# KVDT Analyzer – Python / PyQt6

## Voraussetzung
Python 3.10 oder neuer: https://www.python.org/downloads/

## Installation (einmalig)

```
pip install -r requirements.txt
```

## Starten (ohne Installer)

```
python main.py
```

## Windows .exe bauen

```
pyinstaller kvdt_analyzer.spec
```

Die fertige `KVDT-Analyzer.exe` erscheint im Ordner `dist\`.
Sie benötigt kein installiertes Python – einfach doppelklicken.

## Projektstruktur

```
kvdt-python/
├── main.py                  # Einstiegspunkt
├── requirements.txt
├── kvdt_analyzer.spec       # PyInstaller-Konfiguration
├── core/
│   ├── parser.py            # KVDT-Parser, EBM-Daten
│   ├── session.py           # Datenverwaltung & Persistenz
│   └── export_xlsx.py       # Excel-Export
└── views/
    ├── main_window.py       # Hauptfenster
    ├── style.py             # Dark-Theme Stylesheet
    ├── base_tab.py          # Basis-Tab mit Hilfsmethoden
    ├── tab_vergleich.py     # Tab: Quartal-Vergleich
    ├── tab_ebm.py           # Tab: EBM-Leistungen
    ├── tab_diagnosen.py     # Tab: Diagnosen
    ├── tab_chroniker.py     # Tab: Chroniker
    └── tab_honorar.py       # Tab: Honorar
```

## EBM Updater (für neue KBV-Quartalsdaten)

Wenn die KBV eine neue EHD XML-Datei veröffentlicht (z.B. `850_xx_xx_xx_tf2026q3_nr1.xml`), kann die EBM-Tabelle damit aktualisiert werden:

```
python tools/ebm_updater.py
```

Das Programm öffnet ein Fenster:
1. XML-Datei(en) per Drag & Drop oder Datei-Dialog auswählen
2. **parser.py jetzt aktualisieren** klicken
3. Fertig – alle neuen GOPs sind automatisch eingetragen

Die XML-Dateien sind auf der KBV-Website erhältlich:  
https://www.kbv.de/html/online-ebm.php

---


Alle Daten werden ausschließlich lokal verarbeitet.
Keine Internetverbindung, keine Cloud, keine Telemetrie.
