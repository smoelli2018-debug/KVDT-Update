#!/usr/bin/env python3
"""
EBM Builder & GitHub Uploader
==============================
KBV EHD XML einlesen → Einträge prüfen & bearbeiten → GitHub hochladen
Starten: python tools/ebm_builder.py
"""
import sys, os, re, json, base64, xml.etree.ElementTree as ET
import urllib.request, urllib.error, datetime
from collections import Counter

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QProgressBar, QFrame,
    QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QLineEdit, QComboBox, QAbstractItemView, QCheckBox, QGroupBox,
    QScrollArea, QFormLayout, QTextEdit, QSplitter
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QBrush, QFont

# ── Konstanten ────────────────────────────────────────────────────────────────
NS_GO, NS_EHD = 'urn:ehd/go/001', 'urn:ehd/001'
COL_CODE, COL_KV, COL_ALT, COL_NEU, COL_STATUS = 0, 1, 2, 3, 4
COLOR_NEW_BW  = QColor("#dcfce7")
COLOR_NEW_REG = QColor("#ede9fe")
COLOR_CHANGED = QColor("#fef9c3")
COLOR_SAME    = QColor("#f8fafc")

KV_NAMEN = {
    "00":"Bundesweit","01":"KV Schleswig-Holstein","02":"KV Hamburg",
    "03":"KV Bremen","17":"KV Niedersachsen","20":"KV Westfalen-Lippe",
    "38":"KV Nordrhein","46":"KV Hessen","51":"KV Rheinland-Pfalz",
    "52":"KV Baden-Württemberg","71":"KV Bayerns","72":"KV Berlin",
    "73":"KV Saarland","74":"KV Westfalen-Lippe","78":"KV Mecklenburg-Vorpommern",
    "83":"KV Brandenburg","88":"KV Sachsen-Anhalt","93":"KV Thüringen","98":"KV Sachsen",
}

SETTINGS_FILE = os.path.join(os.path.expanduser("~"), ".ebm_builder_settings.json")

STYLE = """
QMainWindow,QWidget { background:#f8fafc; font-size:13px; color:#0f172a; }
#title { font-size:19px; font-weight:800; color:#1e3a5f; }
#sub   { font-size:12px; color:#64748b; }
#dz    { background:white; border:2px dashed #cbd5e1; border-radius:10px; }
#info  { background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px;
         padding:8px 12px; color:#1e40af; font-size:12px; }
#legend { background:white; border:1px solid #e2e8f0; border-radius:6px;
          padding:5px 10px; font-size:11px; }
QPushButton { background:#2563eb; color:white; border:none;
              border-radius:7px; padding:8px 18px; font-weight:700; }
QPushButton:hover    { background:#1d4ed8; }
QPushButton:disabled { background:#cbd5e1; color:#94a3b8; }
#sec { background:white; color:#334155; border:1px solid #e2e8f0; font-weight:400; }
#sec:hover { background:#f1f5f9; border-color:#2563eb; color:#2563eb; }
#ok  { background:#16a34a; }
#ok:hover { background:#15803d; }
#upload { background:#7c3aed; }
#upload:hover { background:#6d28d9; }
QLineEdit { min-height:26px; padding:3px 6px; }
QComboBox { min-height:26px; padding:2px 6px; }
QTabWidget::pane { border:1px solid #e2e8f0; background:white; }
QTabBar::tab { background:#f1f5f9; border:1px solid #e2e8f0; padding:5px 14px;
               border-bottom:none; border-radius:4px 4px 0 0; }
QTabBar::tab:selected { background:white; font-weight:700; }
QTableWidget { background:white; border:1px solid #e2e8f0; font-size:12px; }
QTableWidget QHeaderView::section { background:#f8fafc; border:1px solid #e2e8f0;
    padding:4px 6px; font-weight:700; font-size:12px; }
QGroupBox { border:1px solid #e2e8f0; border-radius:8px; margin-top:8px; padding:8px; }
QGroupBox::title { subcontrol-origin:margin; left:8px; font-weight:700; color:#334155; }
QProgressBar { background:#f1f5f9; border:1px solid #e2e8f0; border-radius:5px;
               height:14px; text-align:center; font-size:11px; }
QProgressBar::chunk { background:#2563eb; border-radius:4px; }
QTextEdit { background:white; border:1px solid #e2e8f0; border-radius:5px;
            font-family:'Consolas',monospace; font-size:11px; }
QScrollArea { border:1px solid #e2e8f0; border-radius:5px; background:white; }
"""

# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def kv_name(code): return KV_NAMEN.get(code, f"KV {code}")

def kv_from_filename(path):
    name = os.path.basename(path)
    m = re.search(r'[\._](\d{2})[\._]tf', name, re.IGNORECASE)
    if m: return m.group(1)
    m = re.search(r'_(\d{2})_tf', name, re.IGNORECASE)
    if m: return m.group(1)
    return "00"

def parse_ehd(path):
    with open(path, 'r', encoding='iso-8859-15', errors='replace') as f:
        content = f.read()
    root = ET.fromstring(content)
    kv = kv_from_filename(path)
    body = root.find(f'{{{NS_EHD}}}body')
    gnr_liste = body.find(f'{{{NS_GO}}}gnr_liste')
    bez, pkt = {}, {}
    for gnr in gnr_liste:
        code = gnr.get('V','').strip()
        if not code: continue
        allg = gnr.find(f'{{{NS_GO}}}allgemein')
        if allg is None: continue
        leg = allg.find(f'{{{NS_GO}}}legende')
        if leg is not None:
            kt = leg.find(f'{{{NS_GO}}}kurztext')
            if kt is not None:
                v = kt.get('V','').strip()
                if v: bez[code] = v[:120]
        bl = allg.find(f'{{{NS_GO}}}bewertung_liste')
        if bl is not None:
            for b in bl.findall(f'{{{NS_GO}}}bewertung'):
                if b.get('U','') == '1':
                    try:
                        p = int(b.get('V',0))
                        if p > 0: pkt[code] = p
                    except: pass
                    break
    return bez, pkt, kv

def determine_kv_scope(results):
    if len(results) <= 1:
        if results:
            _, _, kv, _ = results[0]
            all_codes = set(results[0][0]) | set(results[0][1])
            return {c: kv for c in all_codes}
        return {}
    code_count, code_kv = Counter(), {}
    for bez, pkt, kv, _ in results:
        for code in set(bez) | set(pkt):
            code_count[code] += 1
            if code not in code_kv: code_kv[code] = kv
    threshold = max(2, len(results) * 0.75)
    return {c: ("00" if n >= threshold else code_kv[c]) for c, n in code_count.items()}

def generate_ebm_data_py(bez, pkt, kv_map):
    lines = [
        "# ebm_data.py – EBM Bezeichnungen und Punktzahlen\n",
        f"# Generiert: {datetime.datetime.now().strftime('%d.%m.%Y %H:%M')}\n",
        "# Quelle: KBV EHD XML (https://www.kbv.de/html/online-ebm.php)\n\n",
        "EBM_BEZEICHNUNG = {\n",
    ]
    for code in sorted(bez):
        v = bez[code].replace('\\','\\\\').replace('"',"'")
        kv = kv_map.get(code,'00')
        comment = f"  # KV:{kv}" if kv != '00' else ""
        lines.append(f'    "{code}":"{v}",{comment}\n')
    lines += ["}\n\nEBM_PUNKTE = {\n"]
    for code in sorted(pkt):
        kv = kv_map.get(code,'00')
        comment = f"  # KV:{kv}" if kv != '00' else ""
        lines.append(f'    "{code}":{pkt[code]},{comment}\n')
    lines.append("}\n")
    return "".join(lines)

def load_settings():
    d = {"github_token":"","github_repo":"smoelli2018-debug/ebm_data",
         "github_path":"ebm_data.py","github_branch":"main"}
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE) as f: d.update(json.load(f))
        except: pass
    return d

def save_settings(s):
    with open(SETTINGS_FILE,"w") as f: json.dump(s,f,indent=2)

# ── Worker ────────────────────────────────────────────────────────────────────

class ParseWorker(QThread):
    progress  = pyqtSignal(int, int, str)
    file_done = pyqtSignal(dict, dict, str, str)
    done      = pyqtSignal(object)
    error     = pyqtSignal(str)
    def __init__(self, files): super().__init__(); self.files = files
    def run(self):
        results = []
        try:
            for i, path in enumerate(self.files):
                self.progress.emit(i, len(self.files), os.path.basename(path))
                bez, pkt, kv = parse_ehd(path)
                results.append((bez, pkt, kv, os.path.basename(path)))
                self.file_done.emit(bez, pkt, kv, os.path.basename(path))
            self.progress.emit(len(self.files), len(self.files), "Fertig")
            self.done.emit(results)
        except Exception as e:
            self.error.emit(str(e))

class UploadWorker(QThread):
    done = pyqtSignal(bool, str)
    def __init__(self, token, repo, path, branch, content, message):
        super().__init__()
        self.token=token; self.repo=repo; self.path=path
        self.branch=branch; self.content=content; self.message=message
    def run(self):
        try:
            api = f"https://api.github.com/repos/{self.repo}/contents/{self.path}"
            # SHA holen
            sha = ""
            try:
                req = urllib.request.Request(
                    f"{api}?ref={self.branch}",
                    headers={"Authorization":f"token {self.token}",
                             "Accept":"application/vnd.github.v3+json",
                             "User-Agent":"EBM-Builder/1.0"})
                r = urllib.request.urlopen(req, timeout=15)
                sha = json.loads(r.read()).get("sha","")
            except: pass
            encoded = base64.b64encode(self.content.encode("utf-8")).decode("ascii")
            payload = {"message":self.message,"content":encoded,"branch":self.branch}
            if sha: payload["sha"] = sha
            req2 = urllib.request.Request(api,
                data=json.dumps(payload).encode("utf-8"),
                headers={"Authorization":f"token {self.token}",
                         "Accept":"application/vnd.github.v3+json",
                         "Content-Type":"application/json",
                         "User-Agent":"EBM-Builder/1.0"},
                method="PUT")
            r2 = urllib.request.urlopen(req2, timeout=30)
            result = json.loads(r2.read())
            url = result.get("content",{}).get("html_url","")
            self.done.emit(True, f"Erfolgreich hochgeladen!\n{url}")
        except urllib.error.HTTPError as e:
            self.done.emit(False, f"HTTP {e.code}: {e.read().decode('utf-8','replace')[:300]}")
        except Exception as e:
            self.done.emit(False, str(e))

# ── Review-Tabelle ────────────────────────────────────────────────────────────

class ReviewTable(QTableWidget):
    def __init__(self):
        super().__init__()
        self.setColumnCount(5)
        self.setHorizontalHeaderLabels(["Ziffer","KV","Aktuell","Neu / Importiert","Status"])
        h = self.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.verticalHeader().setDefaultSectionSize(22)
        self.verticalHeader().hide()
        self.setSortingEnabled(True)

    def set_data(self, rows):
        self.setSortingEnabled(False)
        self.setRowCount(len(rows))
        for r, (code, kv, alt, neu, status) in enumerate(rows):
            is_reg = kv != '00'
            if status == "NEU":
                bg = COLOR_NEW_REG if is_reg else COLOR_NEW_BW
            elif status == "GEÄNDERT":
                bg = COLOR_CHANGED
            else:
                bg = COLOR_SAME
            kv_label = f"{kv} {kv_name(kv)}" if is_reg else "bundesweit"
            for c, val in enumerate([code, kv_label, str(alt), str(neu), status]):
                item = QTableWidgetItem(val)
                item.setBackground(QBrush(bg))
                if c != COL_NEU:
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.setItem(r, c, item)
        self.setSortingEnabled(True)

    def get_data(self):
        result = {}
        for r in range(self.rowCount()):
            code   = self.item(r, COL_CODE).text().strip()
            kv_raw = self.item(r, COL_KV).text().split()[0].strip()
            neu    = self.item(r, COL_NEU).text().strip()
            status = self.item(r, COL_STATUS).text().strip()
            result[code] = (neu, kv_raw if kv_raw != "bundesweit" else "00", status)
        return result

# ── Hauptfenster ──────────────────────────────────────────────────────────────

class EBMBuilder(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EBM Builder & GitHub Uploader")
        self.setMinimumSize(1050, 780)
        self.resize(1150, 850)
        self.setStyleSheet(STYLE)
        self.setAcceptDrops(True)
        self.files=[]; self.results=[]; self._all_bez={}; self._all_pkt={}
        self._scope={}; self._generated=""; self.s=load_settings()
        self.kv_checkboxes={}
        self._build_ui()

    def _build_ui(self):
        c = QWidget(); self.setCentralWidget(c)
        L = QVBoxLayout(c); L.setContentsMargins(20,16,20,16); L.setSpacing(10)

        t = QLabel("EBM Builder & GitHub Uploader"); t.setObjectName("title"); L.addWidget(t)
        s = QLabel("KBV EHD XML einlesen → Einträge prüfen & bearbeiten → GitHub hochladen")
        s.setObjectName("sub"); L.addWidget(s)

        # Drop-Zone + Buttons
        top = QHBoxLayout()
        dz = QFrame(); dz.setObjectName("dz"); dz.setFixedHeight(65)
        dzl = QVBoxLayout(dz); dzl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dzl.addWidget(QLabel("📂  XML-Dateien hier ablegen oder auswählen",
            alignment=Qt.AlignmentFlag.AlignCenter, styleSheet="color:#64748b;"))
        top.addWidget(dz, 3)
        btn_col = QVBoxLayout()
        self.b_open = QPushButton("📁  Auswählen"); self.b_open.clicked.connect(self._open)
        btn_col.addWidget(self.b_open)
        self.b_parse = QPushButton("🔍  Einlesen & prüfen")
        self.b_parse.setEnabled(False); self.b_parse.clicked.connect(self._parse)
        btn_col.addWidget(self.b_parse)
        top.addLayout(btn_col, 1)
        L.addLayout(top)

        self.lbl_files = QLabel("Keine Dateien ausgewählt.")
        self.lbl_files.setStyleSheet("color:#64748b; font-size:12px;"); L.addWidget(self.lbl_files)

        # Filter-Zeile
        frow = QHBoxLayout()
        frow.addWidget(QLabel("🔎 Suche:"))
        self.f_search = QLineEdit(); self.f_search.textChanged.connect(self._filter)
        frow.addWidget(self.f_search, 2)
        frow.addWidget(QLabel("Status:"))
        self.f_status = QComboBox()
        self.f_status.addItems(["Alle","Nur NEU","Nur GEÄNDERT","Nur GLEICH"])
        self.f_status.currentTextChanged.connect(self._filter)
        frow.addWidget(self.f_status, 1)
        frow.addWidget(QLabel("KV:"))
        self.f_kv = QComboBox(); self.f_kv.addItem("Alle KV")
        self.f_kv.currentTextChanged.connect(self._filter)
        frow.addWidget(self.f_kv, 1)
        L.addLayout(frow)

        # Legende
        leg = QLabel("  🟢 Neu bundesweit   🟣 Neu regional   🟡 Geändert   ⬜ Gleich"
                     "  │  Doppelklick auf 'Neu'-Spalte zum Bearbeiten")
        leg.setObjectName("legend"); L.addWidget(leg)

        # Tabs: Bezeichnungen / Punktzahlen
        self.tabs_tbl = QTabWidget()
        self.tbl_bez = ReviewTable()
        self.tbl_pkt = ReviewTable()
        self.tbl_pkt.setHorizontalHeaderLabels(["Ziffer","KV","Aktuell (Pkt)","Neu (Pkt)","Status"])
        self.tabs_tbl.addTab(self.tbl_bez, "Bezeichnungen (0)")
        self.tabs_tbl.addTab(self.tbl_pkt, "Punktzahlen (0)")
        L.addWidget(self.tabs_tbl, 1)

        # Statistik
        self.lbl_stats = QLabel(""); self.lbl_stats.setStyleSheet("color:#475569; font-size:12px;")
        L.addWidget(self.lbl_stats)

        # KV-Übernahme + GitHub Upload in einer Zeile
        bottom = QHBoxLayout()

        # KV-Übernahme
        kv_group = QGroupBox("Übernahme beim Generieren")
        kv_l = QHBoxLayout(kv_group)
        self.chk_bundesweit = QCheckBox("Bundesweite GOPs"); self.chk_bundesweit.setChecked(True)
        kv_l.addWidget(self.chk_bundesweit)
        self.chk_regional = QCheckBox("Regionale GOPs:")
        self.chk_regional.setChecked(False); self.chk_regional.toggled.connect(self._toggle_kv)
        kv_l.addWidget(self.chk_regional)
        self.kv_scroll = QScrollArea(); self.kv_scroll.setFixedHeight(60)
        self.kv_scroll.setFixedWidth(350); self.kv_scroll.setEnabled(False)
        self.kv_scroll.setWidgetResizable(True)
        self.kv_chk_widget = QWidget(); self.kv_chk_layout = QHBoxLayout(self.kv_chk_widget)
        self.kv_chk_layout.setContentsMargins(4,2,4,2); self.kv_chk_layout.setSpacing(8)
        self.kv_chk_layout.addStretch(); self.kv_scroll.setWidget(self.kv_chk_widget)
        kv_l.addWidget(self.kv_scroll)
        b_all = QPushButton("Alle ✓"); b_all.setObjectName("sec"); b_all.setFixedHeight(26)
        b_all.clicked.connect(lambda: [cb.setChecked(True) for cb in self.kv_checkboxes.values()])
        kv_l.addWidget(b_all)
        b_none = QPushButton("Keine ✗"); b_none.setObjectName("sec"); b_none.setFixedHeight(26)
        b_none.clicked.connect(lambda: [cb.setChecked(False) for cb in self.kv_checkboxes.values()])
        kv_l.addWidget(b_none)
        bottom.addWidget(kv_group, 2)

        # Aktions-Buttons
        act_group = QGroupBox("Aktionen")
        act_l = QVBoxLayout(act_group)
        self.b_generate = QPushButton("⚙  ebm_data.py generieren")
        self.b_generate.setEnabled(False); self.b_generate.clicked.connect(self._generate)
        act_l.addWidget(self.b_generate)
        self.b_upload = QPushButton("🚀  Nach GitHub hochladen")
        self.b_upload.setObjectName("upload"); self.b_upload.setEnabled(False)
        self.b_upload.clicked.connect(self._show_upload_dialog)
        act_l.addWidget(self.b_upload)
        bottom.addWidget(act_group, 1)
        L.addLayout(bottom)

        # Fortschritt + Status
        self.pb = QProgressBar(); self.pb.hide(); L.addWidget(self.pb)
        brow = QHBoxLayout()
        b_clear = QPushButton("✕  Leeren"); b_clear.setObjectName("sec")
        b_clear.clicked.connect(self._clear); brow.addWidget(b_clear)
        brow.addStretch()
        self.lbl_status = QLabel(""); self.lbl_status.setStyleSheet("color:#64748b; font-size:12px;")
        brow.addWidget(self.lbl_status)
        L.addLayout(brow)

    # ── Drag & Drop ──────────────────────────────────────────────────────────
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()
    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls()
                 if u.toLocalFile().lower().endswith('.xml')]
        if paths: self._add(paths)

    def _open(self):
        paths,_ = QFileDialog.getOpenFileNames(self,"EHD XML","","XML (*.xml);;Alle (*)")
        if paths: self._add(paths)

    def _add(self, paths):
        for p in paths:
            if p not in self.files: self.files.append(p)
        self.lbl_files.setText("  ".join(
            f"📄 {os.path.basename(p)} (KV:{kv_from_filename(p)})" for p in self.files))
        self.b_parse.setEnabled(True)

    def _clear(self):
        self.files=[]; self.results=[]; self._all_bez={}; self._all_pkt={}
        self._scope={}; self._generated=""
        self.lbl_files.setText("Keine Dateien ausgewählt.")
        self.b_parse.setEnabled(False); self.b_generate.setEnabled(False); self.b_upload.setEnabled(False)
        self.tbl_bez.setRowCount(0); self.tbl_pkt.setRowCount(0)
        self.lbl_stats.setText(""); self.lbl_status.setText("")
        self.f_kv.clear(); self.f_kv.addItem("Alle KV")
        for cb in list(self.kv_checkboxes.values()): cb.deleteLater()
        self.kv_checkboxes.clear()

    def _toggle_kv(self, checked):
        self.kv_scroll.setEnabled(checked)
        for cb in self.kv_checkboxes.values(): cb.setEnabled(checked)

    # ── Einlesen ─────────────────────────────────────────────────────────────
    def _parse(self):
        self.b_parse.setEnabled(False); self.b_generate.setEnabled(False)
        self._all_bez={}; self._all_pkt={}
        self.pb.setRange(0, len(self.files)); self.pb.setValue(0); self.pb.show()
        self.w = ParseWorker(self.files)
        self.w.progress.connect(lambda i,t,n: (self.pb.setValue(i),
            self.lbl_status.setText(f"Lese {i+1}/{t}: {n}")))
        self.w.file_done.connect(self._on_file_done)
        self.w.done.connect(self._on_parsed)
        self.w.error.connect(lambda e: (self.pb.hide(),
            QMessageBox.critical(self,"Fehler",e)))
        self.w.start()

    def _on_file_done(self, bez, pkt, kv, filename):
        self._all_bez.update(bez); self._all_pkt.update(pkt)
        kv_label = f"{kv} – {kv_name(kv)}"
        if self.f_kv.findText(kv_label) == -1: self.f_kv.addItem(kv_label)
        if kv not in self.kv_checkboxes:
            cb = QCheckBox(kv_label); cb.setChecked(True)
            cb.setEnabled(self.chk_regional.isChecked())
            cb.setStyleSheet("font-size:12px;")
            self.kv_chk_layout.insertWidget(self.kv_chk_layout.count()-1, cb)
            self.kv_checkboxes[kv] = cb
        self.lbl_status.setText(
            f"✓ {filename} (KV {kv})  |  {len(self._all_bez)} Bez, {len(self._all_pkt)} Pkt")

    def _on_parsed(self, results):
        self.pb.hide(); self.results = results
        self._scope = determine_kv_scope(results)

        # Bezeichnungs-Tabelle
        bez_rows=[]; n_new=n_chg=0
        for code, val in sorted(self._all_bez.items()):
            kv = self._scope.get(code,'00')
            status = "NEU" if True else "GLEICH"  # Alles NEU da kein Vergleich mit bestehender Datei
            status = "NEU"; n_new += 1
            bez_rows.append((code, kv, "", val, status))
        self.tbl_bez.set_data(bez_rows)
        self.tabs_tbl.setTabText(0, f"Bezeichnungen ({len(bez_rows)})")

        # Punktzahl-Tabelle
        pkt_rows=[]; p_new=0
        for code, val in sorted(self._all_pkt.items()):
            kv = self._scope.get(code,'00')
            pkt_rows.append((code, kv, "", str(val), "NEU"))
            p_new += 1
        self.tbl_pkt.set_data(pkt_rows)
        self.tabs_tbl.setTabText(1, f"Punktzahlen ({len(pkt_rows)})")

        n_regional_b = sum(1 for _,kv,_,_,_ in bez_rows if kv != "00")
        self.lbl_stats.setText(
            f"Bezeichnungen: {len(bez_rows)} ({n_regional_b} regional)   "
            f"Punktzahlen: {len(pkt_rows)}")
        self.lbl_status.setText(f"✓ {len(results)} Datei(en) eingelesen")
        self.b_parse.setEnabled(True); self.b_generate.setEnabled(True)

    # ── Filter ───────────────────────────────────────────────────────────────
    def _filter(self):
        search = self.f_search.text().lower()
        sf = self.f_status.currentText()
        kf = self.f_kv.currentText()
        kf_code = kf.split(" –")[0].strip() if " –" in kf else ""
        for tbl in [self.tbl_bez, self.tbl_pkt]:
            for r in range(tbl.rowCount()):
                code   = tbl.item(r,COL_CODE).text().lower()
                kv_raw = tbl.item(r,COL_KV).text()
                neu    = tbl.item(r,COL_NEU).text().lower()
                status = tbl.item(r,COL_STATUS).text()
                ok_s = not search or search in code or search in neu
                ok_st = (sf=="Alle" or
                    (sf=="Nur NEU" and status=="NEU") or
                    (sf=="Nur GEÄNDERT" and status=="GEÄNDERT") or
                    (sf=="Nur GLEICH" and status=="GLEICH"))
                ok_kv = not kf_code or kf_code in kv_raw
                tbl.setRowHidden(r, not(ok_s and ok_st and ok_kv))

    # ── Generieren ────────────────────────────────────────────────────────────
    def _generate(self):
        selected_kv = {code for code,cb in self.kv_checkboxes.items() if cb.isChecked()}
        # Sammle finale Daten aus editierten Tabellen
        bez_data = self.tbl_bez.get_data()
        pkt_data = self.tbl_pkt.get_data()
        final_bez, final_pkt, final_kv = {}, {}, {}
        for code, (neu, kv, status) in bez_data.items():
            is_reg = kv != '00'
            if is_reg and not self.chk_regional.isChecked(): continue
            if is_reg and selected_kv and kv not in selected_kv: continue
            if not is_reg and not self.chk_bundesweit.isChecked(): continue
            if neu.strip():
                final_bez[code] = neu.strip()
                if is_reg: final_kv[code] = kv
        for code, (neu, kv, status) in pkt_data.items():
            is_reg = kv != '00'
            if is_reg and not self.chk_regional.isChecked(): continue
            if is_reg and selected_kv and kv not in selected_kv: continue
            if not is_reg and not self.chk_bundesweit.isChecked(): continue
            try:
                p = int(neu.strip())
                if p >= 0:
                    final_pkt[code] = p
                    if is_reg: final_kv[code] = kv
            except: pass
        self._generated = generate_ebm_data_py(final_bez, final_pkt, final_kv)
        self.lbl_status.setText(
            f"✓ Generiert: {len(final_bez)} Bezeichnungen, {len(final_pkt)} Punktzahlen")
        self.b_upload.setEnabled(True)
        # Lokal speichern anbieten
        reply = QMessageBox.question(self, "Generiert",
            f"ebm_data.py generiert!\n\n"
            f"{len(final_bez)} Bezeichnungen, {len(final_pkt)} Punktzahlen\n\n"
            "Lokal speichern?")
        if reply == QMessageBox.StandardButton.Yes:
            path,_ = QFileDialog.getSaveFileName(self,"Speichern","ebm_data.py","Python (*.py)")
            if path:
                with open(path,"w",encoding="utf-8") as f: f.write(self._generated)

    # ── GitHub Upload ─────────────────────────────────────────────────────────
    def _show_upload_dialog(self):
        if not self._generated:
            QMessageBox.warning(self,"Hinweis","Zuerst generieren (⚙ Button).")
            return
        dlg = UploadDialog(self.s, self._generated, parent=self)
        dlg.exec()
        self.s = load_settings()


# ── Upload-Dialog ─────────────────────────────────────────────────────────────

class UploadDialog(QMessageBox.__class__):
    pass

from PyQt6.QtWidgets import QDialog

class UploadDialog(QDialog):
    def __init__(self, settings, content, parent=None):
        super().__init__(parent)
        self.setWindowTitle("GitHub Upload")
        self.setMinimumSize(520, 420)
        self.setStyleSheet(STYLE)
        self.s = settings; self.content = content
        self._build()

    def _build(self):
        L = QVBoxLayout(self)
        L.setContentsMargins(20,16,20,16); L.setSpacing(10)
        t = QLabel("🚀  Nach GitHub hochladen")
        t.setStyleSheet("font-size:16px; font-weight:bold; color:#1e3a5f;")
        L.addWidget(t)

        fl = QFormLayout(); fl.setSpacing(10)
        self.inp_token = QLineEdit(self.s.get("github_token",""))
        self.inp_token.setEchoMode(QLineEdit.EchoMode.Password)
        fl.addRow("Personal Access Token:", self.inp_token)
        help_lbl = QLabel("Token benötigt repo-Schreibrechte.\nGitHub → Settings → Developer Settings → Tokens")
        help_lbl.setStyleSheet("color:#64748b; font-size:11px;")
        fl.addRow("", help_lbl)
        self.inp_repo = QLineEdit(self.s.get("github_repo","smoelli2018-debug/ebm_data"))
        fl.addRow("Repository:", self.inp_repo)
        self.inp_path = QLineEdit(self.s.get("github_path","ebm_data.py"))
        fl.addRow("Dateipfad:", self.inp_path)
        self.inp_branch = QLineEdit(self.s.get("github_branch","main"))
        fl.addRow("Branch:", self.inp_branch)
        self.inp_msg = QLineEdit(f"EBM Update {datetime.date.today().strftime('%d.%m.%Y')}")
        fl.addRow("Commit-Nachricht:", self.inp_msg)
        L.addLayout(fl)

        self.pb = QProgressBar(); self.pb.setRange(0,0); self.pb.hide()
        L.addWidget(self.pb)
        self.txt_log = QTextEdit(); self.txt_log.setReadOnly(True); self.txt_log.setFixedHeight(100)
        L.addWidget(self.txt_log)

        row = QHBoxLayout()
        b_close = QPushButton("Schließen"); b_close.setObjectName("sec")
        b_close.clicked.connect(self.accept); row.addWidget(b_close)
        row.addStretch()
        self.b_up = QPushButton("🚀  Hochladen")
        self.b_up.setStyleSheet("QPushButton{background:#7c3aed;color:white;border:none;"
                                "border-radius:7px;padding:8px 20px;font-weight:700;}"
                                "QPushButton:hover{background:#6d28d9;}")
        self.b_up.clicked.connect(self._upload); row.addWidget(self.b_up)
        L.addLayout(row)

    def _upload(self):
        token = self.inp_token.text().strip()
        if not token:
            QMessageBox.warning(self,"Fehler","Bitte Token eingeben."); return
        self.s["github_token"]  = token
        self.s["github_repo"]   = self.inp_repo.text().strip()
        self.s["github_path"]   = self.inp_path.text().strip()
        self.s["github_branch"] = self.inp_branch.text().strip()
        save_settings(self.s)
        self.b_up.setEnabled(False); self.pb.show()
        self.txt_log.append(f"[{datetime.datetime.now().strftime('%H:%M:%S')}] Upload gestartet…")
        self.uw = UploadWorker(token, self.s["github_repo"], self.s["github_path"],
                               self.s["github_branch"], self.content,
                               self.inp_msg.text().strip() or "EBM Update")
        self.uw.done.connect(self._done)
        self.uw.start()

    def _done(self, ok, msg):
        self.pb.hide(); self.b_up.setEnabled(True)
        ts = datetime.datetime.now().strftime('%H:%M:%S')
        self.txt_log.append(f"[{ts}] {'✓' if ok else '✗'} {msg}")
        if ok:
            QMessageBox.information(self,"Erfolg", msg)
        else:
            QMessageBox.critical(self,"Fehler", msg)


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("EBM Builder")
    font = QFont(); font.setPointSize(10); app.setFont(font)
    w = EBMBuilder(); w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
