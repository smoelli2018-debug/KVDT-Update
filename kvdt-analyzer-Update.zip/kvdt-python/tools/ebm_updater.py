#!/usr/bin/env python3
"""EBM Updater – liest KBV EHD XML ein, unterscheidet KV-Herkunft, kontrollierbare Übernahme"""
import sys, os, re, xml.etree.ElementTree as ET
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QFileDialog, QTextEdit, QProgressBar, QFrame,
    QMessageBox, QTableWidget, QTableWidgetItem, QHeaderView, QTabWidget,
    QLineEdit, QComboBox, QAbstractItemView, QCheckBox, QGroupBox,
    QListWidget, QListWidgetItem, QScrollArea
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QColor, QBrush

TARGET = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                      'core', 'ebm_data.py')
NS_GO, NS_EHD = 'urn:ehd/go/001', 'urn:ehd/001'

# KV-Code → Name
KV_NAMEN = {
    "01":"KV Schleswig-Holstein","02":"KV Hamburg","03":"KV Bremen",
    "17":"KV Niedersachsen","20":"KV Westfalen-Lippe","38":"KV Nordrhein",
    "46":"KV Hessen","51":"KV Rheinland-Pfalz","52":"KV Baden-Württemberg",
    "71":"KV Bayerns","72":"KV Berlin","73":"KV Saarland","74":"KV Westfalen-Lippe",
    "78":"KV Mecklenburg-Vorpommern","83":"KV Brandenburg","88":"KV Sachsen-Anhalt",
    "93":"KV Thüringen","98":"KV Sachsen",
    "00":"Bundesweit (KBV)",
}

def kv_name(code: str) -> str:
    return KV_NAMEN.get(code, f"KV {code}")

def kv_from_filename(path: str) -> str:
    """Extrahiert KV-Code aus Dateinamen z.B. 850_01_61_74_... → 74"""
    name = os.path.basename(path)
    # Muster: NNN_NN_NN_KK_ oder NNN_NN.NN_KK_
    m = re.search(r'[\._](\d{2})[\._]tf', name, re.IGNORECASE)
    if m:
        return m.group(1)
    # Fallback: letzter 2-stelliger Block vor tf
    m = re.search(r'_(\d{2})_tf', name, re.IGNORECASE)
    if m:
        return m.group(1)
    return "00"

def kv_from_xml(root) -> str:
    """Liest KV-Code aus dem USE-Attribut der GOPs (alle tragen dieselbe KV)."""
    try:
        NS_GO  = 'urn:ehd/go/001'
        NS_EHD = 'urn:ehd/001'
        body = root.find(f'{{{NS_EHD}}}body')
        gnr_liste = body.find(f'{{{NS_GO}}}gnr_liste')
        for gnr in gnr_liste:
            use = gnr.get('USE', '').strip()
            if use:
                return use
    except:
        pass
    return "00"


def determine_kv_scope(all_results: list) -> dict:
    """Bestimmt für jeden GOP-Code ob er bundesweit oder regional ist.
    Bundesweit = kommt in allen KV-Dateien vor (oder in >= 75% der Dateien).
    Regional   = kommt nur in 1-2 KV-Dateien vor.
    Gibt {code: kv_code} zurück: '00' = bundesweit, 'XX' = nur diese KV."""
    if len(all_results) <= 1:
        # Nur eine Datei – alle als KV-spezifisch kennzeichnen
        if all_results:
            _, _, kv, _ = all_results[0]
            return {code: kv for codes in [all_results[0][0], all_results[0][1]]
                    for code in codes}
        return {}

    # Zähle in wie vielen Dateien jeder Code vorkommt
    from collections import Counter
    code_count = Counter()
    code_kv    = {}  # welche KV hat diesen Code zuerst gesehen
    total_files = len(all_results)

    for bez, pkt, kv, fname in all_results:
        all_codes = set(bez.keys()) | set(pkt.keys())
        for code in all_codes:
            code_count[code] += 1
            if code not in code_kv:
                code_kv[code] = kv

    # Schwellwert: >= 75% der Dateien → bundesweit
    threshold = max(2, total_files * 0.75)
    scope = {}
    for code, count in code_count.items():
        if count >= threshold:
            scope[code] = "00"  # bundesweit
        else:
            scope[code] = code_kv[code]  # regional, erste KV die ihn hatte
    return scope


def parse_ehd(path: str) -> tuple:
    """Gibt (bez, pkt, kv_code) zurück. KV aus Dateiname."""
    kv = kv_from_filename(path)

    with open(path, 'r', encoding='iso-8859-15', errors='replace') as f:
        content = f.read()
    root = ET.fromstring(content)

    # KV aus XML falls Dateiname nicht eindeutig
    if kv == "00":
        kv = kv_from_xml(root)

    body = root.find(f'{{{NS_EHD}}}body')
    gnr_liste = body.find(f'{{{NS_GO}}}gnr_liste')

    bez, pkt = {}, {}
    for gnr in gnr_liste:
        code = gnr.get('V', '').strip()
        if not code: continue
        allg = gnr.find(f'{{{NS_GO}}}allgemein')
        if allg is None: continue

        leg = allg.find(f'{{{NS_GO}}}legende')
        if leg is not None:
            kt = leg.find(f'{{{NS_GO}}}kurztext')
            if kt is not None:
                v = kt.get('V', '').strip()
                if v: bez[code] = v[:120]

        bl = allg.find(f'{{{NS_GO}}}bewertung_liste')
        if bl is not None:
            for b in bl.findall(f'{{{NS_GO}}}bewertung'):
                if b.get('U', '') == '1':
                    try:
                        p = int(b.get('V', 0))
                        if p > 0: pkt[code] = p
                    except: pass
                    break
    return bez, pkt, kv


def load_existing() -> tuple:
    """Liest bestehende ebm_data.py – gibt (bez, pkt, kv_map) zurück.
    kv_map = {code: kv_code} aus Kommentaren"""
    bez, pkt, kv_map = {}, {}, {}
    if not os.path.exists(TARGET): return bez, pkt, kv_map
    with open(TARGET, 'r', encoding='utf-8') as f:
        c = f.read()
    # Format: "01100":"Bezeichnung",  # KV:74
    for m in re.finditer(r'"(\d{5}[A-Za-z0-9]*?)"\s*:\s*"([^"]*)"(?:\s*#\s*KV:(\w+))?', c):
        code = m.group(1)
        bez[code] = m.group(2)
        if m.group(3): kv_map[code] = m.group(3)
    for m in re.finditer(r'"(\d{5}[A-Za-z0-9]*?)"\s*:\s*(\d+)(?:\s*#\s*KV:(\w+))?', c):
        code = m.group(1)
        pkt[code] = int(m.group(2))
        if m.group(3): kv_map[code] = m.group(3)
    return bez, pkt, kv_map


def write_ebm_data(bez: dict, pkt: dict, kv_map: dict):
    """Schreibt ebm_data.py mit KV-Kommentaren."""
    lines = [
        "# ebm_data.py – EBM Bezeichnungen und Punktzahlen\n",
        "# Automatisch generiert – zum Update: python tools/ebm_updater.py\n",
        "# Quelle: KBV EHD XML (https://www.kbv.de/html/online-ebm.php)\n",
        "# KV-Kennzeichnung: # KV:XX = nur für diese KV gültig, KV:00 = bundesweit\n\n",
        "EBM_BEZEICHNUNG = {\n",
    ]
    for code in sorted(bez):
        v = bez[code].replace('\\', '\\\\').replace('"', "'")
        kv = kv_map.get(code, '00')
        comment = f"  # KV:{kv}" if kv != '00' else ""
        lines.append(f'    "{code}":"{v}",{comment}\n')
    lines += ["}\n\nEBM_PUNKTE = {\n"]
    for code in sorted(pkt):
        kv = kv_map.get(code, '00')
        comment = f"  # KV:{kv}" if kv != '00' else ""
        lines.append(f'    "{code}":{pkt[code]},{comment}\n')
    lines.append("}\n")
    with open(TARGET, 'w', encoding='utf-8') as f:
        f.writelines(lines)


# ── Worker ────────────────────────────────────────────────────────────────────

class ParseWorker(QThread):
    progress = pyqtSignal(int, int, str)   # current, total, filename
    file_done = pyqtSignal(dict, dict, str, str)  # bez, pkt, kv, filename
    done  = pyqtSignal(object)
    error = pyqtSignal(str)

    def __init__(self, files):
        super().__init__()
        self.files = files

    def run(self):
        results = []
        total = len(self.files)
        try:
            for i, path in enumerate(self.files):
                self.progress.emit(i, total, os.path.basename(path))
                bez, pkt, kv = parse_ehd(path)
                results.append((bez, pkt, kv, os.path.basename(path)))
                self.file_done.emit(bez, pkt, kv, os.path.basename(path))
            self.progress.emit(total, total, "Fertig")
            self.done.emit(results)
        except Exception as e:
            self.error.emit(str(e))


# ── Tabelle ───────────────────────────────────────────────────────────────────

COL_CODE, COL_KV, COL_ALT, COL_NEU, COL_STATUS = 0, 1, 2, 3, 4

COLOR_NEW     = QColor("#dcfce7")
COLOR_CHANGED = QColor("#fef9c3")
COLOR_SAME    = QColor("#f8fafc")
COLOR_KV      = QColor("#ede9fe")  # lila für regionale Einträge


class ReviewTable(QTableWidget):
    def __init__(self, is_pkt=False):
        super().__init__()
        self.is_pkt = is_pkt
        headers = ["Ziffer","KV","Aktuell","Neu / Importiert","Status"]
        self.setColumnCount(len(headers))
        self.setHorizontalHeaderLabels(headers)
        h = self.horizontalHeader()
        h.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        h.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.setEditTriggers(QAbstractItemView.EditTrigger.DoubleClicked)
        self.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.verticalHeader().setDefaultSectionSize(22)
        self.verticalHeader().hide()
        self.setSortingEnabled(True)

    def set_data(self, rows):
        """rows: (code, kv, alt, neu, status)"""
        self.setSortingEnabled(False)
        self.setRowCount(len(rows))
        for r, (code, kv, alt, neu, status) in enumerate(rows):
            is_regional = kv != '00'
            if status == "NEU":
                bg = COLOR_KV if is_regional else COLOR_NEW
            elif status == "GEÄNDERT":
                bg = COLOR_CHANGED
            else:
                bg = COLOR_KV if is_regional else COLOR_SAME

            kv_label = f"{kv} {kv_name(kv)}" if is_regional else "bundesweit"
            for c, val in enumerate([code, kv_label, str(alt), str(neu), status]):
                item = QTableWidgetItem(val)
                item.setBackground(QBrush(bg))
                if c != COL_NEU:
                    item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                self.setItem(r, c, item)
        self.setSortingEnabled(True)

    def get_data(self):
        result = {}
        for r in range(self.rowCount()):
            code   = self.item(r, COL_CODE).text().strip()
            kv_raw = self.item(r, COL_KV).text().split()[0].strip()
            neu    = self.item(r, COL_NEU).text().strip()
            status = self.item(r, COL_STATUS).text().strip()
            result[code] = (neu, kv_raw if kv_raw != "bundesweit" else "00", status)
        return result


# ── Hauptfenster ──────────────────────────────────────────────────────────────

STYLE = """
* { font-family:'Segoe UI',Arial; font-size:13px; color:#0f172a; }
QMainWindow,QWidget { background:#f8fafc; }
#title { font-size:19px; font-weight:800; }
#sub   { font-size:12px; color:#64748b; }
#info  { background:#eff6ff; border:1px solid #bfdbfe; border-radius:8px;
         padding:8px 12px; color:#1e40af; font-size:12px; }
#dz    { background:white; border:2px dashed #cbd5e1; border-radius:10px; }
QPushButton { background:#2563eb; color:white; border:none;
              border-radius:7px; padding:8px 20px; font-weight:700; }
QPushButton:hover    { background:#1d4ed8; }
QPushButton:disabled { background:#cbd5e1; color:#94a3b8; }
#sec { background:white; color:#334155; border:1px solid #e2e8f0; font-weight:400; }
#sec:hover { background:#f1f5f9; border-color:#2563eb; color:#2563eb; }
#ok  { background:#16a34a; }
#ok:hover { background:#15803d; }
#legend { background:white; border:1px solid #e2e8f0; border-radius:6px; padding:6px 10px; font-size:11px; }
QTabWidget::pane { border:1px solid #e2e8f0; background:white; }
QTabBar::tab { background:#f1f5f9; border:1px solid #e2e8f0; padding:5px 14px;
               border-bottom:none; border-radius:4px 4px 0 0; }
QTabBar::tab:selected { background:white; font-weight:700; }
QTableWidget { background:white; border:1px solid #e2e8f0; gridline-color:#f1f5f9; font-size:12px; }
QTableWidget QHeaderView::section { background:#f8fafc; border:1px solid #e2e8f0;
    padding:4px 6px; font-weight:700; font-size:12px; }
QLineEdit { min-height:26px; padding:3px 6px; }
QComboBox { background:white; border:1px solid #e2e8f0; border-radius:5px; padding:4px 8px; }
QGroupBox { border:1px solid #e2e8f0; border-radius:6px; margin-top:8px; padding:6px; font-weight:700; }
QGroupBox::title { subcontrol-origin:margin; left:8px; }
QCheckBox { spacing:6px; }
QProgressBar { background:#f1f5f9; border:1px solid #e2e8f0; border-radius:5px;
               height:14px; text-align:center; font-size:11px; }
QProgressBar::chunk { background:#2563eb; border-radius:4px; }
"""


class EBMUpdater(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("EBM Updater – KVDT Analyzer")
        self.setMinimumSize(1000, 720)
        self.resize(1100, 800)
        self.setStyleSheet(STYLE)
        self.setAcceptDrops(True)
        self.files = []
        self.results = []
        self._all_bez = {}
        self._all_pkt = {}
        self.ex_bez = {}
        self.ex_pkt = {}
        self.ex_kv  = {}
        self._build_ui()

    def _build_ui(self):
        c = QWidget()
        self.setCentralWidget(c)
        L = QVBoxLayout(c)
        L.setContentsMargins(20, 16, 20, 16)
        L.setSpacing(10)

        # Titel
        t = QLabel("EBM Updater")
        t.setObjectName("title")
        L.addWidget(t)
        s = QLabel("KBV EHD XML einlesen → KV-Herkunft erkennen → Einträge prüfen & speichern")
        s.setObjectName("sub")
        L.addWidget(s)

        ex = "✓ vorhanden" if os.path.exists(TARGET) else "⚠ noch nicht vorhanden"
        self.lbl_info = QLabel(f"Zieldatei: core/ebm_data.py  [{ex}]")
        self.lbl_info.setObjectName("info")
        L.addWidget(self.lbl_info)

        # Drop-Zone
        top = QHBoxLayout()
        dz = QFrame()
        dz.setObjectName("dz")
        dz.setFixedHeight(65)
        dzl = QVBoxLayout(dz)
        dzl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        dzl.addWidget(QLabel("📂  XML-Dateien hier ablegen oder auswählen",
                             alignment=Qt.AlignmentFlag.AlignCenter,
                             styleSheet="color:#64748b;"))
        top.addWidget(dz, 3)

        btn_col = QVBoxLayout()
        self.b_open = QPushButton("📁  Auswählen")
        self.b_open.clicked.connect(self._open)
        btn_col.addWidget(self.b_open)
        self.b_parse = QPushButton("🔍  Einlesen & prüfen")
        self.b_parse.setEnabled(False)
        self.b_parse.clicked.connect(self._parse)
        btn_col.addWidget(self.b_parse)
        top.addLayout(btn_col, 1)
        L.addLayout(top)

        self.lbl_files = QLabel("Keine Dateien ausgewählt.")
        self.lbl_files.setStyleSheet("color:#64748b;font-size:12px;")
        L.addWidget(self.lbl_files)

        # Filter + KV-Filter
        frow = QHBoxLayout()
        frow.addWidget(QLabel("🔎 Suche:"))
        self.f_search = QLineEdit()
        self.f_search.textChanged.connect(self._filter)
        frow.addWidget(self.f_search, 2)
        frow.addWidget(QLabel("Status:"))
        self.f_status = QComboBox()
        self.f_status.addItems(["Alle","Nur NEU","Nur GEÄNDERT","Nur GLEICH"])
        self.f_status.currentTextChanged.connect(self._filter)
        frow.addWidget(self.f_status, 1)
        frow.addWidget(QLabel("KV:"))
        self.f_kv = QComboBox()
        self.f_kv.addItem("Alle KV")
        self.f_kv.currentTextChanged.connect(self._filter)
        frow.addWidget(self.f_kv, 1)
        L.addLayout(frow)

        # Legende
        leg = QLabel(
            "  🟢 Neu (bundesweit)   🟣 Neu (regional)   🟡 Geändert   ⬜ Unverändert   "
            "│  Doppelklick auf 'Neu'-Spalte zum Bearbeiten")
        leg.setObjectName("legend")
        L.addWidget(leg)

        # Tabs
        self.tabs = QTabWidget()
        self.tbl_bez = ReviewTable(is_pkt=False)
        self.tbl_pkt = ReviewTable(is_pkt=True)
        self.tbl_pkt.setHorizontalHeaderLabels(
            ["Ziffer","KV","Aktuell (Pkt)","Neu (Pkt)","Status"])
        self.tabs.addTab(self.tbl_bez, "Bezeichnungen (0)")
        self.tabs.addTab(self.tbl_pkt, "Punktzahlen (0)")
        L.addWidget(self.tabs, 1)

        # Statistik
        self.lbl_stats = QLabel("")
        self.lbl_stats.setStyleSheet("color:#475569;font-size:12px;")
        L.addWidget(self.lbl_stats)

        # KV-Übernahme-Optionen
        kv_group = QGroupBox("Übernahme-Einstellungen")
        kv_layout = QHBoxLayout(kv_group)
        kv_layout.addWidget(QLabel("Beim Speichern übernehmen:"))
        self.chk_bundesweit = QCheckBox("Bundesweite GOPs (KV:00)")
        self.chk_bundesweit.setChecked(True)
        kv_layout.addWidget(self.chk_bundesweit)
        self.chk_regional = QCheckBox("Regionale GOPs:")
        self.chk_regional.setChecked(False)
        self.chk_regional.toggled.connect(self._toggle_kv_list)
        kv_layout.addWidget(self.chk_regional)

        # Checkbox-Container für KV-Auswahl (scrollbar)
        self.kv_scroll = QScrollArea()
        self.kv_scroll.setFixedHeight(72)
        self.kv_scroll.setFixedWidth(500)
        self.kv_scroll.setEnabled(False)
        self.kv_scroll.setWidgetResizable(True)
        self.kv_scroll.setStyleSheet(
            "QScrollArea { border:1px solid #e2e8f0; border-radius:5px; background:white; }")
        self.kv_chk_widget = QWidget()
        self.kv_chk_layout = QHBoxLayout(self.kv_chk_widget)
        self.kv_chk_layout.setContentsMargins(6,4,6,4)
        self.kv_chk_layout.setSpacing(12)
        self.kv_chk_layout.addStretch()
        self.kv_scroll.setWidget(self.kv_chk_widget)
        self.kv_checkboxes = {}  # {kv_code: QCheckBox}
        kv_layout.addWidget(self.kv_scroll)

        btn_kv = QVBoxLayout()
        self.b_kv_all = QPushButton("Alle ✓")
        self.b_kv_all.setObjectName("sec")
        self.b_kv_all.setFixedHeight(28)
        self.b_kv_all.setEnabled(False)
        self.b_kv_all.clicked.connect(self._kv_select_all)
        btn_kv.addWidget(self.b_kv_all)
        self.b_kv_none = QPushButton("Keine ✗")
        self.b_kv_none.setObjectName("sec")
        self.b_kv_none.setFixedHeight(28)
        self.b_kv_none.setEnabled(False)
        self.b_kv_none.clicked.connect(self._kv_select_none)
        btn_kv.addWidget(self.b_kv_none)
        kv_layout.addLayout(btn_kv)
        kv_layout.addStretch()
        L.addWidget(kv_group)

        # Fortschritt + Buttons unten
        self.pb = QProgressBar()
        self.pb.hide()
        L.addWidget(self.pb)

        bot = QHBoxLayout()
        b_clear = QPushButton("✕  Leeren")
        b_clear.setObjectName("sec")
        b_clear.clicked.connect(self._clear)
        bot.addWidget(b_clear)
        bot.addStretch()
        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color:#64748b;font-size:12px;")
        bot.addWidget(self.lbl_status)
        bot.addStretch()
        self.b_save = QPushButton("💾  ebm_data.py speichern")
        self.b_save.setObjectName("ok")
        self.b_save.setFixedHeight(40)
        self.b_save.setEnabled(False)
        self.b_save.clicked.connect(self._save)
        bot.addWidget(self.b_save)
        L.addLayout(bot)

    # ── Drag & Drop ──────────────────────────────────────────────────────────
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls(): e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls()
                 if u.toLocalFile().lower().endswith('.xml')]
        if paths: self._add(paths)

    def _open(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "EHD XML-Dateien", "", "XML-Dateien (*.xml);;Alle (*)")
        if paths: self._add(paths)

    def _add(self, paths):
        for p in paths:
            if p not in self.files: self.files.append(p)
        self.lbl_files.setText("  ".join(
            f"📄 {os.path.basename(p)}  (KV: {kv_from_filename(p)} – {kv_name(kv_from_filename(p))})"
            for p in self.files))
        self.b_parse.setEnabled(True)

    def _toggle_kv_list(self, checked):
        self.kv_scroll.setEnabled(checked)
        self.b_kv_all.setEnabled(checked)
        self.b_kv_none.setEnabled(checked)
        for cb in self.kv_checkboxes.values():
            cb.setEnabled(checked)

    def _kv_select_all(self):
        for cb in self.kv_checkboxes.values():
            cb.setChecked(True)

    def _kv_select_none(self):
        for cb in self.kv_checkboxes.values():
            cb.setChecked(False)

    def _clear(self):
        self.files = []; self.results = []
        self._all_bez = {}; self._all_pkt = {}
        self.lbl_files.setText("Keine Dateien ausgewählt.")
        self.b_parse.setEnabled(False); self.b_save.setEnabled(False)
        self.tbl_bez.setRowCount(0); self.tbl_pkt.setRowCount(0)
        self.lbl_stats.setText(""); self.lbl_status.setText("")
        self.f_kv.clear(); self.f_kv.addItem("Alle KV")
        for cb in list(self.kv_checkboxes.values()):
            cb.deleteLater()
        self.kv_checkboxes.clear()

    # ── Einlesen ─────────────────────────────────────────────────────────────
    def _parse(self):
        self.b_parse.setEnabled(False)
        self.b_save.setEnabled(False)
        self.tbl_bez.setRowCount(0)
        self.tbl_pkt.setRowCount(0)
        self.results = []
        self._all_bez = {}
        self._all_pkt = {}
        self.pb.setRange(0, len(self.files))
        self.pb.setValue(0)
        self.pb.show()
        self.lbl_status.setText("Wird eingelesen…")
        self.ex_bez, self.ex_pkt, self.ex_kv = load_existing()
        self.w = ParseWorker(self.files)
        self.w.progress.connect(self._on_progress)
        self.w.file_done.connect(self._on_file_done)
        self.w.done.connect(self._on_parsed)
        self.w.error.connect(self._on_error)
        self.w.start()

    def _on_progress(self, current, total, filename):
        self.pb.setValue(current)
        self.lbl_status.setText(f"Lese {current+1}/{total}: {filename}")

    def _on_file_done(self, bez, pkt, kv, filename):
        self._all_bez.update(bez)
        self._all_pkt.update(pkt)
        # KV-Filter und KV-Liste aktualisieren
        kv_label = f"{kv} – {kv_name(kv)}"
        if self.f_kv.findText(kv_label) == -1:
            self.f_kv.addItem(kv_label)
        # Multi-Select Liste
        kv_code = kv
        if kv_code not in self.kv_checkboxes:
            cb = QCheckBox(kv_label)
            cb.setChecked(True)
            cb.setEnabled(self.chk_regional.isChecked())
            cb.setStyleSheet("font-size:12px; spacing:4px;")
            # Vor dem Stretch einfügen
            self.kv_chk_layout.insertWidget(self.kv_chk_layout.count()-1, cb)
            self.kv_checkboxes[kv_code] = cb
        self.lbl_status.setText(
            f"✓ {filename}  (KV {kv} – {kv_name(kv)})  |  "
            f"bisher {len(self._all_bez)} Bezeichnungen, {len(self._all_pkt)} Punktzahlen")

    def _on_parsed(self, results):
        self.pb.hide()
        self.results = results

        # Bundesweit vs. Regional durch Vergleich aller Dateien bestimmen
        scope = determine_kv_scope(results)

        all_bez = self._all_bez
        all_pkt = self._all_pkt

        # Bezeichnungs-Tabelle
        bez_rows = []
        n_new = n_chg = 0
        for code, val in sorted(all_bez.items()):
            kv = scope.get(code, "00")
            if code not in self.ex_bez:
                status = "NEU"; n_new += 1
            elif self.ex_bez[code] != val:
                status = "GEÄNDERT"; n_chg += 1
            else:
                status = "GLEICH"
            alt = self.ex_bez.get(code, "")
            bez_rows.append((code, kv, alt, val, status))
        self.tbl_bez.set_data(bez_rows)
        self.tabs.setTabText(0, f"Bezeichnungen ({len(bez_rows)})")

        # Punktzahl-Tabelle
        pkt_rows = []
        p_new = p_chg = 0
        for code, val in sorted(all_pkt.items()):
            kv = scope.get(code, "00")
            if code not in self.ex_pkt:
                status = "NEU"; p_new += 1
            elif self.ex_pkt[code] != val:
                status = "GEÄNDERT"; p_chg += 1
            else:
                status = "GLEICH"
            alt = self.ex_pkt.get(code, "")
            pkt_rows.append((code, kv, str(alt), str(val), status))
        self.tbl_pkt.set_data(pkt_rows)
        self.tabs.setTabText(1, f"Punktzahlen ({len(pkt_rows)})")

        # Statistik
        n_regional_b = sum(1 for _, kv, _, _, _ in bez_rows if kv != "00")
        n_regional_p = sum(1 for _, kv, _, _, _ in pkt_rows if kv != "00")
        self.lbl_stats.setText(
            f"Bezeichnungen:  {n_new} neu  |  {n_chg} geändert  |  "
            f"{len(bez_rows)-n_new-n_chg} gleich  |  {n_regional_b} regional     "
            f"Punktzahlen:  {p_new} neu  |  {p_chg} geändert  |  "
            f"{len(pkt_rows)-p_new-p_chg} gleich  |  {n_regional_p} regional"
        )
        self.lbl_status.setText(f"✓ {len(results)} Datei(en) eingelesen")
        self.b_parse.setEnabled(True)
        self.b_save.setEnabled(True)

        if n_chg + p_chg > 0:
            self.f_status.setCurrentText("Nur GEÄNDERT")
        elif n_new + p_new > 0:
            self.f_status.setCurrentText("Nur NEU")

    def _on_error(self, msg):
        self.pb.hide(); self.b_parse.setEnabled(True)
        self.lbl_status.setText("⚠ Fehler")
        QMessageBox.critical(self, "Fehler", msg)

    # ── Filter ───────────────────────────────────────────────────────────────
    def _filter(self):
        search = self.f_search.text().lower()
        sf = self.f_status.currentText()
        kf = self.f_kv.currentText()
        kf_code = kf.split(" –")[0].strip() if " –" in kf else ""

        for tbl in [self.tbl_bez, self.tbl_pkt]:
            for r in range(tbl.rowCount()):
                code   = tbl.item(r, COL_CODE).text().lower()
                kv_raw = tbl.item(r, COL_KV).text()
                neu    = tbl.item(r, COL_NEU).text().lower()
                status = tbl.item(r, COL_STATUS).text()

                ok_search = not search or search in code or search in neu
                ok_status = (sf == "Alle" or
                    (sf == "Nur NEU"      and status == "NEU") or
                    (sf == "Nur GEÄNDERT" and status == "GEÄNDERT") or
                    (sf == "Nur GLEICH"   and status == "GLEICH"))
                ok_kv = (not kf_code or kf_code in kv_raw)

                tbl.setRowHidden(r, not (ok_search and ok_status and ok_kv))

    # ── Speichern ─────────────────────────────────────────────────────────────
    def _save(self):
        save_bundesweit = self.chk_bundesweit.isChecked()
        save_regional   = self.chk_regional.isChecked()

        # Alle angehakten KV-Checkboxen
        selected_kv = {code for code, cb in self.kv_checkboxes.items() if cb.isChecked()}

        bez_data = self.tbl_bez.get_data()
        pkt_data = self.tbl_pkt.get_data()

        final_bez = dict(self.ex_bez)
        final_pkt = dict(self.ex_pkt)
        final_kv  = dict(self.ex_kv)

        for code, (neu, kv, status) in bez_data.items():
            is_regional = kv != '00'
            if is_regional and not save_regional: continue
            if is_regional and save_regional and selected_kv and kv not in selected_kv: continue
            if not is_regional and not save_bundesweit: continue
            if neu.strip():
                final_bez[code] = neu.strip()
                if is_regional: final_kv[code] = kv

        for code, (neu, kv, status) in pkt_data.items():
            is_regional = kv != '00'
            if is_regional and not save_regional: continue
            if is_regional and save_regional and selected_kv and kv not in selected_kv: continue
            if not is_regional and not save_bundesweit: continue
            try:
                p = int(neu.strip())
                if p >= 0:
                    final_pkt[code] = p
                    if is_regional: final_kv[code] = kv
            except ValueError:
                pass

        try:
            write_ebm_data(final_bez, final_pkt, final_kv)
            regional = sum(1 for v in final_kv.values() if v != '00')
            kv_info = f"KV: {', '.join(sorted(selected_kv))}" if selected_kv else "keine regionalen"
            msg = (f"ebm_data.py gespeichert!\n\n"
                   f"Bezeichnungen gesamt: {len(final_bez)}\n"
                   f"Punktzahlen gesamt:   {len(final_pkt)}\n"
                   f"Davon regional:       {regional}  ({kv_info})")
            self.lbl_status.setText("✓ Gespeichert")
            QMessageBox.information(self, "Gespeichert", msg)
        except Exception as e:
            QMessageBox.critical(self, "Fehler beim Speichern", str(e))


def main():
    app = QApplication(sys.argv)
    app.setApplicationName("EBM Updater")
    w = EBMUpdater()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
