# core/updater.py – Automatische Update-Prüfung via GitHub
"""
Auf GitHub müssen zwei Dateien gepflegt werden:
  - version.txt   → enthält nur die aktuelle Versionsnummer, z.B. "1.0.1"
  - KVDT-Analyzer-Update.zip → die neue ZIP mit allen Programmdateien

Beide Dateien im Repository: smoelli2018-debug/KVDT-Update
"""
import sys
import os
import json
import urllib.request
import urllib.error
import zipfile
import shutil
import subprocess
import tempfile

# ── Konfiguration ─────────────────────────────────────────────────────────────
REPO            = "smoelli2018-debug/KVDT-Update"
VERSION_URL     = f"https://raw.githubusercontent.com/{REPO}/main/version.txt"
UPDATE_ZIP_URL  = f"https://raw.githubusercontent.com/{REPO}/main/KVDT-Analyzer-Update.zip"
LOCAL_VERSION_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                   "version.txt")

# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def get_local_version() -> str:
    """Liest die lokale Versionsnummer aus version.txt."""
    try:
        with open(LOCAL_VERSION_FILE, "r") as f:
            return f.read().strip()
    except Exception:
        return "0.0.0"


def get_remote_version() -> str:
    """Holt die aktuelle Versionsnummer von GitHub."""
    try:
        req = urllib.request.Request(
            VERSION_URL,
            headers={"User-Agent": "KVDT-Analyzer-Updater",
                     "Cache-Control": "no-cache"},
        )
        r = urllib.request.urlopen(req, timeout=10)
        return r.read().decode("utf-8").strip()
    except Exception:
        return ""


def version_tuple(v: str) -> tuple:
    """Konvertiert '1.2.3' zu (1, 2, 3) für Vergleich."""
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return (0, 0, 0)


def update_available() -> tuple:
    """Prüft ob ein Update verfügbar ist.
    Gibt (available: bool, local: str, remote: str) zurück."""
    local  = get_local_version()
    remote = get_remote_version()
    if not remote:
        return False, local, ""
    available = version_tuple(remote) > version_tuple(local)
    return available, local, remote


def download_and_install(progress_callback=None) -> tuple:
    """Lädt Update-ZIP herunter und installiert sie.
    progress_callback(percent, message) wird aufgerufen.
    Gibt (success: bool, message: str) zurück."""
    try:
        # Programmverzeichnis bestimmen
        if getattr(sys, 'frozen', False):
            # EXE-Modus (PyInstaller)
            app_dir = os.path.dirname(sys.executable)
        else:
            # Python-Skript-Modus
            app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        if progress_callback:
            progress_callback(5, "Verbinde mit GitHub…")

        # ZIP herunterladen
        req = urllib.request.Request(
            UPDATE_ZIP_URL,
            headers={"User-Agent": "KVDT-Analyzer-Updater",
                     "Cache-Control": "no-cache"},
        )
        r = urllib.request.urlopen(req, timeout=60)
        total = int(r.headers.get("Content-Length", 0))

        if progress_callback:
            progress_callback(10, "Lade Update herunter…")

        # In temporäre Datei schreiben
        tmp_zip = os.path.join(tempfile.gettempdir(), "kvdt_update.zip")
        downloaded = 0
        with open(tmp_zip, "wb") as f:
            while True:
                chunk = r.read(8192)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if total and progress_callback:
                    pct = 10 + int(downloaded / total * 50)
                    progress_callback(pct, f"Lade herunter… {downloaded//1024} KB")

        if progress_callback:
            progress_callback(65, "Entpacke Update…")

        # Backup des aktuellen Verzeichnisses
        backup_dir = app_dir + "_backup"
        if os.path.exists(backup_dir):
            shutil.rmtree(backup_dir, ignore_errors=True)

        # ZIP entpacken in temporäres Verzeichnis
        tmp_extract = os.path.join(tempfile.gettempdir(), "kvdt_update_extract")
        if os.path.exists(tmp_extract):
            shutil.rmtree(tmp_extract, ignore_errors=True)

        with zipfile.ZipFile(tmp_zip, "r") as z:
            z.extractall(tmp_extract)

        if progress_callback:
            progress_callback(80, "Installiere Update…")

        # Extrahierte Dateien ins App-Verzeichnis kopieren
        # Suche den kvdt-python Unterordner in der ZIP
        extracted_root = tmp_extract
        for entry in os.listdir(tmp_extract):
            candidate = os.path.join(tmp_extract, entry)
            if os.path.isdir(candidate) and "kvdt" in entry.lower():
                extracted_root = candidate
                break

        # Dateien kopieren
        for item in os.listdir(extracted_root):
            src = os.path.join(extracted_root, item)
            dst = os.path.join(app_dir, item)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

        if progress_callback:
            progress_callback(95, "Aufräumen…")

        # Temporäre Dateien löschen
        os.remove(tmp_zip)
        shutil.rmtree(tmp_extract, ignore_errors=True)

        if progress_callback:
            progress_callback(100, "Update abgeschlossen!")

        return True, "Update erfolgreich installiert!\nBitte das Programm neu starten."

    except urllib.error.HTTPError as e:
        return False, f"Download-Fehler: HTTP {e.code}\nUpdate-Datei nicht gefunden."
    except urllib.error.URLError as e:
        return False, f"Verbindungsfehler: {e.reason}"
    except Exception as e:
        return False, f"Fehler beim Update: {e}"
