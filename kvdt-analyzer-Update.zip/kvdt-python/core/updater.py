# core/updater.py – Automatische Update-Prüfung via GitHub
"""
Auf GitHub müssen zwei Dateien gepflegt werden:
  - version.txt   → enthält nur die aktuelle Versionsnummer, z.B. "1.0.1"
  - KVDT-Analyzer-Update.zip → die neue ZIP mit allen Programmdateien

Beide Dateien im Repository: smoelli2018-debug/KVDT-Update
"""
import sys
import os
import json
import urllib.request
import urllib.error
import zipfile
import shutil
import subprocess
import tempfile

# ── Konfiguration ─────────────────────────────────────────────────────────────
REPO            = "smoelli2018-debug/KVDT-Update"
VERSION_URL     = f"https://raw.githubusercontent.com/{REPO}/main/version.txt"
UPDATE_ZIP_URL  = f"https://github.com/{REPO}/raw/main/kvdt-analyzer-Update.zip"
LOCAL_VERSION_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                                   "version.txt")

# ── Hilfsfunktionen ───────────────────────────────────────────────────────────

def get_local_version() -> str:
    """Liest die lokale Versionsnummer aus version.txt."""
    try:
        with open(LOCAL_VERSION_FILE, "r") as f:
            return f.read().strip()
    except Exception:
        return "0.0.0"


def get_remote_version() -> str:
    """Holt die aktuelle Versionsnummer von GitHub."""
    try:
        req = urllib.request.Request(
            VERSION_URL,
            headers={"User-Agent": "KVDT-Analyzer-Updater",
                     "Cache-Control": "no-cache"},
        )
        r = urllib.request.urlopen(req, timeout=10)
        return r.read().decode("utf-8").strip()
    except Exception:
        return ""


def version_tuple(v: str) -> tuple:
    """Konvertiert '1.2.3' zu (1, 2, 3) für Vergleich."""
    try:
        return tuple(int(x) for x in v.split("."))
    except Exception:
        return (0, 0, 0)


def update_available() -> tuple:
    """Prüft ob ein Update verfügbar ist.
    Gibt (available: bool, local: str, remote: str) zurück."""
    local  = get_local_version()
    remote = get_remote_version()
    if not remote:
        return False, local, ""
    available = version_tuple(remote) > version_tuple(local)
    return available, local, remote


def download_and_install(progress_callback=None) -> tuple:
    """Lädt Update-ZIP herunter und installiert sie."""
    import ssl
    try:
        # Programmverzeichnis
        if getattr(sys, 'frozen', False):
            app_dir = os.path.dirname(sys.executable)
        else:
            app_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        if progress_callback:
            progress_callback(5, "Verbinde mit GitHub…")

        # SSL-Kontext für Windows
        ctx = ssl.create_default_context()

        # ZIP herunterladen – mit manuellem Redirect-Follow
        url = UPDATE_ZIP_URL
        for _ in range(5):  # max 5 Redirects
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                    "Accept": "*/*",
                    "Cache-Control": "no-cache",
                },
            )
            try:
                r = urllib.request.urlopen(req, timeout=60, context=ctx)
                break
            except urllib.error.HTTPError as e:
                if e.code in (301, 302, 303, 307, 308):
                    url = e.headers.get("Location", url)
                    continue
                raise

        total = int(r.headers.get("Content-Length", 0))

        if progress_callback:
            progress_callback(10, f"Lade Update herunter… ({total//1024} KB)")

        # In temporäre Datei schreiben
        tmp_zip = os.path.join(tempfile.gettempdir(), "kvdt_update.zip")
        downloaded = 0
        with open(tmp_zip, "wb") as f:
            while True:
                chunk = r.read(65536)
                if not chunk:
                    break
                f.write(chunk)
                downloaded += len(chunk)
                if total and progress_callback:
                    pct = 10 + int(downloaded / total * 50)
                    progress_callback(pct, f"Lade herunter… {downloaded//1024} / {total//1024} KB")

        if downloaded == 0:
            return False, "Download fehlgeschlagen – leere Datei erhalten."

        if progress_callback:
            progress_callback(65, "Entpacke Update…")

        # ZIP entpacken
        tmp_extract = os.path.join(tempfile.gettempdir(), "kvdt_update_extract")
        if os.path.exists(tmp_extract):
            shutil.rmtree(tmp_extract, ignore_errors=True)

        with zipfile.ZipFile(tmp_zip, "r") as z:
            z.extractall(tmp_extract)

        if progress_callback:
            progress_callback(80, "Installiere Update…")

        # Extrahierte Dateien ins App-Verzeichnis kopieren
        # Suche den kvdt-python Unterordner in der ZIP
        extracted_root = tmp_extract
        for entry in os.listdir(tmp_extract):
            candidate = os.path.join(tmp_extract, entry)
            if os.path.isdir(candidate) and "kvdt" in entry.lower():
                extracted_root = candidate
                break

        # Dateien kopieren
        for item in os.listdir(extracted_root):
            src = os.path.join(extracted_root, item)
            dst = os.path.join(app_dir, item)
            if os.path.isdir(src):
                if os.path.exists(dst):
                    shutil.rmtree(dst, ignore_errors=True)
                shutil.copytree(src, dst)
            else:
                shutil.copy2(src, dst)

        if progress_callback:
            progress_callback(95, "Aufräumen…")

        # Lokale version.txt auf neue Version aktualisieren
        remote_ver = get_remote_version()
        if remote_ver:
            try:
                with open(LOCAL_VERSION_FILE, "w") as f:
                    f.write(remote_ver + "\n")
            except Exception:
                pass

        if getattr(sys, 'frozen', False):
            # EXE-Modus: Hilfsprogramm starten das nach Beenden der EXE die Dateien ersetzt
            helper = os.path.join(app_dir, "kvdt_update_helper.exe")
            if not os.path.exists(helper):
                # Fallback: Python-Script
                helper_py = os.path.join(app_dir, "kvdt_update_helper.py")
                if os.path.exists(helper_py):
                    helper = f'pythonw "{helper_py}"'

            exe_path = sys.executable
            if os.path.exists(helper):
                subprocess.Popen([helper, tmp_zip, app_dir, exe_path])
            else:
                # Kein Helper – direkt installieren und Neustart
                shutil.rmtree(tmp_extract, ignore_errors=True)
                os.remove(tmp_zip)

            if progress_callback:
                progress_callback(100, "Update abgeschlossen!")
            return True, (
                "Update heruntergeladen!\n\n"
                "Das Programm wird jetzt beendet und automatisch neu gestartet."
            )
        else:
            # Python-Skript-Modus: direkt ersetzen
            os.remove(tmp_zip)
            shutil.rmtree(tmp_extract, ignore_errors=True)

        if progress_callback:
            progress_callback(100, "Update abgeschlossen!")

        return True, "Update erfolgreich installiert!\nBitte das Programm neu starten."

    except urllib.error.HTTPError as e:
        return False, f"Download-Fehler: HTTP {e.code}\nUpdate-Datei nicht gefunden."
    except urllib.error.URLError as e:
        return False, f"Verbindungsfehler: {e.reason}"
    except Exception as e:
        return False, f"Fehler beim Update: {e}"
