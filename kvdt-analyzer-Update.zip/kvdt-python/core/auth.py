# core/auth.py – Benutzerverwaltung mit Passwortschutz
import hashlib, json, os

def _users_file() -> str:
    from .settings import get_shared_dir
    return os.path.join(get_shared_dir(), ".kvdt_users.json")

def _bsnr_file() -> str:
    from .settings import get_shared_dir
    return os.path.join(get_shared_dir(), ".kvdt_bsnr.json")

# Abwärtskompatibilität
USERS_FILE = os.path.join(os.path.expanduser("~"), ".kvdt_users.json")
BSNR_FILE  = os.path.join(os.path.expanduser("~"), ".kvdt_bsnr.json")

# Admin-Konto – unveränderlich
ADMIN_USER = "admin"
ADMIN_HASH = hashlib.sha256("smoelli69".encode()).hexdigest()


def _hash(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()


# ── BSNR-Verwaltung ───────────────────────────────────────────────────────────

def get_registered_bsnr() -> str:
    """Gibt die registrierte BSNR zurück oder '' wenn noch keine."""
    BSNR_FILE = _bsnr_file()
    if os.path.exists(BSNR_FILE):
        try:
            with open(BSNR_FILE) as f:
                return json.load(f).get("bsnr", "")
        except Exception:
            pass
    return ""


def register_bsnr(bsnr: str, admin_password: str) -> str:
    """Registriert BSNR nach Admin-Passwort-Bestätigung.
    Gibt '' bei Erfolg, Fehlermeldung bei Fehler zurück."""
    if not bsnr or not bsnr.strip():
        return "Keine gültige BSNR übergeben."
    if _hash(admin_password) != ADMIN_HASH:
        return "Admin-Passwort ist falsch."
    existing = get_registered_bsnr()
    if existing:
        return f"Es ist bereits eine BSNR registriert: {existing}"
    BSNR_FILE = _bsnr_file()
    with open(BSNR_FILE, "w") as f:
        json.dump({"bsnr": bsnr.strip()}, f)
    return ""


def is_bsnr_registered() -> bool:
    return bool(get_registered_bsnr())


def bsnr_matches(bsnr: str) -> bool:
    """Prüft ob die übergebene BSNR zur registrierten passt."""
    registered = get_registered_bsnr()
    if not registered:
        return True  # Noch nicht registriert – Erstregistrierung nötig
    return bsnr.strip() == registered


def load_users() -> dict:
    """Gibt {username: pw_hash} zurück. Admin immer enthalten."""
    users = {ADMIN_USER: ADMIN_HASH}
    USERS_FILE = _users_file()
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, "r") as f:
                saved = json.load(f)
            for name, h in saved.items():
                if name != ADMIN_USER:
                    users[name] = h
        except Exception:
            pass
    return users


def save_users(users: dict):
    """Speichert Benutzer (ohne Admin)."""
    to_save = {k: v for k, v in users.items() if k != ADMIN_USER}
    USERS_FILE = _users_file()
    with open(USERS_FILE, "w") as f:
        json.dump(to_save, f, indent=2)


def verify(username: str, password: str) -> bool:
    users = load_users()
    return users.get(username.strip().lower()) == _hash(password)


def add_user(username: str, password: str) -> str:
    """Legt Benutzer an. Gibt Fehlermeldung zurück oder '' bei Erfolg."""
    username = username.strip().lower()
    if not username or not password:
        return "Benutzername und Passwort dürfen nicht leer sein."
    if username == ADMIN_USER:
        return "Der Benutzername 'admin' ist reserviert."
    if len(password) < 4:
        return "Passwort muss mindestens 4 Zeichen haben."
    users = load_users()
    users[username] = _hash(password)
    save_users(users)
    return ""


def change_password(username: str, old_pw: str, new_pw: str) -> str:
    username = username.strip().lower()
    if username == ADMIN_USER:
        return "Das Admin-Passwort kann nicht geändert werden."
    if not verify(username, old_pw):
        return "Altes Passwort ist falsch."
    if len(new_pw) < 4:
        return "Neues Passwort muss mindestens 4 Zeichen haben."
    users = load_users()
    users[username] = _hash(new_pw)
    save_users(users)
    return ""


def delete_user(username: str) -> str:
    username = username.strip().lower()
    if username == ADMIN_USER:
        return "Der Admin-Account kann nicht gelöscht werden."
    users = load_users()
    if username not in users:
        return f"Benutzer '{username}' nicht gefunden."
    del users[username]
    save_users(users)
    return ""


def list_users() -> list:
    """Gibt alle Benutzernamen zurück."""
    return sorted(load_users().keys())
