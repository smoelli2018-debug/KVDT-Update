# core/session.py – Zentrale Datenverwaltung
import json, os
from typing import Optional
from .parser import Quartal, load_kvdt_file, sort_quarter_key

COLORS = ["#3b82f6","#8b5cf6","#10b981","#f59e0b","#ef4444","#06b6d4"]
def _session_file(username: str = "default") -> str:
    from .settings import get_session_file
    return get_session_file(username)

SESSION_FILE = os.path.join(os.path.expanduser("~"), ".kvdt_session.json")


class Session:
    def __init__(self, username: str = "default"):
        self.username = username
        self.quarters: list[Quartal] = []
        self._raw: list[dict] = []
        self._bsnr: Optional[str] = None
        self._praxisname: str = ""

    def color(self, idx: int) -> str:
        return COLORS[idx % len(COLORS)]

    def add_file(self, filename: str, text: str) -> Optional[str]:
        """Lädt eine KVDT-Datei. Gibt Fehlermeldung zurück oder None.
        Sonderfall 'BSNR_REGISTER_NEEDED': erste Datei, BSNR muss registriert werden."""
        if any(r["filename"] == filename for r in self._raw):
            return None  # Duplikat – still ignorieren

        q, bsnr, praxisname, err = load_kvdt_file(filename, text)
        if err:
            return err

        if praxisname and not self._praxisname:
            self._praxisname = praxisname

        # BSNR-Prüfung gegen registrierte BSNR
        from .auth import is_bsnr_registered, bsnr_matches, get_registered_bsnr
        if bsnr:
            if not is_bsnr_registered():
                # Erste Datei – Registrierung erforderlich
                # Datei zwischenspeichern, Signal zurückgeben
                self._pending_bsnr = bsnr
                self._pending_file = {"filename": filename, "text": text, "q": q}
                return f"BSNR_REGISTER_NEEDED:{bsnr}"
            elif not bsnr_matches(bsnr):
                registered = get_registered_bsnr()
                return (f"BSNR-Konflikt!\n\n"
                        f"Registrierte Praxis:  BSNR {registered}\n"
                        f"Diese Datei:          BSNR {bsnr}  ({os.path.basename(filename)})\n\n"
                        f"Nur Dateien der registrierten Praxis werden akzeptiert.")

        # Session-interne BSNR-Prüfung
        if bsnr and self._bsnr and bsnr != self._bsnr:
            return (f"BSNR-Konflikt!\n\n"
                    f"Bereits geladen:  BSNR {self._bsnr}\n"
                    f"Neue Datei:       BSNR {bsnr}  ({os.path.basename(filename)})\n\n"
                    f"Bitte nur Dateien derselben Praxis laden.")
        if bsnr and not self._bsnr:
            self._bsnr = bsnr

        self._raw.append({"filename": filename, "text": text})
        self._rebuild()
        return None

    def confirm_bsnr_and_add(self) -> Optional[str]:
        """Nach erfolgreicher BSNR-Registrierung die ausstehende Datei hinzufügen."""
        if not hasattr(self, '_pending_file') or not self._pending_file:
            return "Keine ausstehende Datei."
        pending = self._pending_file
        self._pending_file = None
        bsnr = getattr(self, '_pending_bsnr', None)
        if bsnr and not self._bsnr:
            self._bsnr = bsnr
        self._raw.append({"filename": pending["filename"], "text": pending["text"]})
        self._rebuild()
        return None

    def remove_quarter(self, idx: int):
        label = self.quarters[idx].label
        self._raw = [r for r in self._raw
                     if not any(q.label == label and q.filename == r["filename"]
                                for q in self.quarters)]
        self._rebuild()

    def _rebuild(self):
        from .parser import parse_kvdt, split_records, is_patient_record, \
            extract_patient, extract_quarter_label
        quarters = []
        for raw in self._raw:
            fields = parse_kvdt(raw["text"])
            records = split_records(fields)
            label = extract_quarter_label(records, raw["filename"])
            patients = [extract_patient(r) for r in records if is_patient_record(r)]
            quarters.append(Quartal(label=label, filename=raw["filename"],
                                    patients=patients))
        quarters.sort(key=lambda q: sort_quarter_key(q.label))
        self.quarters = quarters

    def clear(self):
        self.quarters = []
        self._raw = []
        self._bsnr = None

    # ── Persistenz ────────────────────────────────────────────────────────────
    def save(self):
        try:
            data = {"bsnr": self._bsnr,
                    "files": [{"filename": r["filename"], "text": r["text"]}
                               for r in self._raw]}
            sf = _session_file(self.username)
            with open(sf, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False)
            return True
        except Exception:
            return False

    def load(self) -> bool:
        try:
            sf = _session_file(self.username)
            if not os.path.exists(sf):
                return False
            with open(sf, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.clear()
            self._bsnr = data.get("bsnr")
            for item in data.get("files", []):
                self._raw.append(item)
            self._rebuild()
            return bool(self.quarters)
        except Exception:
            return False

    def export_json(self, path: str):
        import datetime
        data = {"savedAt": datetime.datetime.now().isoformat(),
                "files": self._raw}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def import_json(self, path: str) -> Optional[str]:
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not data.get("files"):
                return "Keine Dateien in der Session gefunden."
            self.clear()
            for item in data["files"]:
                err = self.add_file(item["filename"], item["text"])
                if err:
                    return err
            return None
        except Exception as e:
            return str(e)
