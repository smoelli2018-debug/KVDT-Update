"""
lizenzpruefung.py – Lizenzprüfung via GitHub
Datei auf GitHub leeren oder löschen um das Programm zu sperren.
"""
import sys
import urllib.request
import urllib.error

LICENSE_URL      = "https://raw.githubusercontent.com/smoelli2018-debug/KVDT/main/Lizenz_0001.txt"
LICENSE_FILENAME = "Lizenz_0001.txt"

# Erwarteter Inhalt der Lizenzdatei (muss exakt übereinstimmen)
LICENSE_TOKEN    = "a"


def lizenz_vorhanden() -> bool:
    """
    True  = Datei vorhanden und nicht leer
    False = Datei fehlt, leer oder kein Internet
    """
    import os, datetime
    log = os.path.join(os.path.expanduser("~"), "kvdt_lizenz_debug.txt")
    try:
        import time
        url = f"{LICENSE_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Cache-Control": "no-cache, no-store, must-revalidate",
                "Pragma": "no-cache",
                "Expires": "0",
            },
        )
        r = urllib.request.urlopen(req, timeout=10)
        raw = r.read()
        content = raw.decode("utf-8", errors="replace").strip()
        # Nur Zeilenumbrüche zählen nicht als gültige Lizenz
        result = len(content) > 0
        with open(log, "a") as f:
            f.write(f"{datetime.datetime.now()} OK raw={repr(raw[:50])} content={repr(content)} result={result}\n")
        return result
    except Exception as e:
        with open(log, "a") as f:
            f.write(f"{datetime.datetime.now()} FEHLER: {type(e).__name__}: {e}\n")
        return False


if __name__ == "__main__":
    print("Prüfe Lizenz...")
    result = lizenz_vorhanden()
    print(f"Lizenz {'OK' if result else 'NICHT gefunden'}.")
    input("Enter zum Beenden...")
