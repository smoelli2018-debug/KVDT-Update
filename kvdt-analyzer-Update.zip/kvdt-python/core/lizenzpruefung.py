"""
lizenzpruefung.py – Lizenzprüfung via GitHub (Dateiname als Schlüssel)

Funktionsweise:
- Der erwartete Dateiname ist in LICENSE_FILENAME gespeichert
- Beim Start wird geprüft ob diese Datei im GitHub-Repository vorhanden ist
- Jede Installation bekommt einen eigenen Dateinamen (z.B. Lizenz_Praxis_Muster.txt)
- Sperren: Datei auf GitHub löschen oder umbenennen
- Freischalten: Datei mit dem vereinbarten Namen anlegen (Inhalt egal)

Neuen Lizenznamen setzen: LICENSE_FILENAME unten ändern
"""
import sys
import os
import time
import urllib.request
import urllib.error

# ── Konfiguration ─────────────────────────────────────────────────────────────
GITHUB_REPO    = "smoelli2018-debug/KVDT"
GITHUB_BRANCH  = "main"
LICENSE_FILENAME = "Lizenz_0001.txt"   # ← Hier den Dateinamen der Lizenz eintragen

# GitHub API URL – prüft ob Datei existiert (zuverlässiger als raw)
LICENSE_API_URL = (
    f"https://api.github.com/repos/{GITHUB_REPO}/contents/{LICENSE_FILENAME}"
    f"?ref={GITHUB_BRANCH}"
)
# Fallback: raw URL
LICENSE_RAW_URL = (
    f"https://raw.githubusercontent.com/{GITHUB_REPO}/{GITHUB_BRANCH}/{LICENSE_FILENAME}"
)

LOG_FILE = os.path.join(os.path.expanduser("~"), "kvdt_lizenz_debug.txt")


def _log(msg: str):
    try:
        import datetime
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"{datetime.datetime.now()} {msg}\n")
    except Exception:
        pass


def lizenz_vorhanden() -> bool:
    """
    Prüft ob die Lizenzdatei mit dem konfigurierten Namen auf GitHub existiert.
    True  = Datei vorhanden → Programm startet
    False = Datei nicht gefunden oder kein Internet → Programm gesperrt
    """
    # Methode 1: GitHub API (prüft Existenz zuverlässig, kein Cache)
    try:
        url = f"{LICENSE_API_URL}&t={int(time.time())}"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "KVDT-Analyzer/1.0",
                "Accept": "application/vnd.github.v3+json",
                "Cache-Control": "no-cache",
            }
        )
        r = urllib.request.urlopen(req, timeout=10)
        data = r.read()
        # HTTP 200 = Datei existiert
        _log(f"OK (API) Datei='{LICENSE_FILENAME}' gefunden")
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            _log(f"GESPERRT (API) Datei='{LICENSE_FILENAME}' nicht gefunden (404)")
            return False
        # Bei anderen HTTP-Fehlern (403 Rate-Limit etc.) → Fallback
        _log(f"API Fehler {e.code} – versuche Fallback")
    except Exception as e:
        _log(f"API Fehler: {type(e).__name__}: {e} – versuche Fallback")

    # Methode 2: Fallback via raw.githubusercontent.com
    try:
        url = f"{LICENSE_RAW_URL}?t={int(time.time())}"
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Cache-Control": "no-cache, no-store",
            }
        )
        r = urllib.request.urlopen(req, timeout=10)
        r.read()  # Inhalt ignorieren – nur Existenz prüft
        _log(f"OK (raw) Datei='{LICENSE_FILENAME}' gefunden")
        return True
    except urllib.error.HTTPError as e:
        if e.code == 404:
            _log(f"GESPERRT (raw) Datei='{LICENSE_FILENAME}' nicht gefunden (404)")
        else:
            _log(f"raw Fehler {e.code}")
        return False
    except Exception as e:
        _log(f"raw Fehler: {type(e).__name__}: {e}")
        return False


def check_license(mit_fenster: bool = True) -> None:
    if lizenz_vorhanden():
        return
    meldung = (
        f"Lizenz nicht gefunden.\n\n"
        f"Die Lizenzdatei '{LICENSE_FILENAME}' wurde nicht gefunden.\n\n"
        "Das Programm wird beendet."
    )
    if mit_fenster:
        try:
            import tkinter as tk
            from tkinter import messagebox
            _root = tk.Tk(); _root.withdraw()
            messagebox.showerror("Lizenz nicht gefunden", meldung)
            _root.destroy()
        except Exception:
            print(f"[Lizenz] {meldung}")
    else:
        print(f"[Lizenz] {meldung}")
    sys.exit(1)


if __name__ == "__main__":
    print(f"Prüfe Lizenz: '{LICENSE_FILENAME}'")
    if lizenz_vorhanden():
        print("✓ Lizenz OK.")
    else:
        print("✗ Lizenz NICHT gefunden.")
    input("Enter zum Beenden...")
