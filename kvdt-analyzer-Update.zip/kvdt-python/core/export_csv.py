# core/export_csv.py – CSV Export (kein externes Package nötig)
import csv, os
from collections import Counter
from core.parser import EBM_BEZEICHNUNG, EBM_PUNKTE, get_punktwert


def export_csv(session, base_path: str):
    """Exportiert mehrere CSV-Dateien in einen Ordner."""
    # Basis ohne Erweiterung
    stem = base_path.replace(".csv","")
    os.makedirs(stem + "_csvs", exist_ok=True)
    out = stem + "_csvs"

    qs = session.quarters

    def w(filename, headers, rows):
        path = os.path.join(out, filename)
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            writer = csv.writer(f, delimiter=";")
            writer.writerow(headers)
            writer.writerows(rows)

    q_labels = [q.label for q in qs]

    # ── 1. Quartal-Vergleich ──────────────────────────────────────────────────
    rows = []
    for q in qs:
        ebm  = sum(len(p.ebm_codes) for p in q.patients)
        diag = sum(len(p.diag_akut)+len(p.diag_dauer) for p in q.patients)
        rows.append([q.label, q.patient_count, ebm,
                     round(ebm/q.patient_count,1) if q.patient_count else 0,
                     diag,
                     sum(1 for p in q.patients if p.sex=="M"),
                     sum(1 for p in q.patients if p.sex=="W")])
    w("01_quartal_vergleich.csv",
      ["Quartal","Patienten","EBM-Leistungen","EBM/Patient","Diagnosen","Männlich","Weiblich"],
      rows)

    # ── 2. EBM-Leistungen ────────────────────────────────────────────────────
    per_q = []
    for q in qs:
        c = Counter()
        for p in q.patients:
            for e in p.ebm_entries: c[e.code] += e.mult
        per_q.append(c)
    all_codes = sorted({c for cnt in per_q for c in cnt},
                       key=lambda c: -sum(cnt[c] for cnt in per_q))
    rows = []
    for code in all_codes:
        vals = [cnt.get(code,0) for cnt in per_q]
        rows.append([code, EBM_BEZEICHNUNG.get(code,""), *vals, sum(vals)])
    w("02_ebm_leistungen.csv",
      ["EBM-Ziffer","Bezeichnung"] + q_labels + ["Gesamt"], rows)

    # ── 3. Diagnosen ─────────────────────────────────────────────────────────
    dq = []
    for q in qs:
        c = Counter()
        for p in q.patients:
            for d in p.diag_akut + p.diag_dauer: c[d.code] += 1
        dq.append(c)
    all_diag = sorted({c for cnt in dq for c in cnt},
                      key=lambda c: -sum(cnt[c] for cnt in dq))
    rows = [[code]+[cnt.get(code,0) for cnt in dq]+[sum(cnt.get(code,0) for cnt in dq)]
            for code in all_diag]
    w("03_diagnosen.csv", ["ICD-10"] + q_labels + ["Gesamt"], rows)

    # ── 4. Chroniker ─────────────────────────────────────────────────────────
    rows = []
    for q in qs:
        ch = [p for p in q.patients if p.is_chroniker()]
        quote = round(len(ch)/q.patient_count*100,1) if q.patient_count else 0
        rows.append([q.label, len(ch), f"{quote}%",
                     sum(1 for p in ch if len(p.diag_dauer)>=3),
                     sum(1 for p in ch if "03220" in p.ebm_codes),
                     sum(1 for p in ch if "03221" in p.ebm_codes),
                     round(sum(len(p.diag_dauer) for p in ch)/len(ch),1) if ch else 0])
    w("04_chroniker.csv",
      ["Quartal","Chroniker","Quote","Multimorbid","EBM 03220","EBM 03221","∅ DD"],
      rows)

    # ── 5. Honorar ────────────────────────────────────────────────────────────
    rows = []
    for q in qs:
        pw = get_punktwert(q.label)
        total_p = sum(EBM_PUNKTE.get(e.code,0)*e.mult
                      for p in q.patients for e in p.ebm_entries)
        total_e = total_p * pw
        rows.append([q.label, round(total_p), round(total_e,2),
                     round(total_p/q.patient_count) if q.patient_count else 0,
                     round(total_e/q.patient_count,2) if q.patient_count else 0,
                     round(pw*100,4)])
    w("05_honorar.csv",
      ["Quartal","Gesamtpunkte","Honorar (€)","∅ Punkte/Pat","∅ Honorar/Pat","Punktwert (Ct)"],
      rows)

    return out
