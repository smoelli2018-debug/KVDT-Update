# core/export_xlsx.py
from collections import Counter, defaultdict
from core.parser import EBM_BEZEICHNUNG, EBM_PUNKTE, get_punktwert


def export_xlsx(session, path: str):
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        raise ImportError("openpyxl ist nicht installiert.\nBitte: pip install openpyxl")

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    qs = session.quarters
    q_labels = [q.label for q in qs]

    HDR_FILL  = PatternFill("solid", fgColor="1F4E79")
    HDR_FONT  = Font(bold=True, color="FFFFFF", name="Calibri", size=10)
    EVEN_FILL = PatternFill("solid", fgColor="F2F2F2")
    NORM_FONT = Font(name="Calibri", size=10)
    HDR_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)
    CELL_ALIGN= Alignment(vertical="center")
    thin = Side(style="thin", color="CCCCCC")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    def style_sheet(ws, col_widths):
        for i, w in enumerate(col_widths, 1):
            ws.column_dimensions[get_column_letter(i)].width = w
        for row in ws.iter_rows():
            for cell in row:
                cell.border = border
                if cell.row == 1:
                    cell.fill     = HDR_FILL
                    cell.font     = HDR_FONT
                    cell.alignment= HDR_ALIGN
                else:
                    cell.font     = NORM_FONT
                    cell.alignment= CELL_ALIGN
                    if cell.row % 2 == 0:
                        cell.fill = EVEN_FILL
        ws.freeze_panes = "A2"
        ws.row_dimensions[1].height = 30

    # ── 1. Quartal-Vergleich ──────────────────────────────────────────────────
    ws = wb.create_sheet("Quartal-Vergleich")
    headers = ["Kennzahl"] + q_labels
    ws.append(headers)
    stats = []
    for q in qs:
        ebm  = sum(len(p.ebm_codes) for p in q.patients)
        diag = sum(len(p.diag_akut)+len(p.diag_dauer) for p in q.patients)
        m    = sum(1 for p in q.patients if p.sex=="M")
        w2   = sum(1 for p in q.patients if p.sex=="W")
        stats.append(dict(pat=q.patient_count,ebm=ebm,diag=diag,m=m,w=w2))
    for label, key in [("Patienten","pat"),("EBM-Leistungen","ebm"),
                        ("Diagnosen","diag"),("Männlich","m"),("Weiblich","w")]:
        ws.append([label] + [s[key] for s in stats])
    style_sheet(ws, [24]+[14]*len(qs))

    # ── 2. EBM-Leistungen ────────────────────────────────────────────────────
    ws = wb.create_sheet("EBM-Leistungen")
    per_q = []
    for q in qs:
        c = Counter()
        for p in q.patients:
            for e in p.ebm_entries: c[e.code] += e.mult
        per_q.append(c)
    all_codes = sorted({c for cnt in per_q for c in cnt},
                       key=lambda c: -sum(cnt[c] for cnt in per_q))
    ws.append(["EBM-Ziffer","Bezeichnung"] + q_labels + ["Gesamt"])
    for code in all_codes:
        vals = [cnt.get(code,0) for cnt in per_q]
        ws.append([code, EBM_BEZEICHNUNG.get(code,""), *vals, sum(vals)])
    style_sheet(ws, [10,34]+[12]*len(qs)+[12])

    # ── 3. Diagnosen ─────────────────────────────────────────────────────────
    ws = wb.create_sheet("Diagnosen")
    dq = []
    for q in qs:
        c = Counter()
        for p in q.patients:
            for d in p.diag_akut+p.diag_dauer: c[d.code] += 1
        dq.append(c)
    all_diag = sorted({c for cnt in dq for c in cnt},
                      key=lambda c: -sum(cnt[c] for cnt in dq))
    ws.append(["ICD-10"] + q_labels + ["Gesamt"])
    for code in all_diag:
        vals = [cnt.get(code,0) for cnt in dq]
        ws.append([code, *vals, sum(vals)])
    style_sheet(ws, [12]+[12]*len(qs)+[12])

    # ── 4. Chroniker ─────────────────────────────────────────────────────────
    ws = wb.create_sheet("Chroniker")
    ws.append(["Kennzahl"] + q_labels)
    ch_stats = []
    for q in qs:
        ch = [p for p in q.patients if p.is_chroniker()]
        quote = f"{len(ch)/q.patient_count*100:.1f}%" if q.patient_count else "—"
        mm  = sum(1 for p in ch if len(p.diag_dauer)>=3)
        p1  = sum(1 for p in ch if "03220" in p.ebm_codes)
        p2  = sum(1 for p in ch if "03221" in p.ebm_codes)
        avg = sum(len(p.diag_dauer) for p in ch)/len(ch) if ch else 0
        ch_stats.append(dict(n=len(ch),quote=quote,mm=mm,p1=p1,p2=p2,avg=avg))
    for label, key in [("Chroniker gesamt","n"),("Quote (%)","quote"),
                        ("Multimorbid (≥3 DD)","mm"),("EBM 03220","p1"),
                        ("EBM 03221","p2"),("∅ Dauerdiagnosen","avg")]:
        ws.append([label] + [s[key] for s in ch_stats])
    style_sheet(ws, [24]+[14]*len(qs))

    # ── 5. Honorar ────────────────────────────────────────────────────────────
    ws = wb.create_sheet("Honorar")
    ws.append(["Kennzahl"] + q_labels)
    h_data = []
    for q in qs:
        pw = get_punktwert(q.label)
        total_p = sum(EBM_PUNKTE.get(e.code,0)*e.mult
                      for p in q.patients for e in p.ebm_entries)
        total_e = total_p * pw
        avg_p   = total_p / q.patient_count if q.patient_count else 0
        h_data.append(dict(p=total_p,e=total_e,avg_p=avg_p,pw=pw))
    for label, fn in [
        ("Gesamtpunkte",        lambda h: round(h["p"])),
        ("Geschätztes Honorar", lambda h: round(h["e"],2)),
        ("∅ Punkte/Patient",    lambda h: round(h["avg_p"])),
        ("Punktwert (Ct)",      lambda h: round(h["pw"]*100,4)),
    ]:
        ws.append([label] + [fn(h) for h in h_data])
    style_sheet(ws, [28]+[16]*len(qs))

    wb.save(path)
