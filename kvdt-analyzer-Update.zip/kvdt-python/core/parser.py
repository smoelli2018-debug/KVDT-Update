# core/parser.py – KVDT Datei-Parser
from dataclasses import dataclass, field
from typing import Optional
import re, os

# ── EBM-Bezeichnungen ────────────────────────────────────────────────────────
# EBM-Daten werden aus ebm_data.py importiert
# Zum Update: python tools/ebm_updater.py
from .ebm_data import EBM_BEZEICHNUNG, EBM_PUNKTE

def resolve_ebm_code(code: str) -> str:
    """Löst Alias-Codes auf Basis-GOPs auf (z.B. 01715T -> 01715)."""
    if code in EBM_PUNKTE:
        return code
    base = re.sub(r'[A-Z]+$', '', code)
    if base != code and base in EBM_PUNKTE:
        return base
    return code

# ── Orientierungspunktwerte (Cent/Punkt) ──────────────────────────────────────
PUNKTWERT = {2021:10.9085,2022:11.1439,2023:11.4915,2024:11.9339,
             2025:12.3934,2026:12.7404}

def get_punktwert(quarter_label: str) -> float:
    m = re.search(r'(\d{4})', quarter_label)
    jahr = int(m.group(1)) if m else 2025
    return PUNKTWERT.get(jahr, PUNKTWERT[2025]) / 100.0


@dataclass
class Diagnose:
    code: str
    typ: str  # 'akut' | 'dauer'
    sig: str = "G"


@dataclass
class EBMEntry:
    code: str
    mult: int = 1


@dataclass
class Patient:
    name: str
    dob: str
    sex: str
    kasse: str
    ebm_entries: list = field(default_factory=list)
    diag_akut: list = field(default_factory=list)
    diag_dauer: list = field(default_factory=list)

    @property
    def ebm_codes(self):
        return [e.code for e in self.ebm_entries]

    @property
    def key(self):
        return f"{self.name}|{self.dob}".lower().strip()

    def is_chroniker(self):
        return (bool(self.diag_dauer) or
                "03220" in self.ebm_codes or
                "03221" in self.ebm_codes)

    def punkte(self, pw: float):
        return sum(EBM_PUNKTE.get(e.code, 0) * e.mult
                   for e in self.ebm_entries)

    def honorar(self, pw: float):
        return self.punkte(pw) * pw


@dataclass
class Quartal:
    label: str
    filename: str
    patients: list = field(default_factory=list)

    @property
    def patient_count(self):
        return len(self.patients)

    @property
    def ebm_count(self):
        return sum(len(p.ebm_codes) for p in self.patients)


def parse_kvdt(text: str) -> list:
    fields = []
    for i, line in enumerate(text.splitlines()):
        if len(line) < 7:
            continue
        fid = line[3:7]
        if not fid.isdigit():
            continue
        try:
            length = int(line[:3])
        except ValueError:
            continue
        value = line[7:]
        fields.append({"fid": fid, "value": value, "line": i+1})
    return fields


def split_records(fields: list) -> list:
    records, cur = [], None
    for f in fields:
        if f["fid"] == "8000":
            if cur:
                records.append(cur)
            cur = {"type": f["value"].strip(), "fields": [f]}
        else:
            if cur is None:
                cur = {"type": "(header)", "fields": []}
            cur["fields"].append(f)
    if cur:
        records.append(cur)
    return records


def is_patient_record(rec: dict) -> bool:
    ids = {f["fid"] for f in rec["fields"]}
    return bool(ids & {"3101", "3102", "3103", "3110"})


def extract_patient(rec: dict) -> Patient:
    def g(fid):
        f = next((x for x in rec["fields"] if x["fid"] == fid), None)
        return f["value"].strip() if f else ""

    name_parts = [g("3101"), g("3102")]
    name = ", ".join(p for p in name_parts if p) or "(unbekannt)"
    dob   = g("3103")
    sex   = g("3110")
    kasse = g("4134") or g("4124") or g("4112") or ""

    diag_akut, diag_dauer = [], []
    ebm_entries = []
    last_diag = None
    last_ebm  = None

    for f in rec["fields"]:
        fid, val = f["fid"], f["value"].strip()
        if fid == "6001":
            last_diag = Diagnose(code=val, typ="akut")
            diag_akut.append(last_diag)
        elif fid == "3673":
            last_diag = Diagnose(code=val, typ="dauer")
            diag_dauer.append(last_diag)
        elif fid in ("6003","3674") and last_diag:
            last_diag.sig = val
        elif fid == "5001":
            last_ebm = EBMEntry(code=val)
            ebm_entries.append(last_ebm)
            last_diag = None
        elif fid == "5002" and last_ebm:
            try:
                m = int(val)
                if m > 0:
                    last_ebm.mult = m
            except ValueError:
                pass
        elif fid not in ("5009","5011","5012","5013","5015","5016","5017","5018","5019"):
            last_ebm = None
            if fid not in ("6003","3674"):
                last_diag = None

    return Patient(name=name, dob=dob, sex=sex, kasse=kasse,
                   ebm_entries=ebm_entries,
                   diag_akut=diag_akut, diag_dauer=diag_dauer)


def extract_quarter_label(records: list, filename: str) -> str:
    all_fields = [f for r in records for f in r["fields"]]
    def g(fid):
        f = next((x for x in all_fields if x["fid"] == fid), None)
        return f["value"].strip() if f else ""

    q, y = g("0109"), g("0108")
    if q and y:
        return f"Q{q}/{y}"
    f0250 = g("0250")
    if f0250 and len(f0250) >= 5:
        return f"Q{f0250[4]}/{f0250[:4]}"

    fn = os.path.basename(filename).upper()
    patterns = [
        r'Q([1-4])_?(\d{4})', r'(\d{4})_?Q([1-4])',
        r'CON_([1-4])(\d{4})', r'ADT_Q([1-4])_(\d{4})',
        r'(\d{1})(\d{4})(?:\.CON)?$',
    ]
    for pat in patterns:
        m = re.search(pat, fn)
        if m:
            g1, g2 = m.group(1), m.group(2)
            if len(g1) == 4:
                return f"Q{g2}/{g1}"
            return f"Q{g1}/{g2}"

    return filename.split(".")[0]


def sort_quarter_key(label: str):
    m = re.match(r'Q(\d)/(\d{4})', label)
    if m:
        return int(m.group(2)) * 10 + int(m.group(1))
    return 0


def extract_bsnr(fields: list) -> Optional[str]:
    for fid in ("0201", "0111", "9102", "0212"):
        f = next((x for x in fields if x["fid"] == fid), None)
        if f:
            val = f["value"].strip()[:9]
            if val.isdigit() and len(val) >= 7:
                return val
    return None


def extract_praxisname(fields: list) -> str:
    """Liest den Praxisnamen aus Feld 0203."""
    f = next((x for x in fields if x["fid"] == "0203"), None)
    if f:
        return f["value"].strip()[:60]
    return ""


def load_kvdt_file(filename: str, text: str) -> tuple:
    fields = parse_kvdt(text)
    if not fields:
        return None, None, None, f"Keine gültigen KVDT-Felder in: {filename}"
    records = split_records(fields)
    label = extract_quarter_label(records, filename)
    patients = [extract_patient(r) for r in records if is_patient_record(r)]
    bsnr = extract_bsnr(fields)
    praxisname = extract_praxisname(fields)
    return Quartal(label=label, filename=filename, patients=patients), bsnr, praxisname, None
