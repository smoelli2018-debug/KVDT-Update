# core/settings.py – App-Einstellungen (persistent)
import json, os

SETTINGS_FILE = os.path.join(os.path.expanduser("~"), ".kvdt_settings.json")

DEFAULTS = {
    "ebm_url": "https://raw.githubusercontent.com/smoelli2018-debug/ebm_data/main/ebm_data.py",
    "ebm_auto_update": True,
    "ebm_update_interval_days": 7,
    "ebm_last_update": None,
    # Netzwerk-Modus
    "network_mode": False,          # True = Netzwerkordner aktiv
    "network_path": "",             # z.B. \\\\Server\\KVDT
}


def load() -> dict:
    s = dict(DEFAULTS)
    if os.path.exists(SETTINGS_FILE):
        try:
            with open(SETTINGS_FILE, "r") as f:
                saved = json.load(f)
            s.update(saved)
        except Exception:
            pass
    return s


def save(settings: dict):
    with open(SETTINGS_FILE, "w") as f:
        json.dump(settings, f, indent=2)


def get(key: str):
    return load().get(key, DEFAULTS.get(key))


def set(key: str, value):
    s = load()
    s[key] = value
    save(s)


def get_network_path() -> str:
    """Gibt den konfigurierten Netzwerkpfad zurück oder ''."""
    s = load()
    if s.get("network_mode") and s.get("network_path"):
        return s["network_path"].strip()
    return ""


def get_shared_dir() -> str:
    """Gibt den Pfad für gemeinsame Dateien zurück.
    Im Netzwerkmodus: Netzwerkpfad, sonst: lokaler Home-Ordner."""
    net = get_network_path()
    if net and os.path.isdir(net):
        return net
    return os.path.expanduser("~")


def get_session_file(username: str) -> str:
    """Session-Datei ist immer lokal (pro Nutzer)."""
    return os.path.join(os.path.expanduser("~"),
                        f".kvdt_session_{username}.json")
