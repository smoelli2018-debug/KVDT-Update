#!/usr/bin/env python3
"""
kvdt_update_helper.py – Hilfsprogramm für EXE-Updates
Wird von der Haupt-EXE aufgerufen und ersetzt die Dateien
nachdem die Haupt-EXE sich beendet hat.

Aufruf: python kvdt_update_helper.py <zip_path> <app_dir> <exe_path>
"""
import sys, os, time, shutil, zipfile, subprocess

def main():
    if len(sys.argv) < 4:
        print("Aufruf: kvdt_update_helper.py <zip> <app_dir> <exe>")
        sys.exit(1)

    zip_path = sys.argv[1]
    app_dir  = sys.argv[2]
    exe_path = sys.argv[3]

    # Warte bis Haupt-EXE beendet ist (max 10 Sekunden)
    for _ in range(20):
        try:
            if not os.path.exists(exe_path):
                break
            # Teste ob Datei gesperrt ist
            with open(exe_path, "ab"):
                break
        except PermissionError:
            time.sleep(0.5)

    time.sleep(1)  # Extra-Sicherheit

    try:
        # ZIP entpacken
        tmp_extract = zip_path + "_extract"
        if os.path.exists(tmp_extract):
            shutil.rmtree(tmp_extract, ignore_errors=True)

        with zipfile.ZipFile(zip_path, "r") as z:
            z.extractall(tmp_extract)

        # Unterordner finden
        extracted_root = tmp_extract
        for entry in os.listdir(tmp_extract):
            candidate = os.path.join(tmp_extract, entry)
            if os.path.isdir(candidate) and "kvdt" in entry.lower():
                extracted_root = candidate
                break

        # Dateien kopieren
        for item in os.listdir(extracted_root):
            src = os.path.join(extracted_root, item)
            dst = os.path.join(app_dir, item)
            try:
                if os.path.isdir(src):
                    if os.path.exists(dst):
                        shutil.rmtree(dst, ignore_errors=True)
                    shutil.copytree(src, dst)
                else:
                    shutil.copy2(src, dst)
            except Exception as e:
                print(f"Fehler bei {item}: {e}")

        # Aufräumen
        os.remove(zip_path)
        shutil.rmtree(tmp_extract, ignore_errors=True)

        # Haupt-EXE neu starten
        if os.path.exists(exe_path):
            subprocess.Popen([exe_path])

    except Exception as e:
        print(f"Update-Fehler: {e}")
        input("Enter zum Beenden...")

if __name__ == "__main__":
    main()
