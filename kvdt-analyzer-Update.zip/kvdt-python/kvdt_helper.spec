# kvdt_helper.spec – Build des Update-Hilfsprogramms
# Ausführen: pyinstaller kvdt_helper.spec
# Ergebnis: dist\kvdt_update_helper.exe

block_cipher = None

a = Analysis(
    ['kvdt_update_helper.py'],
    pathex=['.'],
    binaries=[],
    datas=[],
    hiddenimports=['zipfile', 'shutil', 'subprocess'],
    hookspath=[],
    runtime_hooks=[],
    excludes=['PyQt6', 'tkinter', 'numpy', 'pandas'],
    cipher=block_cipher,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='kvdt_update_helper',
    debug=False,
    strip=False,
    upx=False,
    console=True,   # Konsole für Fehlerausgabe
    cipher=block_cipher,
)
