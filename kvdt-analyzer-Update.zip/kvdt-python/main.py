#!/usr/bin/env python3
# main.py – KVDT Analyzer Einstiegspunkt
import sys
import traceback


def excepthook(exc_type, exc_value, exc_tb):
    msg = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))
    try:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        app = QApplication.instance() or QApplication(sys.argv)
        box = QMessageBox()
        box.setWindowTitle("KVDT Analyzer – Fehler")
        box.setIcon(QMessageBox.Icon.Critical)
        box.setText("Die Anwendung konnte nicht gestartet werden.")
        box.setDetailedText(msg)
        box.exec()
    except Exception:
        print(msg, file=sys.stderr)
    sys.exit(1)


sys.excepthook = excepthook


def main():
    from PyQt6.QtWidgets import QApplication, QMessageBox
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QFont

    app = QApplication(sys.argv)
    app.setApplicationName("KVDT Analyzer")
    app.setApplicationVersion("1.0.0")
    app.setOrganizationName("KVDT")
    app.setHighDpiScaleFactorRoundingPolicy(
        Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)

    font = QFont("Segoe UI", 10)
    app.setFont(font)

    # ── Lizenzprüfung ────────────────────────────────────────────────────────
    from core.lizenzpruefung import lizenz_vorhanden, LICENSE_FILENAME
    if not lizenz_vorhanden():
        box = QMessageBox()
        box.setWindowTitle("Lizenz nicht gefunden")
        box.setIcon(QMessageBox.Icon.Critical)
        box.setText(
            f"Die Lizenzdatei '{LICENSE_FILENAME}' wurde nicht gefunden.\n\n"
            "Das Programm wird beendet."
        )
        box.exec()
        sys.exit(1)
    # ─────────────────────────────────────────────────────────────────────────

    # ── EBM Auto-Update ──────────────────────────────────────────────────────
    try:
        from views.dialog_settings import check_auto_update
        check_auto_update()
    except Exception:
        pass
    # ─────────────────────────────────────────────────────────────────────────

    # ── Update-Prüfung ────────────────────────────────────────────────────────
    try:
        from views.dialog_update import check_for_updates
        check_for_updates(silent=True)  # Nur Dialog wenn Update vorhanden
    except Exception:
        pass
    # ─────────────────────────────────────────────────────────────────────────

    # Login-Dialog
    from views.dialogs_auth import LoginDialog
    from views.main_window import MainWindow

    login = LoginDialog()
    if login.exec() != LoginDialog.DialogCode.Accepted:
        sys.exit(0)

    window = MainWindow(current_user=login.logged_in_user)
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
