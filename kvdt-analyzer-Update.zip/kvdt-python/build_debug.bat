@echo off
echo ============================================
echo  KVDT Analyzer - DEBUG Build
echo ============================================
echo.

python -m pip install pyinstaller
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build

python -m PyInstaller --noconfirm --onedir --console --name "KVDT-Analyzer-Debug" ^
    --add-data "core;core" ^
    --add-data "views;views" ^
    --hidden-import PyQt6.QtCore ^
    --hidden-import PyQt6.QtGui ^
    --hidden-import PyQt6.QtWidgets ^
    --hidden-import PyQt6.sip ^
    --hidden-import core.parser ^
    --hidden-import core.ebm_data ^
    --hidden-import core.session ^
    --hidden-import core.auth ^
    --hidden-import core.settings ^
    --hidden-import core.lizenzpruefung ^
    --hidden-import core.export_xlsx ^
    --hidden-import core.export_csv ^
    --hidden-import views.main_window ^
    --hidden-import views.style ^
    --hidden-import views.base_tab ^
    --hidden-import views.tab_vergleich ^
    --hidden-import views.tab_ebm ^
    --hidden-import views.tab_diagnosen ^
    --hidden-import views.tab_chroniker ^
    --hidden-import views.tab_honorar ^
    --hidden-import views.dialogs_auth ^
    --hidden-import views.dialog_settings ^
    --exclude-module tkinter ^
    --exclude-module matplotlib ^
    --exclude-module numpy ^
    main.py

echo.
echo Starte Debug-EXE...
if exist "dist\KVDT-Analyzer-Debug\KVDT-Analyzer-Debug.exe" (
    dist\KVDT-Analyzer-Debug\KVDT-Analyzer-Debug.exe
) else (
    echo EXE nicht gefunden - Build fehlgeschlagen.
)
pause
