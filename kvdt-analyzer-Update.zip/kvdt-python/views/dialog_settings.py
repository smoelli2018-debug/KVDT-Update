# views/dialog_settings.py – Einstellungen & EBM-Download
import os, datetime, urllib.request, urllib.error, shutil
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QGroupBox, QFormLayout, QSpinBox, QCheckBox,
    QMessageBox, QProgressBar, QFrame
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal
import core.settings as settings

EBM_TARGET = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                           'core', 'ebm_data.py')


class DownloadWorker(QThread):
    done  = pyqtSignal(bool, str)  # success, message

    def __init__(self, url):
        super().__init__()
        self.url = url

    def run(self):
        try:
            # Konvertiere GitHub blob URL zu raw URL
            url = self.url.strip()
            if "github.com" in url and "/blob/" in url:
                url = url.replace("github.com", "raw.githubusercontent.com")
                url = url.replace("/blob/", "/")

            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Cache-Control": "no-cache",
                }
            )
            r = urllib.request.urlopen(req, timeout=30)
            content = r.read().decode("utf-8", errors="replace")

            # Validierung: muss EBM_BEZEICHNUNG und EBM_PUNKTE enthalten
            if "EBM_BEZEICHNUNG" not in content or "EBM_PUNKTE" not in content:
                self.done.emit(False, "Die heruntergeladene Datei enthält keine gültigen EBM-Daten.")
                return

            # Backup der alten Datei
            backup = EBM_TARGET + ".backup"
            if os.path.exists(EBM_TARGET):
                shutil.copy2(EBM_TARGET, backup)

            # Neue Datei schreiben
            with open(EBM_TARGET, "w", encoding="utf-8") as f:
                f.write(content)

            # Letztes Update-Datum speichern
            settings.set("ebm_last_update", datetime.datetime.now().isoformat())

            self.done.emit(True, f"ebm_data.py erfolgreich aktualisiert.\n{len(content)} Zeichen geladen.")

        except urllib.error.HTTPError as e:
            self.done.emit(False, f"HTTP-Fehler {e.code}: Datei nicht gefunden oder kein Zugriff.")
        except urllib.error.URLError as e:
            self.done.emit(False, f"Verbindungsfehler: {e.reason}")
        except Exception as e:
            self.done.emit(False, f"Fehler: {e}")


class SettingsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Einstellungen – KVDT Analyzer")
        self.setMinimumSize(560, 420)
        self.resize(600, 460)
        self.s = settings.load()
        self._build()

    def _build(self):
        L = QVBoxLayout(self)
        L.setContentsMargins(24, 20, 24, 20)
        L.setSpacing(14)

        title = QLabel("⚙  Einstellungen")
        title.setStyleSheet("font-size:17px; font-weight:bold; color:#1e3a5f;")
        L.addWidget(title)

        # ── EBM-Daten Update ──────────────────────────────────────────────────
        grp = QGroupBox("EBM-Daten automatisch aktualisieren")
        grp.setStyleSheet("QGroupBox { border:1px solid #e2e8f0; border-radius:8px; "
                          "margin-top:8px; padding:10px; font-weight:bold; }"
                          "QGroupBox::title { subcontrol-origin:margin; left:10px; }")
        grp_l = QFormLayout(grp)
        grp_l.setSpacing(10)

        # URL
        self.inp_url = QLineEdit(self.s.get("ebm_url", ""))
        self.inp_url.setMinimumHeight(30)
        self.inp_url.setPlaceholderText("https://raw.githubusercontent.com/...")
        grp_l.addRow("GitHub URL:", self.inp_url)

        # Auto-Update
        self.chk_auto = QCheckBox("Beim Programmstart automatisch prüfen")
        self.chk_auto.setChecked(self.s.get("ebm_auto_update", True))
        grp_l.addRow("", self.chk_auto)

        # Intervall
        self.spn_days = QSpinBox()
        self.spn_days.setMinimum(1)
        self.spn_days.setMaximum(365)
        self.spn_days.setValue(self.s.get("ebm_update_interval_days", 7))
        self.spn_days.setSuffix(" Tage")
        self.spn_days.setMinimumHeight(28)
        grp_l.addRow("Update-Intervall:", self.spn_days)

        # Letztes Update
        last = self.s.get("ebm_last_update")
        if last:
            try:
                dt = datetime.datetime.fromisoformat(last)
                last_str = dt.strftime("%d.%m.%Y %H:%M Uhr")
            except Exception:
                last_str = last
        else:
            last_str = "Noch nie"
        self.lbl_last = QLabel(f"Letztes Update: {last_str}")
        self.lbl_last.setStyleSheet("color:#64748b; font-size:12px;")
        grp_l.addRow("", self.lbl_last)

        L.addWidget(grp)

        # Fortschritt
        self.pb = QProgressBar()
        self.pb.setRange(0, 0)
        self.pb.hide()
        L.addWidget(self.pb)

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color:#64748b; font-size:12px;")
        self.lbl_status.setWordWrap(True)
        L.addWidget(self.lbl_status)

        L.addStretch()

        # ── Netzwerk-Modus ────────────────────────────────────────────────────────
        grp_net = QGroupBox("Mehrbenutzer-Modus (Netzwerkordner)")
        grp_net.setStyleSheet("QGroupBox { border:1px solid #e2e8f0; border-radius:8px; "
                              "margin-top:8px; padding:10px; font-weight:bold; }"
                              "QGroupBox::title { subcontrol-origin:margin; left:10px; }")
        net_l = QFormLayout(grp_net)
        net_l.setSpacing(10)

        self.chk_network = QCheckBox("Netzwerkordner verwenden")
        self.chk_network.setChecked(self.s.get("network_mode", False))
        self.chk_network.toggled.connect(self._toggle_network)
        net_l.addRow("", self.chk_network)

        self.inp_network = QLineEdit(self.s.get("network_path", ""))
        self.inp_network.setMinimumHeight(30)
        self.inp_network.setPlaceholderText(r"\Server\KVDT")
        self.inp_network.setEnabled(self.chk_network.isChecked())
        net_l.addRow("Netzwerkpfad:", self.inp_network)

        net_info = QLabel(
            "Im Netzwerkmodus werden Benutzerverwaltung und BSNR-Registrierung "
            "aus dem Netzwerkordner gelesen. Jeder Nutzer hat eine eigene Session."
        )
        net_info.setStyleSheet("color:#64748b; font-size:11px;")
        net_l.addRow("", net_info)

        self.btn_test_net = QPushButton("🔗  Verbindung testen")
        self.btn_test_net.setFixedHeight(32)
        self.btn_test_net.setStyleSheet(
            "QPushButton{background:white;color:#334155;border:1px solid #e2e8f0;"
            "border-radius:6px;padding:5px 14px;font-weight:400;}"
            "QPushButton:hover{background:#f1f5f9;border-color:#2563eb;color:#2563eb;}")
        self.btn_test_net.clicked.connect(self._test_network)
        net_l.addRow("", self.btn_test_net)

        L.addWidget(grp_net)

        # Buttons
        btn_row = QHBoxLayout()

        self.btn_dl = QPushButton("⬇  EBM-Daten jetzt herunterladen")
        self.btn_dl.setFixedHeight(38)
        self.btn_dl.setStyleSheet("QPushButton { background:#2563eb; color:white; border:none; "
                                  "border-radius:6px; padding:8px 18px; font-weight:bold; }"
                                  "QPushButton:hover { background:#1d4ed8; }"
                                  "QPushButton:disabled { background:#cbd5e1; color:#94a3b8; }")
        self.btn_dl.clicked.connect(self._download)
        btn_row.addWidget(self.btn_dl)

        btn_row.addStretch()

        btn_save = QPushButton("💾 Speichern")
        btn_save.setFixedHeight(38)
        btn_save.setStyleSheet("QPushButton { background:#16a34a; color:white; border:none; "
                               "border-radius:6px; padding:8px 18px; font-weight:bold; }"
                               "QPushButton:hover { background:#15803d; }")
        btn_save.clicked.connect(self._save)
        btn_row.addWidget(btn_save)

        btn_close = QPushButton("Schließen")
        btn_close.setFixedHeight(38)
        btn_close.setStyleSheet("QPushButton { background:white; color:#334155; "
                                "border:1px solid #e2e8f0; border-radius:6px; padding:8px 18px; }"
                                "QPushButton:hover { background:#f1f5f9; }")
        btn_close.clicked.connect(self.accept)
        btn_row.addWidget(btn_close)

        L.addLayout(btn_row)

    def _toggle_network(self, checked):
        self.inp_network.setEnabled(checked)

    def _test_network(self):
        import os
        path = self.inp_network.text().strip()
        if not path:
            self.lbl_status.setText("⚠ Bitte einen Netzwerkpfad eingeben.")
            self.lbl_status.setStyleSheet("color:#dc2626; font-size:12px;")
            return
        if os.path.isdir(path):
            self.lbl_status.setText(f"✓ Verbindung OK: {path}")
            self.lbl_status.setStyleSheet("color:#16a34a; font-size:12px;")
        else:
            self.lbl_status.setText(f"⚠ Pfad nicht erreichbar: {path}")
            self.lbl_status.setStyleSheet("color:#dc2626; font-size:12px;")

    def _save(self):
        self.s["ebm_url"] = self.inp_url.text().strip()
        self.s["ebm_auto_update"] = self.chk_auto.isChecked()
        self.s["ebm_update_interval_days"] = self.spn_days.value()
        self.s["network_mode"] = self.chk_network.isChecked()
        self.s["network_path"] = self.inp_network.text().strip()
        settings.save(self.s)
        self.lbl_status.setText("✓ Einstellungen gespeichert.")
        self.lbl_status.setStyleSheet("color:#16a34a; font-size:12px;")

    def _download(self):
        url = self.inp_url.text().strip()
        if not url:
            QMessageBox.warning(self, "Fehler", "Bitte eine URL eingeben.")
            return

        self._save()
        self.btn_dl.setEnabled(False)
        self.pb.show()
        self.lbl_status.setText("Wird heruntergeladen…")
        self.lbl_status.setStyleSheet("color:#64748b; font-size:12px;")

        self.worker = DownloadWorker(url)
        self.worker.done.connect(self._on_done)
        self.worker.start()

    def _on_done(self, success, msg):
        self.pb.hide()
        self.btn_dl.setEnabled(True)
        if success:
            self.lbl_status.setText(f"✓ {msg}")
            self.lbl_status.setStyleSheet("color:#16a34a; font-size:12px;")
            # Letztes Update anzeigen
            last = settings.get("ebm_last_update")
            if last:
                dt = datetime.datetime.fromisoformat(last)
                self.lbl_last.setText(f"Letztes Update: {dt.strftime('%d.%m.%Y %H:%M Uhr')}")
            QMessageBox.information(self, "Erfolg", msg +
                "\n\nDie neuen EBM-Daten werden beim nächsten Programmstart aktiv.")
        else:
            self.lbl_status.setText(f"⚠ {msg}")
            self.lbl_status.setStyleSheet("color:#dc2626; font-size:12px;")
            QMessageBox.critical(self, "Fehler", msg)


def check_auto_update():
    """Prüft beim Programmstart ob ein Update fällig ist und lädt ggf. herunter."""
    s = settings.load()
    if not s.get("ebm_auto_update", True):
        return

    interval = s.get("ebm_update_interval_days", 7)
    last_str = s.get("ebm_last_update")

    if last_str:
        try:
            last = datetime.datetime.fromisoformat(last_str)
            if (datetime.datetime.now() - last).days < interval:
                return  # Noch nicht fällig
        except Exception:
            pass

    # Update fällig – still im Hintergrund herunterladen
    url = s.get("ebm_url", "")
    if url:
        try:
            worker = DownloadWorker(url)
            worker.run()  # Synchron beim Start
        except Exception:
            pass
