# views/dialogs_auth.py – Login- und Benutzerverwaltungs-Dialoge
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QHeaderView,
    QMessageBox, QFormLayout, QWidget, QFrame, QGroupBox
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QFont
from core.auth import (
    verify, add_user, change_password, delete_user,
    list_users, load_users, ADMIN_USER
)

STYLE = """
QDialog { background:#f8fafc; }
#title { font-size:16px; font-weight:bold; color:#1e3a5f; }
#sub   { color:#64748b; }
QLineEdit { min-height:28px; padding:4px 8px; }
QPushButton {
    background:#2563eb; color:white; border:none;
    border-radius:6px; padding:8px 20px; font-weight:bold;
}
QPushButton:hover    { background:#1d4ed8; }
QPushButton:disabled { background:#cbd5e1; color:#94a3b8; }
#sec { background:white; color:#334155; border:1px solid #e2e8f0; }
#sec:hover { background:#f1f5f9; }
#danger { background:#dc2626; color:white; border:none; border-radius:6px; padding:8px 20px; }
#danger:hover { background:#b91c1c; }
QGroupBox { border:1px solid #e2e8f0; border-radius:6px; margin-top:8px; padding:8px; }
QGroupBox::title { subcontrol-origin:margin; left:8px; font-weight:bold; }
QTableWidget { background:white; border:1px solid #e2e8f0; }
QTableWidget QHeaderView::section { background:#f8fafc; border:1px solid #e2e8f0; padding:4px 6px; font-weight:bold; }
"""


# ── Login-Dialog ──────────────────────────────────────────────────────────────

class LoginDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("KVDT Analyzer – Anmeldung")
        self.setFixedSize(380, 340)
        self.setStyleSheet(STYLE)
        self.setWindowFlags(Qt.WindowType.Dialog |
                            Qt.WindowType.MSWindowsFixedSizeDialogHint)
        self.logged_in_user = None
        self._build()

    def _build(self):
        from PyQt6.QtGui import QFont
        font = QFont()
        font.setPointSize(10)
        self.setFont(font)
        L = QVBoxLayout(self)
        L.setContentsMargins(32, 20, 32, 20)
        L.setSpacing(4)

        t = QLabel("KVDT Analyzer")
        t.setObjectName("title")
        t.setAlignment(Qt.AlignmentFlag.AlignCenter)
        L.addWidget(t)

        s = QLabel("Bitte melden Sie sich an")
        s.setObjectName("sub")
        s.setAlignment(Qt.AlignmentFlag.AlignCenter)
        L.addWidget(s)

        L.addSpacing(12)

        L.addWidget(QLabel("Benutzername:"))
        self.inp_user = QLineEdit()
        self.inp_user.setFixedHeight(32)
        L.addWidget(self.inp_user)

        L.addSpacing(8)

        L.addWidget(QLabel("Passwort:"))
        self.inp_pw = QLineEdit()
        self.inp_pw.setFixedHeight(32)
        self.inp_pw.setEchoMode(QLineEdit.EchoMode.Password)
        self.inp_pw.returnPressed.connect(self._login)
        L.addWidget(self.inp_pw)

        L.addSpacing(4)

        self.lbl_err = QLabel("")
        self.lbl_err.setStyleSheet("color:#dc2626; font-size:12px;")
        self.lbl_err.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lbl_err.setFixedHeight(18)
        L.addWidget(self.lbl_err)

        L.addSpacing(8)

        btn = QPushButton("Anmelden")
        btn.setFixedHeight(40)
        btn.clicked.connect(self._login)
        L.addWidget(btn)

    def _login(self):
        user = self.inp_user.text().strip().lower()
        pw   = self.inp_pw.text()
        if not user or not pw:
            self.lbl_err.setText("Bitte Benutzername und Passwort eingeben.")
            return
        if verify(user, pw):
            self.logged_in_user = user
            self.accept()
        else:
            self.lbl_err.setText("Falscher Benutzername oder Passwort.")
            self.inp_pw.clear()
            self.inp_pw.setFocus()


# ── Benutzerverwaltungs-Dialog ────────────────────────────────────────────────

class UserManagerDialog(QDialog):
    def __init__(self, current_user: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Benutzerverwaltung")
        self.setMinimumSize(560, 580)
        self.resize(600, 620)
        self.setStyleSheet(STYLE)
        self.current_user = current_user
        self.is_admin = (current_user == ADMIN_USER)
        self._build()
        self._refresh_table()

    def _build(self):
        L = QVBoxLayout(self)
        L.setContentsMargins(24, 20, 24, 20)
        L.setSpacing(14)

        # Titel
        t = QLabel("👤  Benutzerverwaltung")
        t.setObjectName("title")
        L.addWidget(t)

        info = QLabel(
            f"Angemeldet als: <b>{self.current_user}</b>"
            + ("  <span style='background:#fef9c3;border:1px solid #fde047;"
               "border-radius:4px;padding:1px 6px;color:#854d0e;font-size:11px;'>"
               "Administrator</span>" if self.is_admin else ""))
        info.setTextFormat(Qt.TextFormat.RichText)
        info.setStyleSheet("color:#475569; font-size:12px;")
        L.addWidget(info)

        # Benutzerliste
        grp_list = QGroupBox("Vorhandene Benutzer")
        list_layout = QVBoxLayout(grp_list)

        self.tbl = QTableWidget()
        self.tbl.setColumnCount(2)
        self.tbl.setHorizontalHeaderLabels(["Benutzername", "Typ"])
        self.tbl.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.tbl.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.tbl.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.tbl.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.tbl.verticalHeader().hide()
        self.tbl.setFixedHeight(160)
        list_layout.addWidget(self.tbl)

        if self.is_admin:
            del_row = QHBoxLayout()
            del_row.addStretch()
            self.btn_del = QPushButton("🗑  Benutzer löschen")
            self.btn_del.setObjectName("danger")
            self.btn_del.clicked.connect(self._delete_user)
            del_row.addWidget(self.btn_del)
            list_layout.addLayout(del_row)

        L.addWidget(grp_list)

        # Neuen Benutzer anlegen (nur Admin)
        if self.is_admin:
            grp_new = QGroupBox("Neuen Benutzer anlegen")
            new_layout = QFormLayout(grp_new)
            new_layout.setSpacing(10)

            self.inp_new_user = QLineEdit()
            self.inp_new_user.setPlaceholderText("Benutzername")
            new_layout.addRow("Benutzername:", self.inp_new_user)

            self.inp_new_pw = QLineEdit()
            self.inp_new_pw.setPlaceholderText("Passwort (min. 4 Zeichen)")
            self.inp_new_pw.setEchoMode(QLineEdit.EchoMode.Password)
            new_layout.addRow("Passwort:", self.inp_new_pw)

            self.inp_new_pw2 = QLineEdit()
            self.inp_new_pw2.setPlaceholderText("Passwort wiederholen")
            self.inp_new_pw2.setEchoMode(QLineEdit.EchoMode.Password)
            new_layout.addRow("Wiederholen:", self.inp_new_pw2)

            self.lbl_new_err = QLabel("")
            self.lbl_new_err.setStyleSheet("color:#dc2626; font-size:12px;")
            new_layout.addRow("", self.lbl_new_err)

            btn_add = QPushButton("✚  Benutzer anlegen")
            btn_add.setFixedHeight(34)
            btn_add.clicked.connect(self._add_user)
            new_layout.addRow("", btn_add)

            L.addWidget(grp_new)

        # Passwort ändern (eigenes Konto, nicht Admin)
        grp_pw = QGroupBox("Eigenes Passwort ändern")
        pw_layout = QFormLayout(grp_pw)
        pw_layout.setSpacing(10)

        if not self.is_admin:
            self.inp_old_pw = QLineEdit()
            self.inp_old_pw.setEchoMode(QLineEdit.EchoMode.Password)
            self.inp_old_pw.setPlaceholderText("Aktuelles Passwort")
            pw_layout.addRow("Aktuelles Passwort:", self.inp_old_pw)

            self.inp_chg_pw = QLineEdit()
            self.inp_chg_pw.setEchoMode(QLineEdit.EchoMode.Password)
            self.inp_chg_pw.setPlaceholderText("Neues Passwort")
            pw_layout.addRow("Neues Passwort:", self.inp_chg_pw)

            self.inp_chg_pw2 = QLineEdit()
            self.inp_chg_pw2.setEchoMode(QLineEdit.EchoMode.Password)
            self.inp_chg_pw2.setPlaceholderText("Wiederholen")
            pw_layout.addRow("Wiederholen:", self.inp_chg_pw2)

            self.lbl_pw_err = QLabel("")
            self.lbl_pw_err.setStyleSheet("color:#dc2626; font-size:12px;")
            pw_layout.addRow("", self.lbl_pw_err)

            btn_chg = QPushButton("🔑  Passwort ändern")
            btn_chg.setFixedHeight(34)
            btn_chg.clicked.connect(self._change_pw)
            pw_layout.addRow("", btn_chg)
        else:
            note = QLabel("Das Admin-Passwort ist fest und kann nicht geändert werden.")
            note.setStyleSheet("color:#64748b; font-size:12px;")
            pw_layout.addRow(note)

        L.addWidget(grp_pw)

        # Schließen
        row = QHBoxLayout()
        row.addStretch()

        if self.is_admin:
            btn_lizenz = QPushButton("🔑  Lizenz konfigurieren")
            btn_lizenz.setObjectName("sec")
            btn_lizenz.setFixedHeight(34)
            btn_lizenz.clicked.connect(self._open_lizenz)
            row.addWidget(btn_lizenz)

        btn_close = QPushButton("Schließen")
        btn_close.setObjectName("sec")
        btn_close.clicked.connect(self.accept)
        row.addWidget(btn_close)
        L.addLayout(row)

    def _open_lizenz(self):
        dlg = LizenzConfigDialog(parent=self)
        dlg.exec()

    def _refresh_table(self):
        users = list_users()
        self.tbl.setRowCount(len(users))
        for r, name in enumerate(users):
            self.tbl.setItem(r, 0, QTableWidgetItem(name))
            typ = "Administrator (fest)" if name == ADMIN_USER else "Benutzer"
            item = QTableWidgetItem(typ)
            if name == ADMIN_USER:
                item.setForeground(Qt.GlobalColor.darkYellow)
            self.tbl.setItem(r, 1, item)

    def _add_user(self):
        user = self.inp_new_user.text().strip()
        pw   = self.inp_new_pw.text()
        pw2  = self.inp_new_pw2.text()
        if pw != pw2:
            self.lbl_new_err.setText("Passwörter stimmen nicht überein.")
            return
        err = add_user(user, pw)
        if err:
            self.lbl_new_err.setText(err)
        else:
            self.lbl_new_err.setText("")
            self.inp_new_user.clear()
            self.inp_new_pw.clear()
            self.inp_new_pw2.clear()
            self._refresh_table()
            QMessageBox.information(self, "Erfolg",
                f"Benutzer '{user}' wurde angelegt.")

    def _delete_user(self):
        row = self.tbl.currentRow()
        if row < 0:
            QMessageBox.warning(self, "Hinweis", "Bitte einen Benutzer auswählen.")
            return
        name = self.tbl.item(row, 0).text()
        if name == ADMIN_USER:
            QMessageBox.warning(self, "Nicht möglich",
                "Der Admin-Account kann nicht gelöscht werden.")
            return
        reply = QMessageBox.question(self, "Benutzer löschen",
            f"Benutzer '{name}' wirklich löschen?")
        if reply == QMessageBox.StandardButton.Yes:
            err = delete_user(name)
            if err:
                QMessageBox.critical(self, "Fehler", err)
            else:
                self._refresh_table()

    def _change_pw(self):
        old  = self.inp_old_pw.text()
        new  = self.inp_chg_pw.text()
        new2 = self.inp_chg_pw2.text()
        if new != new2:
            self.lbl_pw_err.setText("Neue Passwörter stimmen nicht überein.")
            return
        err = change_password(self.current_user, old, new)
        if err:
            self.lbl_pw_err.setText(err)
        else:
            self.lbl_pw_err.setText("")
            self.inp_old_pw.clear()
            self.inp_chg_pw.clear()
            self.inp_chg_pw2.clear()
            QMessageBox.information(self, "Erfolg", "Passwort wurde geändert.")


# ── BSNR-Registrierungs-Dialog ────────────────────────────────────────────────

class BSNRRegisterDialog(QDialog):
    """Erscheint beim ersten Einlesen einer KVDT-Datei.
    Admin muss Passwort eingeben um die BSNR zu bestätigen und zu registrieren."""

    def __init__(self, bsnr: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("BSNR registrieren")
        self.setFixedSize(420, 300)
        self.setStyleSheet(STYLE)
        self.setWindowFlags(Qt.WindowType.Dialog |
                            Qt.WindowType.MSWindowsFixedSizeDialogHint)
        self.bsnr = bsnr
        self.confirmed = False
        self._build()

    def _build(self):
        from PyQt6.QtGui import QFont
        font = QFont(); font.setPointSize(10); self.setFont(font)

        L = QVBoxLayout(self)
        L.setContentsMargins(28, 22, 28, 22)
        L.setSpacing(10)

        t = QLabel("🏥  BSNR registrieren")
        t.setStyleSheet("font-size:16px; font-weight:bold; color:#1e3a5f;")
        L.addWidget(t)

        info = QLabel(
            "Dies ist die erste KVDT-Datei die eingelesen wird.\n"
            "Die BSNR dieser Praxis wird dauerhaft registriert.\n"
            "Danach werden nur Dateien dieser Praxis akzeptiert."
        )
        info.setStyleSheet("color:#475569; font-size:12px;")
        info.setWordWrap(True)
        L.addWidget(info)

        # BSNR anzeigen
        bsnr_box = QLabel(f"BSNR:  {self.bsnr}")
        bsnr_box.setStyleSheet(
            "background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px;"
            "padding:8px 12px; font-size:15px; font-weight:bold; color:#1e40af;")
        L.addWidget(bsnr_box)

        L.addWidget(QLabel("Admin-Passwort zur Bestätigung:"))
        self.inp_pw = QLineEdit()
        self.inp_pw.setEchoMode(QLineEdit.EchoMode.Password)
        self.inp_pw.setFixedHeight(32)
        self.inp_pw.returnPressed.connect(self._confirm)
        L.addWidget(self.inp_pw)

        self.lbl_err = QLabel("")
        self.lbl_err.setStyleSheet("color:#dc2626; font-size:12px;")
        self.lbl_err.setFixedHeight(18)
        L.addWidget(self.lbl_err)

        row = QHBoxLayout()
        btn_cancel = QPushButton("Abbrechen")
        btn_cancel.setObjectName("sec")
        btn_cancel.setFixedHeight(34)
        btn_cancel.clicked.connect(self.reject)
        row.addWidget(btn_cancel)
        row.addStretch()
        btn_ok = QPushButton("✓  BSNR bestätigen & registrieren")
        btn_ok.setFixedHeight(34)
        btn_ok.clicked.connect(self._confirm)
        row.addWidget(btn_ok)
        L.addLayout(row)

    def _confirm(self):
        from core.auth import register_bsnr
        pw = self.inp_pw.text()
        err = register_bsnr(self.bsnr, pw)
        if err:
            self.lbl_err.setText(err)
            self.inp_pw.clear()
            self.inp_pw.setFocus()
        else:
            self.confirmed = True
            self.accept()


# ── Lizenz-Konfigurations-Dialog ──────────────────────────────────────────────

class LizenzConfigDialog(QDialog):
    """Erlaubt dem Admin den Lizenzdateinamen zu ändern."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Lizenz konfigurieren")
        self.setFixedSize(480, 260)
        self.setStyleSheet(STYLE)
        self.setWindowFlags(Qt.WindowType.Dialog |
                            Qt.WindowType.MSWindowsFixedSizeDialogHint)
        self._build()

    def _build(self):
        from PyQt6.QtGui import QFont
        from core.lizenzpruefung import LICENSE_FILENAME, GITHUB_REPO
        font = QFont(); font.setPointSize(10); self.setFont(font)

        L = QVBoxLayout(self)
        L.setContentsMargins(28, 20, 28, 20)
        L.setSpacing(10)

        t = QLabel("🔑  Lizenz konfigurieren")
        t.setStyleSheet("font-size:15px; font-weight:bold; color:#1e3a5f;")
        L.addWidget(t)

        info = QLabel(
            f"Repository: {GITHUB_REPO}\n"
            "Der Dateiname muss exakt mit der Datei auf GitHub übereinstimmen."
        )
        info.setStyleSheet(
            "background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px;"
            "padding:8px 12px; color:#1e40af; font-size:12px;")
        info.setWordWrap(True)
        info.setMinimumHeight(52)
        L.addWidget(info)

        L.addWidget(QLabel("Aktueller Lizenz-Dateiname:"))
        self.inp_filename = QLineEdit(LICENSE_FILENAME)
        self.inp_filename.setFixedHeight(32)
        L.addWidget(self.inp_filename)

        self.lbl_err = QLabel("")
        self.lbl_err.setStyleSheet("color:#dc2626; font-size:12px;")
        self.lbl_err.setFixedHeight(18)
        L.addWidget(self.lbl_err)

        row = QHBoxLayout()
        btn_cancel = QPushButton("Abbrechen")
        btn_cancel.setObjectName("sec"); btn_cancel.setFixedHeight(34)
        btn_cancel.clicked.connect(self.reject)
        row.addWidget(btn_cancel)
        row.addStretch()
        btn_ok = QPushButton("💾  Speichern")
        btn_ok.setFixedHeight(34)
        btn_ok.clicked.connect(self._save)
        row.addWidget(btn_ok)
        L.addLayout(row)

    def _save(self):
        new_name = self.inp_filename.text().strip()
        if not new_name:
            self.lbl_err.setText("Dateiname darf nicht leer sein.")
            return
        if not new_name.endswith('.txt'):
            self.lbl_err.setText("Dateiname muss auf .txt enden.")
            return

        # Schreibe neuen Dateinamen in lizenzpruefung.py
        import os
        liz_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            'core', 'lizenzpruefung.py'
        )
        try:
            with open(liz_path, 'r', encoding='utf-8') as f:
                content = f.read()
            import re
            content = re.sub(
                r'LICENSE_FILENAME\s*=\s*"[^"]*"',
                f'LICENSE_FILENAME = "{new_name}"',
                content
            )
            with open(liz_path, 'w', encoding='utf-8') as f:
                f.write(content)
            QMessageBox.information(self, "Gespeichert",
                f"Lizenzdateiname geändert auf:\n{new_name}\n\n"
                "Änderung wird beim nächsten Programmstart aktiv.")
            self.accept()
        except Exception as e:
            self.lbl_err.setText(f"Fehler: {e}")
