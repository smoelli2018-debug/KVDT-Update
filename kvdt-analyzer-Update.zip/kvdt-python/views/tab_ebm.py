# views/tab_ebm.py
from collections import Counter
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget, QLineEdit
from PyQt6.QtCore import Qt
from .base_tab import BaseTab
from core.parser import EBM_BEZEICHNUNG


class TabEBM(BaseTab):
    def refresh(self):
        self._clear()
        qs = self.session.quarters
        if not qs:
            self.content_layout.addWidget(QLabel("Keine Quartale geladen."))
            self.content_layout.addStretch()
            return

        self.content_layout.addWidget(
            self._header("💊 EBM-Leistungen", "Häufigkeit je Gebührenordnungsposition"))

        # Zählungen pro Quartal
        per_q = []
        for q in qs:
            c = Counter()
            for p in q.patients:
                for e in p.ebm_entries:
                    c[e.code] += e.mult
            per_q.append(c)

        # Alle Codes, sortiert nach Gesamthäufigkeit
        all_codes = sorted(
            {c for cnt in per_q for c in cnt},
            key=lambda c: -sum(cnt[c] for cnt in per_q))

        headers = ["EBM-Ziffer", "Bezeichnung"] + [q.label for q in qs] + ["Gesamt"]
        rows = []
        for code in all_codes:
            vals = [cnt.get(code, 0) for cnt in per_q]
            rows.append([code,
                         EBM_BEZEICHNUNG.get(code, ""),
                         *[self._fmt_int(v) for v in vals],
                         self._fmt_int(sum(vals))])

        col_w = [90, -1] + [90]*len(qs) + [90]
        t = self._table(headers, rows, col_widths=col_w)
        self.content_layout.addWidget(t)

        # KPI
        total = sum(sum(c.values()) for c in per_q)
        unique = len(all_codes)
        kpi = self._kpi_row([
            ("Verschiedene Ziffern", self._fmt_int(unique), "", "#3b82f6"),
            ("Leistungen gesamt", self._fmt_int(total), "alle Quartale", "#8b5cf6"),
        ])
        self.content_layout.insertWidget(1, kpi)

        self.content_layout.addStretch()
