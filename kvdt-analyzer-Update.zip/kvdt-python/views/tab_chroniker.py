# views/tab_chroniker.py
from collections import Counter
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget
from .base_tab import BaseTab


class TabChroniker(BaseTab):
    def refresh(self):
        self._clear()
        qs = self.session.quarters
        if not qs:
            self.content_layout.addWidget(QLabel("Keine Quartale geladen."))
            self.content_layout.addStretch()
            return

        self.content_layout.addWidget(
            self._header("♾ Chroniker-Auswertung",
                         "Definition: mind. 1 Dauerdiagnose oder EBM 03220/03221"))

        # ── KPI-Karten ────────────────────────────────────────────────────────
        kpi_items = []
        stats = []
        for i, q in enumerate(qs):
            ch = [p for p in q.patients if p.is_chroniker()]
            total = q.patient_count
            quote = f"{len(ch)/total*100:.1f}%" if total else "—"
            mm    = sum(1 for p in ch if len(p.diag_dauer) >= 3)
            p1    = sum(1 for p in ch if "03220" in p.ebm_codes)
            p2    = sum(1 for p in ch if "03221" in p.ebm_codes)
            avg   = (sum(len(p.diag_dauer) for p in ch) / len(ch)) if ch else 0
            stats.append(dict(n=len(ch), quote=quote, mm=mm, p1=p1, p2=p2,
                              avg=avg, total=total))
            kpi_items.append((q.label, self._fmt_int(len(ch)),
                              f"Quote: {quote}", self.session.color(i)))

        self.content_layout.addWidget(self._kpi_row(kpi_items))

        # ── Kennzahlen-Tabelle ────────────────────────────────────────────────
        self.content_layout.addWidget(self._section("Kennzahlen"))
        headers = ["Kennzahl"] + [q.label for q in qs]
        rows = [
            ["Chroniker gesamt"]       + [self._fmt_int(s["n"])     for s in stats],
            ["Quote (%)"]              + [s["quote"]                 for s in stats],
            ["Multimorbid (≥3 DD)"]   + [self._fmt_int(s["mm"])    for s in stats],
            ["EBM 03220"]              + [self._fmt_int(s["p1"])    for s in stats],
            ["EBM 03221"]              + [self._fmt_int(s["p2"])    for s in stats],
            ["∅ Dauerdiagnosen"]       + [f"{s['avg']:.1f}"         for s in stats],
            ["Patienten gesamt"]       + [self._fmt_int(s["total"]) for s in stats],
        ]
        self.content_layout.addWidget(
            self._table(headers, rows, col_widths=[200]+[-1]*len(qs)))

        # ── Häufigste Dauerdiagnosen ──────────────────────────────────────────
        self.content_layout.addWidget(self._section("Häufigste Dauerdiagnosen"))
        per_q = []
        for q in qs:
            c = Counter()
            for p in q.patients:
                if p.is_chroniker():
                    for d in p.diag_dauer:
                        c[d.code] += 1
            per_q.append(c)

        all_dd = sorted(
            {c for cnt in per_q for c in cnt},
            key=lambda c: -sum(cnt[c] for cnt in per_q))

        dd_headers = ["ICD-10"] + [q.label for q in qs] + ["Gesamt"]
        dd_rows = []
        for code in all_dd[:30]:
            vals = [cnt.get(code, 0) for cnt in per_q]
            dd_rows.append([code,
                            *[self._fmt_int(v) for v in vals],
                            self._fmt_int(sum(vals))])

        self.content_layout.addWidget(
            self._table(dd_headers, dd_rows,
                        col_widths=[90]+[90]*len(qs)+[90]))

        self.content_layout.addStretch()
