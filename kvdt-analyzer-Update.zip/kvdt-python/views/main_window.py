# views/main_window.py
from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QTabWidget,
    QPushButton, QLabel, QFileDialog, QMessageBox, QFrame,
    QSizePolicy, QApplication, QScrollArea, QToolBar, QStatusBar,
    QProgressDialog
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QIcon, QFont, QColor, QPalette, QAction, QDragEnterEvent, QDropEvent
import os, sys

from core.session import Session
from .style import STYLE, COLORS
from .tab_vergleich import TabVergleich
from .tab_ebm import TabEBM
from .tab_diagnosen import TabDiagnosen
from .tab_chroniker import TabChroniker
from .tab_honorar import TabHonorar


class LoadWorker(QThread):
    done     = pyqtSignal(str)   # Fehlermeldung oder ""
    progress = pyqtSignal(int, int, str)  # aktuell, gesamt, dateiname

    def __init__(self, session, files):
        super().__init__()
        self.session = session
        self.files = files  # [(filename, text), ...]

    def run(self):
        total = len(self.files)
        for i, (filename, text) in enumerate(self.files):
            self.progress.emit(i, total, os.path.basename(filename))
            err = self.session.add_file(filename, text)
            if err:
                self.done.emit(err)
                return
        self.progress.emit(total, total, "")
        self.done.emit("")


class MainWindow(QMainWindow):
    def __init__(self, current_user: str = "admin"):
        super().__init__()
        self.current_user = current_user
        self.session = Session(username=current_user)
        self.setWindowTitle("KVDT Analyzer")
        self.setMinimumSize(1100, 700)
        self.resize(1300, 850)
        self.setStyleSheet(STYLE)
        self.setAcceptDrops(True)
        self._build_ui()
        self._try_restore_session()

    def _build_ui(self):
        # ── Toolbar ───────────────────────────────────────────────────────────
        tb = QToolBar("Hauptleiste")
        tb.setMovable(False)
        tb.setIconSize(QSize(16, 16))
        tb.setObjectName("mainToolbar")
        self.addToolBar(tb)

        self.act_open = QAction("＋ Quartal laden", self)
        self.act_open.setShortcut("Ctrl+O")
        self.act_open.triggered.connect(self._open_files)
        tb.addAction(self.act_open)

        tb.addSeparator()

        self.act_save = QAction("💾 Speichern", self)
        self.act_save.triggered.connect(self._save_session)
        self.act_save.setEnabled(False)
        tb.addAction(self.act_save)

        self.act_export_json = QAction("📦 Als Datei sichern", self)
        self.act_export_json.triggered.connect(self._export_json)
        self.act_export_json.setEnabled(False)
        tb.addAction(self.act_export_json)

        self.act_import_json = QAction("📂 Session laden", self)
        self.act_import_json.triggered.connect(self._import_json)
        tb.addAction(self.act_import_json)

        tb.addSeparator()

        self.act_export_xlsx = QAction("📊 Excel exportieren", self)
        self.act_export_xlsx.triggered.connect(self._export_xlsx)
        self.act_export_xlsx.setEnabled(False)
        tb.addAction(self.act_export_xlsx)

        self.act_export_csv = QAction("📄 CSV exportieren", self)
        self.act_export_csv.triggered.connect(self._export_csv)
        self.act_export_csv.setEnabled(False)
        tb.addAction(self.act_export_csv)

        tb.addSeparator()

        self.act_reset = QAction("↩ Zurücksetzen", self)
        self.act_reset.triggered.connect(self._reset)
        self.act_reset.setEnabled(False)
        tb.addAction(self.act_reset)

        # Spacer
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        tb.addWidget(spacer)

        # BSNR-Anzeige
        self.lbl_bsnr = QLabel("")
        self.lbl_bsnr.setObjectName("bsnrLabel")
        tb.addWidget(self.lbl_bsnr)

        tb.addSeparator()

        # Benutzer-Button
        self.act_users = QAction(f"👤 {self.current_user}", self)
        self.act_users.triggered.connect(self._open_user_manager)
        tb.addAction(self.act_users)

        # Einstellungen-Button
        self.act_settings = QAction("⚙ Einstellungen", self)
        self.act_settings.triggered.connect(self._open_settings)
        tb.addAction(self.act_settings)

        # Update-Button
        self.act_update = QAction("🔄 Update", self)
        self.act_update.triggered.connect(self._check_update)
        tb.addAction(self.act_update)

        # ── Zentrales Widget ──────────────────────────────────────────────────
        central = QWidget()
        self.setCentralWidget(central)
        self.main_layout = QVBoxLayout(central)
        self.main_layout.setContentsMargins(0, 0, 0, 0)
        self.main_layout.setSpacing(0)

        # ── Quartals-Leiste ───────────────────────────────────────────────────
        self.quarter_bar = QWidget()
        self.quarter_bar.setObjectName("quarterBar")
        self.quarter_bar.hide()
        qbar_layout = QHBoxLayout(self.quarter_bar)
        qbar_layout.setContentsMargins(12, 6, 12, 6)
        qbar_layout.setSpacing(8)
        self.quarter_chips_layout = QHBoxLayout()
        self.quarter_chips_layout.setSpacing(6)
        qbar_layout.addLayout(self.quarter_chips_layout)
        qbar_layout.addStretch()
        self.main_layout.addWidget(self.quarter_bar)

        # ── Drop-Zone ─────────────────────────────────────────────────────────
        self.drop_zone = DropZone()
        self.drop_zone.files_dropped.connect(self._load_paths)
        self.drop_zone.open_clicked.connect(self._open_files)
        self.main_layout.addWidget(self.drop_zone)

        # ── Tab-Bereich ───────────────────────────────────────────────────────
        self.tabs = QTabWidget()
        self.tabs.setObjectName("mainTabs")
        self.tabs.hide()
        self.main_layout.addWidget(self.tabs, 1)

        self.tab_vergleich  = TabVergleich(self.session)
        self.tab_ebm        = TabEBM(self.session)
        self.tab_diagnosen  = TabDiagnosen(self.session)
        self.tab_chroniker  = TabChroniker(self.session)
        self.tab_honorar    = TabHonorar(self.session)

        self.tabs.addTab(self.tab_vergleich,  "📊  Quartal-Vergleich")
        self.tabs.addTab(self.tab_ebm,        "💊  EBM-Leistungen")
        self.tabs.addTab(self.tab_diagnosen,  "🔬  Diagnosen")
        self.tabs.addTab(self.tab_chroniker,  "♾   Chroniker")
        self.tabs.addTab(self.tab_honorar,    "💶  Honorar")

        self.tabs.currentChanged.connect(self._refresh_current_tab)

        # ── Statusbar ─────────────────────────────────────────────────────────
        self.status = QStatusBar()
        self.setStatusBar(self.status)

    # ── Drag & Drop ───────────────────────────────────────────────────────────
    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e: QDropEvent):
        paths = [u.toLocalFile() for u in e.mimeData().urls()
                 if u.toLocalFile().lower().endswith(('.con','.txt','.kvdt'))]
        if paths:
            self._load_paths(paths)

    # ── Datei-Aktionen ────────────────────────────────────────────────────────
    def _open_files(self):
        paths, _ = QFileDialog.getOpenFileNames(
            self, "KVDT-Dateien öffnen", "",
            "KVDT-Dateien (*.con *.txt *.kvdt);;Alle Dateien (*)")
        if paths:
            self._load_paths(paths)

    def _load_paths(self, paths: list):
        files = []
        for path in paths:
            try:
                with open(path, "r", encoding="iso-8859-1") as f:
                    text = f.read()
                files.append((path, text))
            except Exception as e:
                QMessageBox.warning(self, "Lesefehler", str(e))
                return

        # Fortschritts-Dialog
        self._progress = QProgressDialog(
            "Dateien werden geladen…", "Abbrechen", 0, len(files), self)
        self._progress.setWindowTitle("KVDT Analyzer")
        self._progress.setWindowModality(Qt.WindowModality.WindowModal)
        self._progress.setMinimumDuration(0)
        self._progress.setMinimumWidth(380)
        self._progress.setValue(0)
        self._progress.setStyleSheet("""
            QProgressDialog { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; }
            QProgressDialog QLabel { color: #0f172a; font-size: 13px; padding: 8px; font-family: 'Segoe UI'; }
            QProgressBar {
                background: #f1f5f9; border: 1px solid #e2e8f0; border-radius: 4px;
                height: 18px; text-align: center; color: #334155;
            }
            QProgressBar::chunk { background: #2563eb; border-radius: 3px; }
            QPushButton { background: #f1f5f9; color: #334155; border: 1px solid #e2e8f0;
                          border-radius: 5px; padding: 5px 14px; }
            QPushButton:hover { background: #e2e8f0; border-color: #2563eb; color: #2563eb; }
        """)

        self.worker = LoadWorker(self.session, files)
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(self._on_load_done)
        self._progress.canceled.connect(self.worker.terminate)
        self.worker.start()

    def _on_progress(self, current: int, total: int, filename: str):
        if self._progress.wasCanceled():
            return
        self._progress.setValue(current)
        if filename:
            self._progress.setLabelText(
                f"Lade Datei {current + 1} von {total}:\n{filename}")

    def _on_load_done(self, err: str):
        self._progress.setValue(self._progress.maximum())
        self._progress.close()
        if err and err.startswith("BSNR_REGISTER_NEEDED:"):
            # Erste KVDT-Datei – BSNR-Registrierung erforderlich
            bsnr = err.split(":", 1)[1]
            from views.dialogs_auth import BSNRRegisterDialog
            dlg = BSNRRegisterDialog(bsnr, parent=self)
            if dlg.exec() == BSNRRegisterDialog.DialogCode.Accepted and dlg.confirmed:
                # Registrierung erfolgreich – Datei jetzt hinzufügen
                add_err = self.session.confirm_bsnr_and_add()
                if add_err:
                    QMessageBox.warning(self, "Fehler", add_err)
                else:
                    self._update_ui()
                    self.session.save()
                    if self.session._praxisname:
                        self.setWindowTitle(f"KVDT Analyzer – {self.session._praxisname}")
                    self.status.showMessage(
                        f"✓ BSNR {bsnr} registriert – Quartal geladen", 4000)
            else:
                self.status.showMessage("Laden abgebrochen – BSNR nicht bestätigt.", 4000)
        elif err:
            QMessageBox.warning(self, "Fehler", err)
            self.status.showMessage("Fehler beim Laden.", 4000)
        else:
            self._update_ui()
            self.session.save()
            # Praxisname in Fenstertitel setzen
            if self.session._praxisname:
                self.setWindowTitle(f"KVDT Analyzer – {self.session._praxisname}")
            self.status.showMessage(
                f"✓ {len(self.session.quarters)} Quartal(e) geladen", 3000)

    def _update_ui(self):
        has_data = bool(self.session.quarters)
        self.drop_zone.setVisible(not has_data)
        self.tabs.setVisible(has_data)
        self.quarter_bar.setVisible(has_data)
        self.act_save.setEnabled(has_data)
        self.act_export_json.setEnabled(has_data)
        self.act_export_xlsx.setEnabled(has_data)
        self.act_export_csv.setEnabled(has_data)
        self.act_reset.setEnabled(has_data)

        if has_data and self.session._bsnr:
            self.lbl_bsnr.setText(f"BSNR: {self.session._bsnr}")
        else:
            self.lbl_bsnr.setText("")

        self._rebuild_quarter_chips()
        self._refresh_current_tab()

    def _rebuild_quarter_chips(self):
        # Alte Chips löschen
        while self.quarter_chips_layout.count():
            item = self.quarter_chips_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        for i, q in enumerate(self.session.quarters):
            color = self.session.color(i)
            chip = QuarterChip(q.label, color, i)
            chip.remove_clicked.connect(self._remove_quarter)
            self.quarter_chips_layout.addWidget(chip)

    def _remove_quarter(self, idx: int):
        q = self.session.quarters[idx]
        if len(self.session.quarters) == 1:
            reply = QMessageBox.question(
                self, "Letztes Quartal",
                f'"{q.label}" ist das letzte Quartal.\nApp wird zurueckgesetzt. Fortfahren?')
            if reply == QMessageBox.StandardButton.Yes:
                self._reset()
            return
        reply = QMessageBox.question(self, "Quartal entfernen",
                                     f'Quartal "{q.label}" entfernen?')
        if reply == QMessageBox.StandardButton.Yes:
            self.session.remove_quarter(idx)
            self.session.save()
            self._update_ui()

    def _refresh_current_tab(self):
        tab = self.tabs.currentWidget()
        if tab and hasattr(tab, 'refresh'):
            tab.refresh()

    # ── Session ───────────────────────────────────────────────────────────────
    def _save_session(self):
        if self.session.save():
            self.status.showMessage("✓ Im Browser gespeichert – wird beim nächsten Start geladen", 4000)
        else:
            self.status.showMessage("⚠ Speichern fehlgeschlagen", 4000)

    def _export_json(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Session speichern", "kvdt-session.json",
            "JSON-Dateien (*.json)")
        if path:
            self.session.export_json(path)
            self.status.showMessage(f"✓ Session gespeichert: {path}", 4000)

    def _import_json(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Session laden", "", "JSON-Dateien (*.json)")
        if path:
            err = self.session.import_json(path)
            if err:
                QMessageBox.warning(self, "Fehler", err)
            else:
                self._update_ui()
                if self.session._praxisname:
                    self.setWindowTitle(f"KVDT Analyzer – {self.session._praxisname}")
                self.status.showMessage("✓ Session geladen", 3000)

    def _export_xlsx(self):
        # Prüfen ob openpyxl verfügbar
        try:
            import openpyxl
        except ImportError:
            reply = QMessageBox.question(
                self, "openpyxl nicht installiert",
                "Für Excel-Export wird openpyxl benötigt.\n\n"
                "Bitte ausführen:\n  pip install openpyxl\n\n"
                "Stattdessen CSV exportieren?")
            if reply == QMessageBox.StandardButton.Yes:
                self._export_csv()
            return

        path, _ = QFileDialog.getSaveFileName(
            self, "Excel exportieren", "KVDT-Auswertung.xlsx",
            "Excel-Dateien (*.xlsx)")
        if not path:
            return
        try:
            from core.export_xlsx import export_xlsx
            export_xlsx(self.session, path)
            self.status.showMessage(f"✓ Excel exportiert: {path}", 4000)
            QMessageBox.information(self, "Export erfolgreich",
                                    f"Excel-Datei gespeichert:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export-Fehler", str(e))

    def _export_csv(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "CSV exportieren", "KVDT-Auswertung.csv",
            "CSV-Dateien (*.csv)")
        if not path:
            return
        try:
            from core.export_csv import export_csv
            export_csv(self.session, path)
            self.status.showMessage(f"✓ CSV exportiert: {path}", 4000)
            QMessageBox.information(self, "Export erfolgreich",
                                    f"CSV-Datei gespeichert:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export-Fehler", str(e))

    def _check_update(self):
        from views.dialog_update import check_for_updates
        check_for_updates(parent=self, silent=False)

    def _open_settings(self):
        from views.dialog_settings import SettingsDialog
        dlg = SettingsDialog(parent=self)
        dlg.exec()

    def _open_user_manager(self):
        from views.dialogs_auth import UserManagerDialog
        dlg = UserManagerDialog(current_user=self.current_user, parent=self)
        dlg.exec()

    def _reset(self):
        self.session.clear()
        import os
        if os.path.exists(self.session.__class__.__module__):
            pass
        from core.session import SESSION_FILE
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
        self._update_ui()
        self.status.showMessage("Zurückgesetzt.", 3000)

    def _try_restore_session(self):
        if self.session.load():
            self._update_ui()
            if self.session._praxisname:
                self.setWindowTitle(f"KVDT Analyzer – {self.session._praxisname}")
            self.status.showMessage(
                f"✓ Session geladen – {len(self.session.quarters)} Quartal(e)", 3000)


# ── Hilfs-Widgets ─────────────────────────────────────────────────────────────

class DropZone(QFrame):
    files_dropped = pyqtSignal(list)
    open_clicked  = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setObjectName("dropZone")
        self.setAcceptDrops(True)
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(16)

        icon = QLabel("📂")
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("font-size: 56px;")
        layout.addWidget(icon)

        title = QLabel("KVDT-Dateien hier ablegen")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setObjectName("dropTitle")
        layout.addWidget(title)

        sub = QLabel(".con · .txt · .kvdt")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setObjectName("dropSub")
        layout.addWidget(sub)

        btn = QPushButton("  Dateien auswählen …")
        btn.setObjectName("btnPrimary")
        btn.setFixedWidth(220)
        btn.clicked.connect(self.open_clicked)
        layout.addWidget(btn, alignment=Qt.AlignmentFlag.AlignCenter)

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            self.setProperty("dragOver", True)
            self.style().unpolish(self)
            self.style().polish(self)
            e.acceptProposedAction()

    def dragLeaveEvent(self, e):
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)

    def dropEvent(self, e):
        self.setProperty("dragOver", False)
        self.style().unpolish(self)
        self.style().polish(self)
        paths = [u.toLocalFile() for u in e.mimeData().urls()
                 if u.toLocalFile().lower().endswith(('.con','.txt','.kvdt'))]
        if paths:
            self.files_dropped.emit(paths)


class QuarterChip(QFrame):
    remove_clicked = pyqtSignal(int)

    def __init__(self, label: str, color: str, idx: int):
        super().__init__()
        self.idx = idx
        self.setStyleSheet(
            f"QFrame {{ border: 2px solid {color}; border-radius: 14px; "
            f"background: white; padding: 0px; }}")
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 4, 6, 4)
        layout.setSpacing(6)

        dot = QLabel("●")
        dot.setStyleSheet(f"color: {color}; font-size: 10px; border:none; background:transparent;")
        layout.addWidget(dot)

        lbl = QLabel(label)
        lbl.setStyleSheet(f"color: {color}; font-size: 12px; font-weight: 700; border:none; background:transparent;")
        layout.addWidget(lbl)

        btn = QPushButton("✕")
        btn.setFixedSize(18, 18)
        btn.setStyleSheet(
            f"QPushButton {{ background: none; border: none; color: {color}; "
            f"font-size: 11px; padding: 0; border-radius: 9px; }}"
            f"QPushButton:hover {{ background: #fee2e2; color: #dc2626; }}")
        btn.clicked.connect(lambda: self.remove_clicked.emit(self.idx))
        layout.addWidget(btn)
