# views/tab_honorar.py
from collections import defaultdict
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget
from .base_tab import BaseTab
from core.parser import EBM_PUNKTE, EBM_BEZEICHNUNG, get_punktwert, resolve_ebm_code


def calc_honorar(patients, quarter_label):
    pw = get_punktwert(quarter_label)
    per_code = defaultdict(lambda: {"count":0,"punkte":0,"euro":0.0})
    total_punkte = 0
    total_euro   = 0.0
    unknown      = set()
    per_patient  = []

    for p in patients:
        pp, pe = 0, 0.0
        for e in p.ebm_entries:
            pts = EBM_PUNKTE.get(e.code, 0) * e.mult
            eur = pts * pw
            if e.code not in EBM_PUNKTE:
                unknown.add(e.code)
            per_code[e.code]["count"]  += e.mult
            per_code[e.code]["punkte"] += pts
            per_code[e.code]["euro"]   += eur
            pp += pts; pe += eur
        total_punkte += pp; total_euro += pe
        if pp > 0:
            per_patient.append((p.name, p.dob, pp, pe))

    per_patient.sort(key=lambda x: -x[2])

    # Unbekannte Ziffern in Logdatei schreiben
    if unknown:
        import os
        log_path = os.path.join(os.path.expanduser("~"), "kvdt_unbekannte_ziffern.txt")
        existing = set()
        if os.path.exists(log_path):
            with open(log_path, "r") as f:
                existing = {l.strip() for l in f if l.strip()}
        new_unknown = unknown - existing
        if new_unknown:
            with open(log_path, "a") as f:
                for code in sorted(new_unknown):
                    f.write(code + "\n")

    return dict(pw=pw, total_punkte=total_punkte, total_euro=total_euro,
                per_code=dict(per_code), unknown=unknown,
                per_patient=per_patient)
    pw = get_punktwert(quarter_label)
    per_code = defaultdict(lambda: {"count":0,"punkte":0,"euro":0.0})
    total_punkte = 0
    total_euro   = 0.0
    unknown      = set()
    per_patient  = []

    for p in patients:
        pp, pe = 0, 0.0
        for e in p.ebm_entries:
            resolved = resolve_ebm_code(e.code)
            pts = EBM_PUNKTE.get(resolved, 0) * e.mult
            eur = pts * pw
            if resolved not in EBM_PUNKTE:
                unknown.add(e.code)
            per_code[e.code]["count"]  += e.mult
            per_code[e.code]["punkte"] += pts
            per_code[e.code]["euro"]   += eur
            pp += pts; pe += eur
        total_punkte += pp; total_euro += pe
        if pp > 0:
            per_patient.append((p.name, p.dob, pp, pe))

    per_patient.sort(key=lambda x: -x[2])
    return dict(pw=pw, total_punkte=total_punkte, total_euro=total_euro,
                per_code=dict(per_code), unknown=unknown,
                per_patient=per_patient)


class TabHonorar(BaseTab):
    def refresh(self):
        self._clear()
        qs = self.session.quarters
        if not qs:
            self.content_layout.addWidget(QLabel("Keine Quartale geladen."))
            self.content_layout.addStretch()
            return

        self.content_layout.addWidget(
            self._header("💶 Honorar-Auswertung",
                         "EBM-Punkte · Geschätztes Honorar auf Basis Orientierungspunktwert"))

        h_data = [calc_honorar(q.patients, q.label) for q in qs]

        # ── Hinweis-Banner ────────────────────────────────────────────────────
        unknown = set().union(*(d["unknown"] for d in h_data))
        txt = ("⚠  Geschätztes Honorar basiert auf dem bundesweiten Orientierungspunktwert. "
               "Tatsächliches Honorar kann durch Budgetierung und regionale Vereinbarungen abweichen.")
        if unknown:
            txt += f"\n⚠  Unbekannte Ziffern (0 Punkte): {', '.join(sorted(unknown)[:10])}"
        self.content_layout.addWidget(self._banner(txt))

        # ── KPI-Karten ────────────────────────────────────────────────────────
        kpi_items = []
        for i, (q, h) in enumerate(zip(qs, h_data)):
            avg_p = h["total_punkte"] / q.patient_count if q.patient_count else 0
            kpi_items.append((
                q.label,
                self._fmt_int(round(h["total_punkte"])),
                f"≈ {self._fmt_euro(h['total_euro'])}  ·  "
                f"∅ {self._fmt_int(round(avg_p))} Pkt/Pat",
                self.session.color(i)
            ))
        self.content_layout.addWidget(self._kpi_row(kpi_items))

        # ── Vergleichstabelle ─────────────────────────────────────────────────
        self.content_layout.addWidget(self._section("Quartal-Vergleich"))
        cmp_headers = ["Kennzahl"] + [q.label for q in qs]
        if len(qs) >= 2:
            cmp_headers.append("Δ letzte")

        def row_with_delta(label, vals_raw, fmt):
            row = [label] + [fmt(v) for v in vals_raw]
            if len(qs) >= 2:
                try:
                    row.append(self._delta_str(float(vals_raw[-2]),
                                               float(vals_raw[-1])))
                except Exception:
                    row.append("—")
            return row

        cmp_rows = [
            row_with_delta("Gesamtpunkte",
                           [h["total_punkte"] for h in h_data],
                           lambda v: self._fmt_int(round(v))),
            row_with_delta("Geschätztes Honorar",
                           [h["total_euro"] for h in h_data],
                           lambda v: self._fmt_euro(v)),
            ["∅ Punkte/Patient"] +
                [self._fmt_int(round(h["total_punkte"]/q.patient_count))
                 if q.patient_count else "—"
                 for q, h in zip(qs, h_data)] +
                (["—"] if len(qs)>=2 else []),
            ["∅ Honorar/Patient"] +
                [self._fmt_euro(h["total_euro"]/q.patient_count)
                 if q.patient_count else "—"
                 for q, h in zip(qs, h_data)] +
                (["—"] if len(qs)>=2 else []),
            ["Orientierungspunktwert"] +
                [f"{h['pw']*100:.4f} Ct" for h in h_data] +
                (["—"] if len(qs)>=2 else []),
        ]
        self.content_layout.addWidget(
            self._table(cmp_headers, cmp_rows,
                        col_widths=[200]+[-1]*len(qs)+([100] if len(qs)>=2 else [])))

        # ── Top-Leistungen ────────────────────────────────────────────────────
        self.content_layout.addWidget(self._section("Top-Leistungen nach Punkten"))
        all_codes = sorted(
            {c for h in h_data for c in h["per_code"]},
            key=lambda c: -sum(h["per_code"].get(c,{}).get("punkte",0) for h in h_data))

        top_headers = ["EBM", "Bezeichnung", "Pkt/Lstg"] + \
                      [q.label for q in qs] + ["Σ Punkte"]
        top_rows = []
        for code in all_codes[:40]:
            pp = EBM_PUNKTE.get(code, "?")
            vals_str = []
            total_p = 0
            for h in h_data:
                d = h["per_code"].get(code)
                if d:
                    vals_str.append(f"{d['count']}× / {self._fmt_int(d['punkte'])} Pkt")
                    total_p += d["punkte"]
                else:
                    vals_str.append("—")
            top_rows.append([code, EBM_BEZEICHNUNG.get(code,""), pp,
                             *vals_str, self._fmt_int(round(total_p))])

        col_w = [80, -1, 70] + [140]*len(qs) + [90]
        self.content_layout.addWidget(
            self._table(top_headers, top_rows, col_widths=col_w))

        self.content_layout.addStretch()
