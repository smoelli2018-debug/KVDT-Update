# views/tab_diagnosen.py
from collections import Counter
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget, QTabWidget
from .base_tab import BaseTab


class TabDiagnosen(BaseTab):
    def refresh(self):
        self._clear()
        qs = self.session.quarters
        if not qs:
            self.content_layout.addWidget(QLabel("Keine Quartale geladen."))
            self.content_layout.addStretch()
            return

        self.content_layout.addWidget(
            self._header("🔬 Diagnosen", "ICD-10 Häufigkeiten"))

        for typ, label in [("alle","Alle Diagnosen"),
                            ("akut","Akutdiagnosen"),
                            ("dauer","Dauerdiagnosen")]:
            per_q = []
            for q in qs:
                c = Counter()
                for p in q.patients:
                    diags = []
                    if typ in ("alle","akut"):
                        diags += p.diag_akut
                    if typ in ("alle","dauer"):
                        diags += p.diag_dauer
                    for d in diags:
                        c[d.code] += 1
                per_q.append(c)

            all_codes = sorted(
                {c for cnt in per_q for c in cnt},
                key=lambda c: -sum(cnt[c] for cnt in per_q))

            if not all_codes:
                continue

            self.content_layout.addWidget(self._section(label))
            headers = ["ICD-10"] + [q.label for q in qs] + ["Gesamt"]
            rows = []
            for code in all_codes[:50]:
                vals = [cnt.get(code, 0) for cnt in per_q]
                rows.append([code,
                             *[self._fmt_int(v) for v in vals],
                             self._fmt_int(sum(vals))])

            col_w = [90] + [90]*len(qs) + [90]
            col_w[1] = -1  # zweite Spalte (erstes Quartal) strecken
            t = self._table(headers, rows, col_widths=col_w)
            self.content_layout.addWidget(t)

        self.content_layout.addStretch()
