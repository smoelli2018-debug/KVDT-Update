# views/base_tab.py
from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QTableWidget, QTableWidgetItem, QHeaderView, QScrollArea,
    QSizePolicy, QGridLayout
)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QColor, QFont
from views.style import (COLORS, BG, SURFACE, SURFACE2, BORDER, BORDER2,
                         TEXT, TEXT2, MUTED, ACCENT, ACCENT2)


class BaseTab(QWidget):
    def __init__(self, session):
        super().__init__()
        self.session = session
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        self.scroll = QScrollArea()
        self.scroll.setWidgetResizable(True)
        self.scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.scroll.setStyleSheet(f"background:{BG};")
        outer.addWidget(self.scroll)

        self.content = QWidget()
        self.content.setStyleSheet(f"background:{BG};")
        self.content_layout = QVBoxLayout(self.content)
        self.content_layout.setContentsMargins(28, 24, 28, 28)
        self.content_layout.setSpacing(20)
        self.scroll.setWidget(self.content)

    def refresh(self):
        pass

    def _clear(self):
        while self.content_layout.count():
            item = self.content_layout.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

    def _header(self, title: str, subtitle: str = "") -> QWidget:
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 4)
        l.setSpacing(3)
        t = QLabel(title)
        t.setStyleSheet(f"font-size:20px;font-weight:800;color:{TEXT};background:transparent;")
        l.addWidget(t)
        if subtitle:
            s = QLabel(subtitle)
            s.setStyleSheet(f"font-size:12px;color:{MUTED};background:transparent;")
            l.addWidget(s)
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(f"background:{BORDER};max-height:1px;border:none;")
        l.addWidget(line)
        return w

    def _section(self, title: str) -> QWidget:
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        l = QVBoxLayout(w)
        l.setContentsMargins(0, 6, 0, 4)
        l.setSpacing(4)
        lbl = QLabel(title)
        lbl.setStyleSheet(f"font-size:13px;font-weight:700;color:{TEXT2};background:transparent;")
        l.addWidget(lbl)
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet(f"background:{BORDER};max-height:1px;border:none;")
        l.addWidget(line)
        return w

    def _kpi_row(self, items: list) -> QWidget:
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        l = QHBoxLayout(w)
        l.setContentsMargins(0, 0, 0, 0)
        l.setSpacing(14)
        for label, value, sub, color in items:
            l.addWidget(self._kpi_card(label, value, sub, color))
        l.addStretch()
        return w

    def _kpi_card(self, label: str, value: str, sub: str = "", color: str = "") -> QFrame:
        if not color:
            color = ACCENT
        card = QFrame()
        card.setFixedWidth(200)
        card.setStyleSheet(f"""
            QFrame {{
                background: {SURFACE};
                border: 1px solid {BORDER};
                border-top: 4px solid {color};
                border-radius: 10px;
            }}
        """)
        l = QVBoxLayout(card)
        l.setContentsMargins(16, 14, 16, 14)
        l.setSpacing(5)
        lbl = QLabel(label)
        lbl.setStyleSheet(f"color:{MUTED};font-size:10px;font-weight:700;text-transform:uppercase;letter-spacing:1px;background:transparent;border:none;")
        l.addWidget(lbl)
        val = QLabel(value)
        val.setStyleSheet(f"font-size:26px;font-weight:800;color:{color};background:transparent;border:none;")
        l.addWidget(val)
        if sub:
            s = QLabel(sub)
            s.setStyleSheet(f"font-size:11px;color:{TEXT2};background:transparent;border:none;")
            s.setWordWrap(True)
            l.addWidget(s)
        return card

    def _table(self, headers: list, rows: list, col_widths: list = None, stretch_col: int = 1) -> QTableWidget:
        t = QTableWidget(len(rows), len(headers))
        t.setHorizontalHeaderLabels(headers)
        t.setAlternatingRowColors(True)
        t.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        t.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        t.verticalHeader().setVisible(False)
        t.horizontalHeader().setStretchLastSection(False)
        t.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        t.setShowGrid(True)
        for r, row in enumerate(rows):
            for c, val in enumerate(row):
                item = QTableWidgetItem(str(val) if val is not None else "")
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignVCenter |
                    (Qt.AlignmentFlag.AlignRight if isinstance(val, (int, float))
                     else Qt.AlignmentFlag.AlignLeft))
                t.setItem(r, c, item)
        hdr = t.horizontalHeader()
        if col_widths:
            for i, w in enumerate(col_widths):
                if i >= len(headers):
                    break
                if w == -1:
                    hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
                else:
                    hdr.setSectionResizeMode(i, QHeaderView.ResizeMode.Fixed)
                    t.setColumnWidth(i, w)
        else:
            if stretch_col < len(headers):
                hdr.setSectionResizeMode(stretch_col, QHeaderView.ResizeMode.Stretch)
        t.resizeRowsToContents()
        total_h = t.horizontalHeader().height()
        for i in range(t.rowCount()):
            total_h += t.rowHeight(i)
        t.setMaximumHeight(min(total_h + 4, 520))
        return t

    def _banner(self, text: str) -> QLabel:
        lbl = QLabel(text)
        lbl.setObjectName("infoBanner")
        lbl.setWordWrap(True)
        return lbl

    def _delta_str(self, a, b) -> str:
        try:
            if a and a != 0:
                d = (b - a) / abs(a) * 100
                arrow = "▲" if d >= 0 else "▼"
                return f"{arrow} {abs(d):.1f}%"
        except Exception:
            pass
        return ""

    def _fmt_int(self, v) -> str:
        try:
            return f"{int(v):,}".replace(",", ".")
        except Exception:
            return str(v)

    def _fmt_euro(self, v: float) -> str:
        return f"{v:,.2f} €".replace(",", "X").replace(".", ",").replace("X", ".")
