# views/style.py
COLORS = ["#2563eb","#7c3aed","#059669","#d97706","#dc2626","#0891b2"]

BG       = "#f8fafc"
SURFACE  = "#ffffff"
SURFACE2 = "#f1f5f9"
BORDER   = "#e2e8f0"
BORDER2  = "#cbd5e1"
TEXT     = "#0f172a"
TEXT2    = "#334155"
MUTED    = "#94a3b8"
ACCENT   = "#2563eb"
ACCENT2  = "#059669"
DANGER   = "#dc2626"
TOOLBAR  = "#1e3a5f"

STYLE = f"""
* {{
    font-family: 'Segoe UI', 'Arial', sans-serif;
    font-size: 13px;
    color: {TEXT};
}}

QMainWindow, QDialog {{
    background: {BG};
}}

QWidget {{
    background: {BG};
}}

/* ── Toolbar ─────────────────────────────────────────────── */
QToolBar#mainToolbar {{
    background: {TOOLBAR};
    border: none;
    padding: 6px 10px;
    spacing: 2px;
}}
QToolBar#mainToolbar QToolButton {{
    background: transparent;
    border: 1px solid transparent;
    border-radius: 6px;
    padding: 6px 14px;
    color: #ffffff;
    font-size: 12px;
    font-weight: 600;
}}
QToolBar#mainToolbar QToolButton:hover {{
    background: rgba(255,255,255,0.15);
    border-color: rgba(255,255,255,0.3);
}}
QToolBar#mainToolbar QToolButton:disabled {{
    color: rgba(255,255,255,0.35);
}}
QToolBar::separator {{
    background: rgba(255,255,255,0.2);
    width: 1px;
    margin: 6px 4px;
}}
#bsnrLabel {{
    color: rgba(255,255,255,0.6);
    font-size: 11px;
    padding-right: 10px;
}}

/* ── Quartals-Leiste ─────────────────────────────────────── */
#quarterBar {{
    background: {SURFACE};
    border-bottom: 2px solid {BORDER};
    min-height: 42px;
    max-height: 42px;
}}

/* ── Drop-Zone ───────────────────────────────────────────── */
#dropZone {{
    background: {SURFACE};
    border: 2px dashed {BORDER2};
    border-radius: 16px;
    margin: 48px;
}}
#dropZone[dragOver="true"] {{
    border-color: {ACCENT};
    background: #eff6ff;
}}
#dropTitle {{
    font-size: 22px;
    font-weight: 700;
    color: {TEXT};
}}
#dropSub {{
    font-size: 13px;
    color: {MUTED};
}}

/* ── Tabs ────────────────────────────────────────────────── */
QTabWidget#mainTabs::pane {{
    border: none;
    border-top: 1px solid {BORDER};
    background: {BG};
}}
QTabBar {{
    background: {SURFACE};
}}
QTabBar::tab {{
    background: {SURFACE};
    color: {MUTED};
    border: none;
    border-bottom: 3px solid transparent;
    padding: 11px 20px;
    font-size: 12px;
    font-weight: 600;
    min-width: 120px;
}}
QTabBar::tab:selected {{
    color: {ACCENT};
    border-bottom: 3px solid {ACCENT};
    background: {BG};
}}
QTabBar::tab:hover:!selected {{
    color: {TEXT2};
    background: {SURFACE2};
}}

/* ── Buttons ─────────────────────────────────────────────── */
#btnPrimary {{
    background: {ACCENT};
    color: white;
    border: none;
    border-radius: 8px;
    padding: 11px 24px;
    font-weight: 700;
    font-size: 13px;
}}
#btnPrimary:hover {{
    background: #1d4ed8;
}}
QPushButton {{
    background: {SURFACE};
    color: {TEXT2};
    border: 1px solid {BORDER2};
    border-radius: 6px;
    padding: 6px 16px;
}}
QPushButton:hover {{
    background: {SURFACE2};
    border-color: {ACCENT};
    color: {ACCENT};
}}
QPushButton:disabled {{
    color: {MUTED};
    border-color: {BORDER};
}}

/* ── Tabellen ────────────────────────────────────────────── */
QTableWidget {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 8px;
    gridline-color: {BORDER};
    alternate-background-color: {SURFACE2};
    outline: none;
}}
QTableWidget::item {{
    padding: 7px 12px;
    border: none;
    color: {TEXT};
}}
QTableWidget::item:selected {{
    background: #dbeafe;
    color: {TEXT};
}}
QHeaderView::section {{
    background: {SURFACE2};
    color: {TEXT2};
    border: none;
    border-right: 1px solid {BORDER};
    border-bottom: 2px solid {BORDER2};
    padding: 9px 12px;
    font-weight: 700;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}}
QHeaderView::section:first {{
    border-top-left-radius: 8px;
}}

/* ── Scroll ──────────────────────────────────────────────── */
QScrollBar:vertical {{
    background: {SURFACE2};
    width: 8px;
    border-radius: 4px;
    margin: 0;
}}
QScrollBar::handle:vertical {{
    background: {BORDER2};
    border-radius: 4px;
    min-height: 30px;
}}
QScrollBar::handle:vertical:hover {{
    background: {MUTED};
}}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{ height: 0; }}
QScrollBar:horizontal {{
    background: {SURFACE2};
    height: 8px;
    border-radius: 4px;
}}
QScrollBar::handle:horizontal {{
    background: {BORDER2};
    border-radius: 4px;
    min-width: 30px;
}}
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {{ width: 0; }}

/* ── Cards ───────────────────────────────────────────────── */
#card {{
    background: {SURFACE};
    border: 1px solid {BORDER};
    border-radius: 12px;
}}
#cardTitle {{
    font-size: 10px;
    font-weight: 700;
    color: {MUTED};
    text-transform: uppercase;
    letter-spacing: 1px;
}}
#cardValue {{
    font-size: 28px;
    font-weight: 800;
    color: {TEXT};
}}
#cardSub {{
    font-size: 11px;
    color: {MUTED};
}}
#sectionTitle {{
    font-size: 15px;
    font-weight: 700;
    color: {TEXT};
}}
#infoBanner {{
    background: #fffbeb;
    border: 1px solid #fcd34d;
    border-radius: 8px;
    padding: 10px 14px;
    color: #92400e;
    font-size: 12px;
}}

/* ── Statusbar ───────────────────────────────────────────── */
QStatusBar {{
    background: {SURFACE2};
    color: {TEXT2};
    font-size: 11px;
    border-top: 1px solid {BORDER};
    padding: 2px 8px;
}}

/* ── ComboBox ────────────────────────────────────────────── */
QComboBox {{
    background: {SURFACE};
    border: 1px solid {BORDER2};
    border-radius: 6px;
    padding: 6px 10px;
    color: {TEXT};
}}
QComboBox:hover {{ border-color: {ACCENT}; }}
QComboBox::drop-down {{ border: none; width: 20px; }}
QComboBox QAbstractItemView {{
    background: {SURFACE};
    border: 1px solid {BORDER2};
    selection-background-color: #dbeafe;
    selection-color: {TEXT};
}}

/* ── LineEdit ────────────────────────────────────────────── */
QLineEdit {{
    background: {SURFACE};
    border: 1px solid {BORDER2};
    border-radius: 6px;
    padding: 6px 10px;
    color: {TEXT};
}}
QLineEdit:focus {{ border-color: {ACCENT}; }}

/* ── Progress Dialog ─────────────────────────────────────── */
QProgressDialog {{
    background: {SURFACE};
    border: 1px solid {BORDER2};
    border-radius: 10px;
}}
QProgressBar {{
    background: {SURFACE2};
    border: 1px solid {BORDER};
    border-radius: 5px;
    height: 18px;
    text-align: center;
    color: {TEXT2};
}}
QProgressBar::chunk {{
    background: {ACCENT};
    border-radius: 4px;
}}

/* ── MessageBox ──────────────────────────────────────────── */
QMessageBox {{
    background: {SURFACE};
}}
QMessageBox QLabel {{
    color: {TEXT};
    font-size: 13px;
}}
"""

