# views/tab_vergleich.py
from PyQt6.QtWidgets import QLabel, QHBoxLayout, QWidget
from .base_tab import BaseTab
from views.style import COLORS


class TabVergleich(BaseTab):
    def refresh(self):
        self._clear()
        qs = self.session.quarters
        if not qs:
            self.content_layout.addWidget(QLabel("Keine Quartale geladen."))
            self.content_layout.addStretch()
            return

        self.content_layout.addWidget(
            self._header("📊 Quartal-Vergleich", "Kennzahlen im Überblick"))

        # ── KPI-Karten ────────────────────────────────────────────────────────
        kpi_w = QWidget()
        kpi_l = QHBoxLayout(kpi_w)
        kpi_l.setContentsMargins(0,0,0,0)
        kpi_l.setSpacing(12)
        for i, q in enumerate(qs):
            color = self.session.color(i)
            ebm   = sum(len(p.ebm_codes) for p in q.patients)
            diag  = sum(len(p.diag_akut)+len(p.diag_dauer) for p in q.patients)
            sub   = (f"EBM: {self._fmt_int(ebm)}  ·  "
                     f"Diag: {self._fmt_int(diag)}")
            kpi_l.addWidget(
                self._kpi_card(q.label, self._fmt_int(q.patient_count),
                               sub, color))
        kpi_l.addStretch()
        self.content_layout.addWidget(kpi_w)

        # ── Vergleichstabelle ─────────────────────────────────────────────────
        self.content_layout.addWidget(self._section("Kennzahlen"))

        headers = ["Kennzahl"] + [q.label for q in qs]
        if len(qs) >= 2:
            headers.append("Δ letzte")

        def stat(q):
            ebm  = sum(len(p.ebm_codes) for p in q.patients)
            diag = sum(len(p.diag_akut)+len(p.diag_dauer) for p in q.patients)
            m    = sum(1 for p in q.patients if p.sex == "M")
            w    = sum(1 for p in q.patients if p.sex == "W")
            ebmpp = f"{ebm/q.patient_count:.1f}" if q.patient_count else "—"
            return dict(pat=q.patient_count, ebm=ebm, diag=diag,
                        ebmpp=ebmpp, m=m, w=w)

        stats = [stat(q) for q in qs]

        rows_defs = [
            ("Patienten",        lambda s: self._fmt_int(s["pat"])),
            ("EBM-Leistungen",   lambda s: self._fmt_int(s["ebm"])),
            ("EBM pro Patient",  lambda s: s["ebmpp"]),
            ("Diagnosen",        lambda s: self._fmt_int(s["diag"])),
            ("Männlich",         lambda s: self._fmt_int(s["m"])),
            ("Weiblich",         lambda s: self._fmt_int(s["w"])),
        ]
        rows = []
        for label, fn in rows_defs:
            row = [label] + [fn(s) for s in stats]
            if len(qs) >= 2:
                try:
                    a = float(str(fn(stats[-2])).replace(".","").replace(",","."))
                    b = float(str(fn(stats[-1])).replace(".","").replace(",","."))
                    row.append(self._delta_str(a, b))
                except Exception:
                    row.append("—")
            rows.append(row)

        col_w = [200] + [-1]*len(qs) + ([100] if len(qs)>=2 else [])
        t = self._table(headers, rows, col_widths=col_w)
        self.content_layout.addWidget(t)

        # ── Patientenbewegungen ───────────────────────────────────────────────
        if len(qs) >= 2:
            self.content_layout.addWidget(self._section("Patientenbewegungen"))
            mov_headers = ["Übergang", "Neu", "Weggefallen", "Weiterhin"]
            mov_rows = []
            for i in range(1, len(qs)):
                prev_keys = {p.key for p in qs[i-1].patients}
                curr_keys = {p.key for p in qs[i].patients}
                neu  = len(curr_keys - prev_keys)
                weg  = len(prev_keys - curr_keys)
                cont = len(prev_keys & curr_keys)
                mov_rows.append([
                    f"{qs[i-1].label} → {qs[i].label}",
                    self._fmt_int(neu), self._fmt_int(weg), self._fmt_int(cont)])
            self.content_layout.addWidget(
                self._table(mov_headers, mov_rows, col_widths=[-1,100,100,100]))

        self.content_layout.addStretch()
