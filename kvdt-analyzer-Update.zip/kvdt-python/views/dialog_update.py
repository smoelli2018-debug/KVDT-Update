# views/dialog_update.py – Update-Dialog
import sys
from PyQt6.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QProgressBar, QMessageBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal


class UpdateWorker(QThread):
    progress = pyqtSignal(int, str)
    done     = pyqtSignal(bool, str)

    def run(self):
        from core.updater import download_and_install
        def cb(pct, msg):
            self.progress.emit(pct, msg)
        ok, msg = download_and_install(progress_callback=cb)
        self.done.emit(ok, msg)


class UpdateDialog(QDialog):
    def __init__(self, local_ver: str, remote_ver: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Update verfügbar")
        self.setFixedSize(440, 280)
        self.setWindowFlags(Qt.WindowType.Dialog |
                            Qt.WindowType.MSWindowsFixedSizeDialogHint)
        self.local_ver  = local_ver
        self.remote_ver = remote_ver
        self._build()

    def _build(self):
        L = QVBoxLayout(self)
        L.setContentsMargins(28, 22, 28, 22)
        L.setSpacing(12)

        t = QLabel("🔄  Update verfügbar")
        t.setStyleSheet("font-size:16px; font-weight:bold; color:#1e3a5f;")
        L.addWidget(t)

        info = QLabel(
            f"Eine neue Version des KVDT Analyzers ist verfügbar.\n\n"
            f"  Installierte Version:   {self.local_ver}\n"
            f"  Neue Version:           {self.remote_ver}"
        )
        info.setStyleSheet(
            "background:#eff6ff; border:1px solid #bfdbfe; border-radius:6px;"
            "padding:10px 14px; color:#1e40af; font-size:13px;")
        L.addWidget(info)

        self.pb = QProgressBar()
        self.pb.setRange(0, 100)
        self.pb.setValue(0)
        self.pb.hide()
        L.addWidget(self.pb)

        self.lbl_status = QLabel("")
        self.lbl_status.setStyleSheet("color:#64748b; font-size:12px;")
        self.lbl_status.hide()
        L.addWidget(self.lbl_status)

        L.addStretch()

        row = QHBoxLayout()
        self.btn_skip = QPushButton("Überspringen")
        self.btn_skip.setStyleSheet(
            "QPushButton{background:white;color:#334155;border:1px solid #e2e8f0;"
            "border-radius:7px;padding:8px 18px;font-weight:400;}"
            "QPushButton:hover{background:#f1f5f9;}")
        self.btn_skip.clicked.connect(self.reject)
        row.addWidget(self.btn_skip)
        row.addStretch()

        self.btn_update = QPushButton("⬇  Jetzt aktualisieren")
        self.btn_update.setStyleSheet(
            "QPushButton{background:#2563eb;color:white;border:none;"
            "border-radius:7px;padding:8px 20px;font-weight:700;}"
            "QPushButton:hover{background:#1d4ed8;}"
            "QPushButton:disabled{background:#cbd5e1;color:#94a3b8;}")
        self.btn_update.setFixedHeight(38)
        self.btn_update.clicked.connect(self._start_update)
        row.addWidget(self.btn_update)
        L.addLayout(row)

    def _start_update(self):
        self.btn_update.setEnabled(False)
        self.btn_skip.setEnabled(False)
        self.pb.show()
        self.lbl_status.show()

        self.worker = UpdateWorker()
        self.worker.progress.connect(self._on_progress)
        self.worker.done.connect(self._on_done)
        self.worker.start()

    def _on_progress(self, pct, msg):
        self.pb.setValue(pct)
        self.lbl_status.setText(msg)

    def _on_done(self, ok, msg):
        self.pb.setValue(100)
        if ok:
            QMessageBox.information(self, "Update erfolgreich", msg)
            self.accept()
            # Programm neu starten
            import os
            if getattr(__import__('sys'), 'frozen', False):
                import sys
                os.execv(sys.executable, [sys.executable])
            else:
                import sys, subprocess
                subprocess.Popen([sys.executable] + sys.argv)
                sys.exit(0)
        else:
            QMessageBox.critical(self, "Update fehlgeschlagen", msg)
            self.btn_skip.setEnabled(True)
            self.btn_update.setEnabled(True)


def check_for_updates(parent=None, silent=True) -> bool:
    """Prüft auf Updates. Bei silent=True nur Dialog wenn Update vorhanden.
    Gibt True zurück wenn Update installiert wurde."""
    from core.updater import update_available
    available, local, remote = update_available()

    if not available:
        if not silent:
            QMessageBox.information(parent, "Kein Update",
                f"Sie verwenden bereits die aktuelle Version ({local}).")
        return False

    dlg = UpdateDialog(local, remote, parent=parent)
    return dlg.exec() == QDialog.DialogCode.Accepted
