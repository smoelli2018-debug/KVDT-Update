@echo off
echo ============================================
echo  KVDT Analyzer - EXE Build
echo ============================================
echo.

python -m pip install pyinstaller -q

echo Pruefe ebm_data.py auf Syntaxfehler...
python -m py_compile core\ebm_data.py
if errorlevel 1 (
    echo FEHLER: core\ebm_data.py hat Syntaxfehler!
    echo Bitte ebm_data.py aus der aktuellen ZIP verwenden.
    pause
    exit /b 1
)
echo OK.
echo.

echo Alte Build-Ordner werden geloescht...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build

echo.
echo Schritt 1: Update-Helper bauen...
python -m PyInstaller kvdt_helper.spec
echo.

echo Schritt 2: Hauptprogramm bauen...
python -m PyInstaller kvdt_analyzer.spec
echo.

if exist "dist\kvdt_update_helper.exe" (
    copy "dist\kvdt_update_helper.exe" "dist\KVDT-Analyzer\kvdt_update_helper.exe" >nul
    echo Helper-EXE kopiert.
)

echo.
if exist "dist\KVDT-Analyzer\KVDT-Analyzer.exe" (
    echo ============================================
    echo  FERTIG!
    echo  Ordner: dist\KVDT-Analyzer\
    echo  Dieser gesamte Ordner muss weitergegeben
    echo  werden (nicht nur die EXE).
    echo ============================================
) else (
    echo FEHLER beim Build - siehe Ausgabe oben
)
pause
