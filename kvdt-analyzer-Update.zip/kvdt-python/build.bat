@echo off
echo ============================================
echo  KVDT Analyzer - EXE Build
echo ============================================
echo.

python -m pip install pyinstaller -q

echo Alte Build-Dateien werden geloescht...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build

echo.
echo Schritt 1: Update-Helper bauen...
python -m PyInstaller kvdt_helper.spec
echo.

echo Schritt 2: Hauptprogramm bauen...
python -m PyInstaller kvdt_analyzer.spec
echo.

REM Helper-EXE ins Hauptprogramm-Verzeichnis kopieren
if exist "dist\kvdt_update_helper.exe" (
    copy "dist\kvdt_update_helper.exe" "dist\KVDT-Analyzer\kvdt_update_helper.exe"
    echo Helper-EXE kopiert.
)

echo.
if exist "dist\KVDT-Analyzer\KVDT-Analyzer.exe" (
    echo ============================================
    echo  FERTIG!
    echo  Ordner: dist\KVDT-Analyzer\
    echo  Dieser gesamte Ordner muss weitergegeben
    echo  werden (nicht nur die EXE).
    echo ============================================
) else (
    echo FEHLER beim Build - siehe Ausgabe oben
)
pause
