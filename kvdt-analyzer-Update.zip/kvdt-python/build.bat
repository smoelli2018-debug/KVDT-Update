@echo off
echo ============================================
echo  KVDT Analyzer - EXE Build
echo ============================================
echo.

echo Installiere PyInstaller...
python -m pip install pyinstaller

echo.
echo Alte Build-Dateien werden geloescht...
if exist dist rmdir /s /q dist
if exist build rmdir /s /q build

echo.
echo Baue EXE - bitte warten (3-5 Minuten)...
echo.

python -m PyInstaller kvdt_analyzer.spec

echo.
if exist "dist\KVDT-Analyzer\KVDT-Analyzer.exe" (
    echo ============================================
    echo  FERTIG!
    echo  EXE: dist\KVDT-Analyzer\KVDT-Analyzer.exe
    echo ============================================
) else (
    echo FEHLER beim Build - siehe Ausgabe oben
)
pause
