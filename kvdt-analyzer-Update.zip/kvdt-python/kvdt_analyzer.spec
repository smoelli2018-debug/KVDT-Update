# kvdt_analyzer.spec
# Ausführen: pyinstaller kvdt_analyzer.spec
# EXE liegt danach unter: dist\KVDT-Analyzer\KVDT-Analyzer.exe

import os
block_cipher = None

a = Analysis(
    ['main.py'],
    pathex=[os.path.abspath('.')],
    binaries=[],
    datas=[
        ('core/*.py', 'core'),
        ('views/*.py', 'views'),
        ('tools/*.py', 'tools'),
        ('version.txt', '.'),
        ('kvdt_update_helper.py', '.'),
    ],
    hiddenimports=[
        'PyQt6.QtCore',
        'PyQt6.QtGui',
        'PyQt6.QtWidgets',
        'PyQt6.QtNetwork',
        'PyQt6.sip',
        'openpyxl',
        'openpyxl.styles',
        'openpyxl.styles.fonts',
        'openpyxl.styles.fills',
        'openpyxl.styles.borders',
        'openpyxl.styles.alignment',
        'openpyxl.utils',
        'openpyxl.workbook',
        'openpyxl.worksheet',
        'core',
        'core.updater',
        'core.parser',
        'core.ebm_data',
        'core.session',
        'core.auth',
        'core.settings',
        'core.lizenzpruefung',
        'core.export_xlsx',
        'core.export_csv',
        'views',
        'views.main_window',
        'views.style',
        'views.base_tab',
        'views.tab_vergleich',
        'views.tab_ebm',
        'views.tab_diagnosen',
        'views.tab_chroniker',
        'views.tab_honorar',
        'views.dialogs_auth',
        'views.dialog_update',
        'views.dialog_settings',
        'hashlib',
        'json',
        'urllib.request',
        'urllib.error',
        'xml.etree.ElementTree',
        'dataclasses',
        'collections',
        'csv',
        'shutil',
        'base64',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        'tkinter',
        'matplotlib',
        'numpy',
        'pandas',
        'scipy',
        'PIL',
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,      # onedir Modus
    name='KVDT-Analyzer',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='assets/icon.ico' if os.path.exists('assets/icon.ico') else None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='KVDT-Analyzer',       # Ordnername unter dist/
)
